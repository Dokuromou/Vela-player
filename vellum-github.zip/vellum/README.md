# Vellum

![Vellum — dark theme](docs/screenshot-dark.png)

A fast, local-first Markdown workspace that runs entirely in your browser. Think Obsidian's best ideas — wiki-links, backlinks, graph view, databases, daily notes — with none of the plugin ceremony, and plain `.md` files with YAML frontmatter as the only storage format.

<p>
  <img src="docs/screenshot-light.png" alt="Light theme with callouts and live tables" width="49%" />
  <img src="docs/screenshot-paper.png" alt="Warm Paper theme" width="49%" />
</p>
<p>
  <img src="docs/screenshot-kanban.png" alt="Kanban board generated from frontmatter" width="49%" />
  <img src="docs/screenshot-graph.png" alt="Knowledge graph" width="49%" />
</p>

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # type-check + production bundle in dist/
npm run preview  # serve the production build
```

Everything is static — no server, no database, no API keys. The build works when served from a domain root, from a sub-path (`https://user.github.io/repo/`) or opened as a local file.

---

## What's inside

### Local vault, real files
- **File System Access API** — open any folder and Vellum reads/writes real `.md` files. The directory handle is remembered in IndexedDB, so a reload re-connects (permission is re-requested by the browser when needed).
- **IndexedDB fallback** — if the folder picker is unavailable (e.g. embedded preview, Firefox, Safari) the app transparently keeps a local vault in IndexedDB. Nothing is lost; notes still autosave.
- **Autosave** — every keystroke is debounced (~400 ms) into the vault; the status bar reports save state.
- **Offline** — a service worker caches the app shell, so a production build loads with no network at all.

### Editor (CodeMirror 6)
Live-preview Markdown: the Markdown source stays the source of truth, but non-active lines render as you'd expect.

- Headings, **bold**, *italic*, ~~strike~~, `inline code`, links, `#tags`
- **Real tables** — pipe tables render as an actual grid; put the caret on a row and that row shows its raw Markdown
- **Callouts** — `> [!note|tip|warning|danger|info]` render with colour and an icon
- **Checklists** — click a checkbox to toggle `[ ]` ↔ `[x]`; the file changes on disk
- Fenced code blocks, dividers, bullet widgets, smart list continuation (Enter keeps lists, checkboxes and ordered numbering going)
- `[[wiki-links]]` render as chips; missing targets are dotted and clickable (a click creates the note)
- Frontmatter collapses into the property chips above the editor; click **properties** to reveal and edit the YAML

### Slash commands
Type `/` anywhere to insert a table, callout, task list, code block, divider, headings, today's date, frontmatter, wiki-link or a template (meeting notes, project note, decision log, daily log).

### Wiki-links & backlinks
- `[[` opens fuzzy autocomplete across **all note titles, folder paths and `#headings`**
- Aliases (`[[Note|label]]`) and heading links (`[[Note#Section]]`) are supported
- Backlinks are collected automatically and shown in a collapsible footer under every note, and in the right sidebar with context snippets

### Databases from frontmatter
Any folder can be viewed as a **Table** or a **Kanban board** (⋮ menu on a folder, the Views button, or the palette):
- Columns are inferred from the union of YAML keys (`status`, `tags`, `date`, `due`, `owner`, `priority`, …)
- Sortable table with inline `status` editing and tag chips
- Kanban groups by `status` with drag & drop between columns — dropping a card rewrites the frontmatter in the file

### Daily notes
A mini-calendar in the sidebar (dots mark days that already have notes) creates or opens `Daily/YYYY-MM-DD.md` from a template with yesterday/tomorrow links.

### Knowledge graph
- **Global** graph overlay and **local** graph in the right sidebar (1° / 2° depth)
- Hand-rolled force simulation on canvas: drag to pin, scroll to zoom, drag background to pan, hover to isolate neighbours
- Node size = degree, node colour = first tag, search box dims non-matches, tag legend filters

### Workspace
- Collapsible file tree (right-click a note for rename / duplicate / delete), instant search with worker-backed results and snippets
- Tabbed editor with **split panes**; outline, backlinks and local graph in the right sidebar
- `⌘/Ctrl + P` command palette (type `>` for commands), `⌘/Ctrl + N` new note, `⌘/Ctrl + ⇧ + D` daily note, `⌘/Ctrl + G` graph, `⌘/Ctrl + \` split
- **Three themes** — Dark, Light, Warm Paper — all driven by CSS custom properties
- 11 interconnected sample notes ship on first launch, so backlinks, Kanban and the graph are populated immediately

---

## Architecture

```
src/
  App.tsx                 layout, global shortcuts
  store/useStore.ts       zustand store: notes, panes, view state, vault IO
  lib/
    markdown.ts           frontmatter, links, headings, tags, backlinks, graph
    vault.ts              FsVault (File System Access) + IdbVault (IndexedDB)
    db.ts                 promise wrappers for IndexedDB
    searchCore.ts         inverted-index search (pure, used by worker + fallback)
    searchClient.ts       worker facade with main-thread fallback
    samples.ts            starter vault + daily template
  workers/search.worker.ts background index over every note
  editor/
    livePreview.ts        CodeMirror decorations: live Markdown rendering
    theme.ts              editor theme + syntax highlight style
    keymap.ts             list continuation, inline formatting, indent
    slashCommands.ts      slash-menu definitions
    registry.ts           access to the active EditorView (insert/scroll)
  components/             TopBar, Sidebar, FileTree, Calendar, EditorPane,
                          MarkdownEditor, RightSidebar, ForceGraph,
                          DatabaseViews, CommandPalette, GraphOverlay,
                          Onboarding, StatusBar, Toasts
```

**Storage format** — a note is a Markdown file:

```markdown
---
title: Website Redesign
status: In Progress
tags: [project, design]
date: 2026-11-04
due: 2026-12-12
owner: Ana
---

# Website Redesign

Rebuild the site around the [[Notes/Design System]].
```

Folders are folders, frontmatter is plain YAML, and there is no database: delete the app and your notes are still yours.

### Search indexing
Every note is tokenised in a Web Worker (inverted index → `token → {path, tf}`). Queries score title hits, prefix matches and term frequency, then return a snippet around the first match. If workers are blocked, the identical core runs on the main thread — the status bar tells you which is active.

---

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| `⌘/Ctrl + P` | Quick switcher |
| `⌘/Ctrl + ⇧ + P` | Command list |
| `⌘/Ctrl + N` | New note |
| `⌘/Ctrl + ⇧ + D` | Today's daily note |
| `⌘/Ctrl + G` | Knowledge graph |
| `⌘/Ctrl + B` / `⌘/Ctrl + ⇧ + B` | Toggle left / right sidebar |
| `⌘/Ctrl + \` | Split pane |
| `⌘/Ctrl + B / I / E` | Bold / italic / code (in editor) |
| `⌘/Ctrl + ↵` | Toggle task on the current line |
| `/` | Slash menu |
| `[[` | Wiki-link autocomplete |
| `Esc` | Close palette / graph / menus |

## Browser support

Chromium-based browsers get the full experience including real folders. Firefox and Safari fall back to the IndexedDB vault (everything else works). Inside a sandboxed preview iframe the folder picker is blocked by the browser — Vellum says so and keeps using the local vault.

---

## Publish it on GitHub

The repository is ready to push as-is (this folder already has git history, `.gitignore`, MIT license and a Pages workflow).

```bash
# from this project folder
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

Or, with the [GitHub CLI](https://cli.github.com/) creating the repo at the same time:

```bash
gh repo create <repo> --public --source=. --remote=origin --push
```

**Live demo on GitHub Pages** — after the first push: *Settings → Pages → Source: **GitHub Actions***.
`.github/workflows/deploy.yml` then builds and publishes on every push to `main` (type-checks with `tsc --noEmit`, builds with Vite, uploads `dist`). The app is a single static page, so no SPA rewrite rules are needed.

Notes:

- Change the licence holder in `LICENSE` if it should be your name rather than "Vellum contributors".
- Optional: add `"repository"`, `"homepage"` and `"bugs"` to `package.json` so npm and GitHub link back to your repo.
- Any static host works the same way: Vercel, Netlify, Cloudflare Pages (`npm run build`, output `dist`).

## Licence

[MIT](LICENSE)
