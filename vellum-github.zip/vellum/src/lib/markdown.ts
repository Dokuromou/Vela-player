import yaml from 'js-yaml'
import type { Backlink, Frontmatter, Heading, LinkRef, Note } from '../types'

const FM_RE = /^---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/

export interface SplitNote {
  fm: Frontmatter
  fmRaw: string
  body: string
  hasFrontmatter: boolean
}

export function splitFrontmatter(content: string): SplitNote {
  const m = FM_RE.exec(content)
  if (!m) return { fm: {}, fmRaw: '', body: content, hasFrontmatter: false }
  let fm: Frontmatter = {}
  try {
    const parsed = yaml.load(m[1], { schema: yaml.JSON_SCHEMA })
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) fm = parsed as Frontmatter
  } catch {
    fm = {}
  }
  return { fm, fmRaw: m[1], body: content.slice(m[0].length), hasFrontmatter: true }
}

export function serializeFrontmatter(fm: Frontmatter): string {
  const keys = Object.keys(fm)
  if (!keys.length) return ''
  const dumped = yaml.dump(fm, { schema: yaml.JSON_SCHEMA, lineWidth: 1000, noRefs: true, sortKeys: false })
  return `---\n${dumped}---\n`
}

export function replaceFrontmatter(content: string, fm: Frontmatter): string {
  const { body } = splitFrontmatter(content)
  const head = serializeFrontmatter(fm)
  return head ? `${head}${body.replace(/^\r?\n/, '')}` : body
}

export function setFrontmatterKey(content: string, key: string, value: unknown): string {
  const { fm, body } = splitFrontmatter(content)
  const next: Frontmatter = { ...fm }
  if (value === undefined || value === null || value === '') delete next[key]
  else next[key] = value
  const head = serializeFrontmatter(next)
  return head ? `${head}${body.replace(/^\r?\n/, '')}` : body
}

export function basename(path: string): string {
  const i = path.lastIndexOf('/')
  return i === -1 ? path : path.slice(i + 1)
}

export function dirname(path: string): string {
  const i = path.lastIndexOf('/')
  return i === -1 ? '' : path.slice(0, i)
}

export function noteTitle(path: string): string {
  return basename(path).replace(/\.md$/i, '')
}

export function normalizeTarget(target: string): string {
  return target.replace(/\.md$/i, '').replace(/^\/+/, '').trim()
}

const WIKILINK_RE = /(!?)\[\[([^\]\n]+)\]\]/g

export function parseLinks(body: string): LinkRef[] {
  const out: LinkRef[] = []
  const seen = new Set<string>()
  let m: RegExpExecArray | null
  while ((m = WIKILINK_RE.exec(body))) {
    const embed = m[1] === '!'
    const inner = m[2].trim()
    if (!inner) continue
    const [beforeAlias, alias] = splitOnce(inner, '|')
    const [targetRaw, heading] = splitOnce(beforeAlias, '#')
    const target = targetRaw.trim()
    const key = `${target}#${heading || ''}|${alias || ''}`
    if (!target && !heading) continue
    if (seen.has(key)) continue
    seen.add(key)
    out.push({
      target,
      path: normalizeTarget(target),
      heading: heading ? heading.trim() : undefined,
      alias: alias ? alias.trim() : undefined,
      raw: m[0],
      embed,
    })
  }
  return out
}

function splitOnce(s: string, sep: string): [string, string | undefined] {
  const i = s.indexOf(sep)
  if (i === -1) return [s, undefined]
  return [s.slice(0, i), s.slice(i + 1)]
}

export function parseHeadings(body: string): Heading[] {
  const out: Heading[] = []
  let fence: string | null = null
  const lines = body.split(/\r?\n/)
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    const fenceMatch = /^\s*(```+|~~~+)/.exec(line)
    if (fenceMatch) {
      if (!fence) fence = fenceMatch[1][0]
      else if (line.trim().startsWith(fence.repeat(3))) fence = null
      continue
    }
    if (fence) continue
    const m = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line)
    if (m) out.push({ level: m[1].length, text: m[2], line: i })
  }
  return out
}

export function parseInlineTags(body: string): string[] {
  const out = new Set<string>()
  const re = /(^|[\s(<])#([A-Za-z][\w/-]*)/g
  let m: RegExpExecArray | null
  while ((m = re.exec(body))) {
    const tag = m[2]
    if (/^\d+$/.test(tag)) continue
    out.add(tag)
  }
  return [...out]
}

export function parseTags(fm: Frontmatter, body: string): string[] {
  const set = new Set<string>()
  const raw = fm.tags ?? fm.tag
  if (typeof raw === 'string') {
    raw.split(/[,\s]+/).forEach((t) => t && set.add(t.replace(/^#/, '')))
  } else if (Array.isArray(raw)) {
    raw.forEach((t) => {
      if (typeof t === 'string') set.add(t.replace(/^#/, ''))
    })
  }
  parseInlineTags(body).forEach((t) => set.add(t))
  return [...set].filter(Boolean)
}

export function parseNote(path: string, content: string, modified = Date.now()): Note {
  const { fm, body } = splitFrontmatter(content)
  return {
    path,
    content,
    fm,
    body,
    title: noteTitle(path),
    tags: parseTags(fm, body),
    links: parseLinks(body),
    headings: parseHeadings(body),
    modified,
  }
}

/** map of lowercased names (full path without extension + basename) -> path */
export function buildTitleIndex(notes: Record<string, Note>): Map<string, string> {
  const index = new Map<string, string>()
  const list = Object.values(notes)
  // first pass: full paths (highest priority)
  for (const n of list) {
    const p = n.path.replace(/\.md$/i, '').toLowerCase()
    index.set(p, n.path)
  }
  // second pass: basenames / titles (do not overwrite path matches)
  for (const n of list) {
    const t = n.title.toLowerCase()
    if (!index.has(t)) index.set(t, n.path)
  }
  return index
}

export function resolveLink(index: Map<string, string>, target: string): string | null {
  if (!target) return null
  const norm = normalizeTarget(target).toLowerCase()
  if (index.has(norm)) return index.get(norm)!
  // try just the basename of the target
  const base = basename(norm)
  if (index.has(base)) return index.get(base)!
  return null
}

export function computeBacklinks(notes: Record<string, Note>): Record<string, Backlink[]> {
  const index = buildTitleIndex(notes)
  const result: Record<string, Backlink[]> = {}
  for (const note of Object.values(notes)) {
    for (const link of note.links) {
      const resolved = resolveLink(index, link.path || link.target)
      if (!resolved || resolved === note.path) continue
      const snippets = linkSnippets(note.body, link)
      const bucket = result[resolved] || (result[resolved] = [])
      const existing = bucket.find((b) => b.path === note.path)
      if (existing) existing.snippets.push(...snippets.filter((s) => !existing.snippets.includes(s)))
      else bucket.push({ path: note.path, title: note.title, snippets })
    }
  }
  return result
}

function linkSnippets(body: string, link: LinkRef): string[] {
  const lines = body.split(/\r?\n/)
  const needle = link.path ? normalizeTarget(link.path) : ''
  const out: string[] = []
  for (const line of lines) {
    if (!line.includes('[[')) continue
    const matches = line.match(WIKILINK_RE)
    if (!matches) continue
    const hit = matches.some((m) => {
      const inner = m.replace(/^!?\[\[|\]\]$/g, '')
      const target = normalizeTarget(splitOnce(inner, '|')[0].split('#')[0])
      return target.toLowerCase() === needle.toLowerCase()
    })
    if (hit) {
      const clean = plainSnippet(line)
      if (clean) out.push(clean.length > 180 ? `${clean.slice(0, 177)}…` : clean)
      if (out.length >= 3) break
    }
  }
  return out.length ? out : [link.raw]
}

/** strip markdown noise from a line so backlink snippets read like prose */
export function plainSnippet(line: string): string {
  return line
    .replace(/^\s*>\s?/, '')
    .replace(/^\s*[-*+]\s(\[[ xX]\]\s)?/, '')
    .replace(/!?\[\[([^\]|]*)(?:\|([^\]]*))?\]\]/g, (_m, target: string, alias?: string) => {
      if (alias) return alias
      const [path, heading] = String(target).split('#')
      const base = (path.split('/').pop() || path).replace(/\.md$/i, '')
      return heading ? `${base} › ${heading}` : base
    })
    .replace(/\*\*|__|~~|`/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

export function computeGraph(notes: Record<string, Note>, opts?: { folder?: string }): { nodes: import('../types').GraphNode[]; edges: import('../types').GraphEdge[] } {
  const index = buildTitleIndex(notes)
  const paths = Object.keys(notes).filter((p) => (opts?.folder ? dirname(p) === opts.folder : true))
  const nodeMap = new Map<string, import('../types').GraphNode>()
  for (const p of paths) {
    const n = notes[p]
    nodeMap.set(p, { id: p, label: n.title, tags: n.tags, degree: 0 })
  }
  const edges: import('../types').GraphEdge[] = []
  const seen = new Set<string>()
  for (const p of paths) {
    const note = notes[p]
    for (const link of note.links) {
      const target = resolveLink(index, link.path || link.target)
      if (!target || !nodeMap.has(target) || target === p) continue
      const key = p < target ? `${p}→${target}` : `${target}→${p}`
      if (seen.has(key)) continue
      seen.add(key)
      edges.push({ source: p, target })
      const a = nodeMap.get(p)!
      const b = nodeMap.get(target)!
      a.degree++
      b.degree++
    }
  }
  return { nodes: [...nodeMap.values()], edges }
}

export function wordCount(text: string): number {
  const body = splitFrontmatter(text).body
  const stripped = body
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/\[\[([^\]|]*\|)?([^\]]*)\]\]/g, '$2')
    .replace(/[#>*_`~|-]/g, ' ')
  const words = stripped.split(/\s+/).filter(Boolean)
  return words.length
}

export function excerpt(body: string, max = 220): string {
  const clean = splitFrontmatter(body).body
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/^---[\s\S]*?---/g, ' ')
    .replace(/[#>*_`~]/g, '')
    .replace(/\[\[([^\]|]*\|)?([^\]]*)\]\]/g, '$2')
    .replace(/\s+/g, ' ')
    .trim()
  return clean.length > max ? `${clean.slice(0, max - 1)}…` : clean
}

/** toggle a `- [ ]` checkbox in a markdown string at the given doc offset */
export function toggleTaskAt(content: string, offset: number): string {
  const before = content.slice(0, offset)
  const after = content.slice(offset)
  const m = /^\[([ xX])\]/.exec(after)
  if (!m) return content
  const isChecked = m[1].toLowerCase() === 'x'
  return `${before}[${isChecked ? ' ' : 'x'}]${after.slice(3)}`
}
