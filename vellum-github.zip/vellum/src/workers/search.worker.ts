/// <reference lib="webworker" />
import { SearchIndex } from '../lib/searchCore'
import type { SearchDoc } from '../types'

const index = new SearchIndex()

type InMessage =
  | { type: 'index'; docs: SearchDoc[] }
  | { type: 'upsert'; doc: SearchDoc }
  | { type: 'remove'; path: string }
  | { type: 'query'; id: number; q: string; limit?: number }

self.onmessage = (event: MessageEvent<InMessage>) => {
  const msg = event.data
  switch (msg.type) {
    case 'index': {
      index.clear()
      for (const doc of msg.docs) index.upsert(doc)
      ;(self as unknown as Worker).postMessage({ type: 'indexed', size: index.size })
      break
    }
    case 'upsert':
      index.upsert(msg.doc)
      break
    case 'remove':
      index.remove(msg.path)
      break
    case 'query': {
      const hits = index.query(msg.q, msg.limit ?? 40)
      ;(self as unknown as Worker).postMessage({ type: 'results', id: msg.id, hits })
      break
    }
  }
}
