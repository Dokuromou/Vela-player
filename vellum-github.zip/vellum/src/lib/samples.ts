/** Five-plus interconnected starter notes. Loaded on first launch so
 *  backlinks, Kanban databases and the knowledge graph all have content. */
export const SAMPLE_NOTES: { path: string; content: string }[] = [
  {
    path: 'Welcome to Vellum.md',
    content: `---
title: Welcome to Vellum
status: In Progress
tags: [start-here, meta]
date: 2026-11-19
---

# Welcome to Vellum

A **local-first** Markdown workspace. Your notes are plain \`.md\` files with YAML frontmatter — no lock-in, no plugins, no cloud required.

> [!tip] Start here
> Type \`/\` anywhere to insert a table, callout, task list or template. Type \`[[\` to link another note. Press \`⌘P\` (or \`Ctrl+P\`) for the command palette.

## What's in this vault

- [[Projects/Website Redesign]] — active project with tasks and a Kanban column
- [[Projects/Search Index]] — how the background indexer works
- [[Notes/Design System]] — the visual language shared with the website
- [[Notes/Knowledge Graph]] — why links beat folders
- [[Areas/Reading List]] — a checklist you can tick right in the editor
- [[Notes/Markdown Cheatsheet]] — everything this editor renders live

## Try it now

- [x] Open the graph view (top-right) and see how these notes connect
- [ ] Flip **Projects** to a Kanban board from the *Views* menu
- [ ] Press \`⌘⇧D\` to open today's daily note
- [ ] Click the checkbox on the left — it writes straight to the file

> [!note] Offline by default
> Everything runs in your browser. Open a real folder with the *Open folder* button and Vellum writes actual files to disk; otherwise it keeps a local vault in IndexedDB.

See you in [[Daily/2026-11-19]].
`,
  },
  {
    path: 'Projects/Website Redesign.md',
    content: `---
title: Website Redesign
status: In Progress
tags: [project, design]
date: 2026-11-04
due: 2026-12-12
owner: Ana
priority: High
---

# Website Redesign

Rebuild the marketing site around the [[Notes/Design System]]. Ship a fast, static-first experience that mirrors the speed of this notes app.

> [!info] North star
> A visitor should understand the product in under 8 seconds, on a phone, on 3G.

## Scope

| Area | Owner | State |
| --- | --- | --- |
| Hero + navigation | Ana | In progress |
| Pricing page | Beto | Not started |
| Docs theme | Chen | Done |
| Performance budget | Ana | Ongoing |

## Tasks

- [x] Audit current pages and analytics
- [x] Agree on type scale with [[Notes/Design System]]
- [ ] Draft new hero copy
- [ ] Build responsive navigation
- [ ] Lighthouse pass (> 95 in all categories)

## Decisions

- Sticky sidebar navigation, collapsing below 1024px.
- Warm paper and dark themes share the same tokens (see [[Notes/Design System]]).
- Related: [[Projects/Mobile App]] reuses this type scale.

## Open questions

> [!warning] Unresolved
> Do we keep the legacy blog URLs? Redirects would add ~40 lines to the edge config. Discuss in [[Daily/2026-11-19]].
`,
  },
  {
    path: 'Projects/Mobile App.md',
    content: `---
title: Mobile App
status: Backlog
tags: [project, mobile]
date: 2026-10-21
due: 2027-02-01
owner: Beto
priority: Medium
---

# Mobile App

A read-only companion app for the vault: browse notes, search offline, and capture quick ideas. Should feel like [[Projects/Website Redesign]] on a phone.

## Rough plan

- [ ] Decide between React Native and a PWA shell
- [ ] Reuse the [[Notes/Knowledge Graph]] layout at small sizes
- [ ] Offline search over a synced copy of the vault

> [!note] Blocker
> Waiting on the sync design in [[Projects/Vault Sync]] before we commit to a storage model.

## Notes

The mobile team keeps asking for the typography tokens from [[Notes/Design System]].
`,
  },
  {
    path: 'Projects/Search Index.md',
    content: `---
title: Search Index
status: Done
tags: [project, engineering]
date: 2026-10-02
due: 2026-10-30
owner: Chen
priority: High
---

# Search Index

Instant search that never blocks the UI. Every note is tokenised in a **Web Worker** so typing stays smooth even on large vaults.

## Design

1. Main thread posts note text to the worker whenever a note changes (debounced).
2. Worker builds an inverted index: \`token -> { path: termFrequency }\`.
3. Queries return ranked paths plus a snippet centred on the first hit.
4. Title matches and prefix matches are boosted above body matches.

- [x] Inverted index with prefix scoring
- [x] Snippet extraction
- [x] Falls back to main-thread search if workers are unavailable
- [ ] Add fuzzy/subsequence matching for typos

> [!tip] Why a worker?
> Indexing a 5,000-note vault takes ~200 ms. On the main thread that is a dropped frame; off it, nobody notices.

Related: [[Notes/Knowledge Graph]], [[Notes/Markdown Cheatsheet]].
`,
  },
  {
    path: 'Projects/Vault Sync.md',
    content: `---
title: Vault Sync
status: In Progress
tags: [project, engineering, sync]
date: 2026-11-10
due: 2027-01-15
owner: Chen
priority: High
---

# Vault Sync

Optional end-to-end encrypted sync for vaults that outgrow a single device. Local-first always: the file on disk stays the source of truth.

## Principles

- Offline edits always win locally and merge later.
- Conflicts produce a visible diff, never a silent overwrite.
- No proprietary format — plain Markdown + YAML frontmatter.

## Steps

- [x] Choose conflict representation (sibling files with \` (conflict)\` suffix)
- [ ] CRDT-free three-way merge on frontmatter keys
- [ ] Background sync status in the status bar
- [ ] Document the threat model

> [!danger] Careful
> Never touch files while a sync is mid-write. Use the atomic write path from [[Projects/Search Index]] indexing queue.

Depends on [[Projects/Search Index]]; unblocks [[Projects/Mobile App]].
`,
  },
  {
    path: 'Notes/Design System.md',
    content: `---
title: Design System
status: In Progress
tags: [design, ui, reference]
date: 2026-09-18
---

# Design System

Shared tokens for every Vellum surface, including [[Projects/Website Redesign]].

## Themes

Three themes ship by default, all driven by CSS custom properties:

| Theme | Background | Accent | Use |
| --- | --- | --- | --- |
| Dark | #0d0f14 | #7c9cff | Default, low light |
| Light | #ffffff | #3b62e8 | Daylight, projectors |
| Warm Paper | #f7efe1 | #b06a34 | Long writing sessions |

## Type scale

- Display 1.92rem — note titles
- Heading 1.24rem — sections
- Body 1rem / 1.78 line height
- Mono 0.88em — code and tables

## Rules

1. Borders are 1px and always use \`--line\`. Never pure black or pure white.
2. Accent colour is for interaction only: links, focus, selection.
3. Density over decoration — whitespace is the design.

> [!tip] Contrast
> Body text must stay above 7:1 contrast in every theme. Checked against [[Projects/Website Redesign]] mockups.

Tags used across the vault: #design #ui
`,
  },
  {
    path: 'Notes/Knowledge Graph.md',
    content: `---
title: Knowledge Graph
status: Done
tags: [meta, reference]
date: 2026-11-16
---

# Knowledge Graph

Folders are a filing cabinet; links are a conversation. Vellum indexes every \`[[wiki-link]]\` and draws a force-directed graph from them.

## How it works

- Each note is a node, each link is an edge.
- Node size scales with degree (incoming + outgoing links).
- Node colour comes from the note's first tag, so clusters are visible at a glance.
- Local graph shows only the neighbours of the note you are reading.

Click a node to open the note. Drag to pin it, scroll to zoom, drag the background to pan.

## Why bother

> [!info] Emergence
> A link you add today becomes a backlink you discover tomorrow. That is the whole trick — see [[Projects/Search Index]] for how the index makes it instant.

Try it: [[Welcome to Vellum]] → [[Notes/Design System]] → [[Projects/Website Redesign]] all sit in one cluster, while [[Areas/Reading List]] floats on its own.
`,
  },
  {
    path: 'Notes/Markdown Cheatsheet.md',
    content: `---
title: Markdown Cheatsheet
status: Done
tags: [reference, markdown]
date: 2026-08-30
---

# Markdown Cheatsheet

Everything below renders live in the editor. Put the cursor on a line to see its raw Markdown.

## Text

**Bold**, *italic*, ~~strikethrough~~, \`inline code\`, and a [link](https://example.com).

## Headings

\`#\` H1 · \`##\` H2 · \`###\` H3 · \`####\` H4

## Lists

- Bullet one
- Bullet two
  - Nested bullet
1. Ordered
2. Ordered again

## Tasks

- [x] A finished task
- [ ] An open task
- [ ] Click me — the file changes on disk

## Callouts

> [!note] Note
> Neutral information.

> [!tip] Tip
> A shortcut worth learning: \`⌘P\` opens the palette.

> [!warning] Warning
> Something to be careful about.

> [!danger] Danger
> Destructive or irreversible.

## Tables

| Column | Meaning | Example |
| --- | --- | --- |
| status | Kanban column | In Progress |
| tags | Colours in the graph | design |
| date | Sort key | 2026-11-19 |

## Code

\`\`\`ts
export function greet(name: string) {
  return \`Hello, \${name}\`
}
\`\`\`

## Divider

---

Links: [[Projects/Search Index]] · [[Notes/Design System]]
`,
  },
  {
    path: 'Areas/Reading List.md',
    content: `---
title: Reading List
status: In Progress
tags: [reading, personal]
date: 2026-11-17
---

# Reading List

## Now

- [ ] *The Humane Interface* — Jef Raskin
- [x] *Thinking in Systems* — Donella Meadows
- [ ] *How Buildings Learn* — Stewart Brand

## Next

- [ ] *The Timeless Way of Building* — Christopher Alexander
- [ ] *Shape Up* — Ryan Singer

> [!note] Why these
> Each one feeds the thinking in [[Projects/Website Redesign]] and [[Notes/Design System]] — systems, patterns, and how things age.

Quotes worth keeping:

> The most important thing about a system is what it does, not what it says it does.

Mentioned in [[Daily/2026-11-19]].
`,
  },
  {
    path: 'Daily/2026-11-19.md',
    content: `---
date: 2026-11-19
tags: [daily]
status: In Progress
---

# Thursday, November 19

## Focus

- [x] Review [[Projects/Website Redesign]] hero copy
- [ ] Sketch the local graph layout for [[Notes/Knowledge Graph]]
- [ ] Answer the open question about blog redirects

## Log

- 09:10 Standup — sync work in [[Projects/Vault Sync]] is blocked on merge edge cases.
- 11:00 Paired with Ana on the type scale from [[Notes/Design System]].
- 15:30 Indexed the vault; search latency is ~4 ms.

## Notes

> [!tip] Keep moving
> Two small ships beat one big one. Tomorrow: pricing page.

Tomorrow: [[Daily/2026-11-20]] · Back to [[Welcome to Vellum]]
`,
  },
  {
    path: 'Daily/2026-11-18.md',
    content: `---
date: 2026-11-18
tags: [daily]
status: Done
---

# Wednesday, November 18

## Focus

- [x] Resync [[Projects/Mobile App]] backlog with Beto
- [x] Finish the inverted index notes in [[Projects/Search Index]]

## Log

- Spent the morning on [[Notes/Markdown Cheatsheet]] rendering bugs.
- Ended the day reading from [[Areas/Reading List]].

Next: [[Daily/2026-11-19]]
`,
  },
]

export const DAILY_TEMPLATE = `---
date: {{date}}
tags: [daily]
status: In Progress
---

# {{prettyDate}}

## Focus

- [ ] 

## Log

- 

## Notes

> [!tip] Intention
> What is the one thing worth finishing today?

Yesterday: {{prev}} · Tomorrow: {{next}}
`
