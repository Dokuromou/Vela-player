export function cls(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ')
}

export function relativeTime(ts: number): string {
  const diff = Date.now() - ts
  if (diff < 45_000) return 'just now'
  const mins = Math.round(diff / 60_000)
  if (mins < 60) return `${mins}m ago`
  const hours = Math.round(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.round(hours / 24)
  if (days < 30) return `${days}d ago`
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

export function debounce<A extends unknown[]>(fn: (...args: A) => void, wait: number) {
  let timer: ReturnType<typeof setTimeout> | null = null
  const wrapped = (...args: A) => {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      timer = null
      fn(...args)
    }, wait)
  }
  wrapped.flush = (...args: A) => {
    if (timer) clearTimeout(timer)
    timer = null
    fn(...args)
  }
  wrapped.cancel = () => {
    if (timer) clearTimeout(timer)
    timer = null
  }
  return wrapped
}

/** Simple subsequence fuzzy matcher, returns score (higher = better) or -1. */
export function fuzzyScore(query: string, target: string): number {
  if (!query) return 1
  const q = query.toLowerCase()
  const t = target.toLowerCase()
  if (t === q) return 1000
  if (t.startsWith(q)) return 700 - t.length
  const direct = t.indexOf(q)
  if (direct >= 0) return 500 - direct - t.length * 0.1
  // subsequence with word-boundary bonus
  let ti = 0
  let score = 0
  let streak = 0
  for (let qi = 0; qi < q.length; qi++) {
    const ch = q[qi]
    let found = -1
    while (ti < t.length) {
      if (t[ti] === ch) {
        found = ti
        break
      }
      ti++
    }
    if (found === -1) return -1
    const boundary = found === 0 || /[\s/\-_.#]/.test(t[found - 1])
    score += 10 + (boundary ? 12 : 0) + streak * 3
    streak = boundary ? 2 : streak + 1
    ti = found + 1
  }
  return score - t.length * 0.15
}

export function isMac(): boolean {
  if (typeof navigator === 'undefined') return false
  return /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent)
}

export const MOD_KEY = isMac() ? '⌘' : 'Ctrl'

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n)
}

/** local YYYY-MM-DD */
export function toISODate(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
}

export function fromISODate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, (m || 1) - 1, d || 1)
}

export function todayISO(): string {
  return toISODate(new Date())
}

export function prettyDate(d: Date): string {
  return d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })
}

export function shortDate(s: unknown): string {
  if (!s) return ''
  const str = typeof s === 'string' ? s : s instanceof Date ? toISODate(s) : String(s)
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(str)
  if (!m) return str
  return `${m[2]}/${m[3]}/${m[1].slice(2)}`
}

export function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v))
}

export function hashString(s: string): number {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return Math.abs(h)
}

const TAG_PALETTE = [
  '#7c9cff',
  '#35c48a',
  '#e9a13b',
  '#ef6b6b',
  '#b184f5',
  '#3fc0d8',
  '#f07bb0',
  '#9ad14b',
  '#f58f5a',
  '#6aa6f8',
]

export function tagColor(tag: string): string {
  return TAG_PALETTE[hashString(tag) % TAG_PALETTE.length]
}

export function plural(n: number, word: string, pluralWord?: string): string {
  return `${n} ${n === 1 ? word : pluralWord || `${word}s`}`
}

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string))
}
