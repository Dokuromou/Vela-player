import { EditorView } from '@codemirror/view'

const views = new Map<number, EditorView>()

export function registerView(pane: number, view: EditorView): void {
  views.set(pane, view)
}

export function unregisterView(pane: number, view: EditorView): void {
  if (views.get(pane) === view) views.delete(pane)
}

export function getView(pane = 0): EditorView | null {
  return views.get(pane) ?? null
}

export function insertAtCursor(text: string, cursorOffset?: number, pane = 0): void {
  const view = views.get(pane)
  if (!view) return
  const { from, to } = view.state.selection.main
  const anchor = cursorOffset === undefined ? from + text.length : from + cursorOffset
  view.dispatch({
    changes: { from, to, insert: text },
    selection: { anchor },
    scrollIntoView: true,
  })
  view.focus()
}

export function wrapSelection(before: string, after = before, pane = 0): void {
  const view = views.get(pane)
  if (!view) return
  const { from, to } = view.state.selection.main
  const selected = view.state.doc.sliceString(from, to)
  view.dispatch({
    changes: { from, to, insert: `${before}${selected}${after}` },
    selection: { anchor: from + before.length, head: from + before.length + selected.length },
  })
  view.focus()
}

export function toggleTaskOnLine(pane = 0): void {
  const view = views.get(pane)
  if (!view) return
  const pos = view.state.selection.main.head
  const line = view.state.doc.lineAt(pos)
  const text = line.text
  const task = /^(\s*)([-*+])\s+\[([ xX])\]/.exec(text)
  if (task) {
    const bracket = line.from + task[0].indexOf('[') + 1
    const checked = task[3].toLowerCase() === 'x'
    view.dispatch({ changes: { from: bracket, to: bracket + 1, insert: checked ? ' ' : 'x' } })
    return
  }
  // not a task yet → turn the line into one
  const indent = /^\s*/.exec(text)?.[0] ?? ''
  view.dispatch({
    changes: { from: line.from, to: line.from + indent.length, insert: `${indent}- [ ] ` },
  })
  view.focus()
}

/** Put the caret on line 1 and scroll there — reveals the (normally collapsed) frontmatter. */
export function focusDocStart(pane = 0): void {
  const view = views.get(pane)
  if (!view) return
  view.dispatch({ selection: { anchor: 0 }, effects: EditorView.scrollIntoView(0, { y: 'start', yMargin: 70 }) })
  view.focus()
}

export function scrollToHeadingText(level: number, text: string, pane = 0): boolean {
  const view = views.get(pane)
  if (!view) return false
  const doc = view.state.doc
  const needle = text.trim().toLowerCase()
  for (let i = 1; i <= doc.lines; i++) {
    const lineText = doc.line(i).text
    const m = /^(#{1,6})\s+(.*?)\s*$/.exec(lineText)
    if (m && m[1].length === level && m[2].toLowerCase() === needle) {
      const pos = doc.line(i).from
      view.dispatch({
        selection: { anchor: pos },
        effects: EditorView.scrollIntoView(pos, { y: 'start', yMargin: 80 }),
      })
      view.focus()
      return true
    }
  }
  return false
}

/** replace the current selection with markdown and keep the caret sensible */
export function replaceSelection(text: string, pane = 0): void {
  const view = views.get(pane)
  if (!view) return
  const { from, to } = view.state.selection.main
  view.dispatch({ changes: { from, to, insert: text }, selection: { anchor: from + text.length } })
  view.focus()
}
