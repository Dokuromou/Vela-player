package com.vela.player.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val year: String?,
    val genre: String?,
    val trackNumber: Int?,
    val art: ByteArray?,
    val addedAt: Long = System.currentTimeMillis(),
    val favorite: Boolean = false
)

@Entity(tableName = "mixes")
data class Mix(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Newline-separated content URIs; these are SAF-granted, not file paths. */
    val trackUris: String
)
