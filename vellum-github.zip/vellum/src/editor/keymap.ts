import { EditorSelection, type ChangeSpec } from '@codemirror/state'
import { EditorView, type KeyBinding } from '@codemirror/view'
import { toggleTaskOnLine } from './registry'

/** Enter inside a list continues the list (tasks stay tasks, ordered numbers bump). */
function continueList(view: EditorView): boolean {
  const { state } = view
  const sel = state.selection.main
  if (!sel.empty) return false
  const line = state.doc.lineAt(sel.head)
  const text = line.text
  const task = /^(\s*)([-*+])\s+\[([ xX])\]\s+/.exec(text)
  const bullet = /^(\s*)([-*+])\s+/.exec(text)
  const ordered = /^(\s*)(\d+)[.)]\s+/.exec(text)
  const hit = task || bullet || ordered
  if (!hit) return false
  const indent = hit[1]
  const prefixLen = hit[0].length
  if (sel.head < line.from + prefixLen) return false
  const rest = text.slice(prefixLen)

  // empty item → drop the marker and break out of the list
  if (!rest.trim() && sel.head === line.to) {
    view.dispatch({
      changes: { from: line.from, to: line.to, insert: '' },
      selection: { anchor: line.from },
    })
    return true
  }

  let nextPrefix: string
  if (task) nextPrefix = `${indent}${task[2]} [ ] `
  else if (bullet) nextPrefix = `${indent}${bullet[2]} `
  else nextPrefix = `${indent}${parseInt(ordered![2], 10) + 1}. `

  view.dispatch({
    changes: { from: sel.head, insert: `\n${nextPrefix}` },
    selection: { anchor: sel.head + 1 + nextPrefix.length },
    scrollIntoView: true,
  })
  return true
}

function indentLines(view: EditorView, dir: 1 | -1): boolean {
  const { state } = view
  const changes: ChangeSpec[] = []
  for (const range of state.selection.ranges) {
    const first = state.doc.lineAt(range.from).number
    const last = state.doc.lineAt(range.to).number
    for (let i = first; i <= last; i++) {
      const line = state.doc.line(i)
      if (dir === 1) {
        changes.push({ from: line.from, insert: '  ' })
      } else {
        const m = /^(\t| {1,2})/.exec(line.text)
        if (m) changes.push({ from: line.from, to: line.from + m[0].length, insert: '' })
      }
    }
  }
  if (!changes.length) return true
  view.dispatch({ changes, scrollIntoView: true })
  return true
}

/** Wrap the selection, or insert a pair and place the caret inside. */
export function wrapMarker(view: EditorView, marker: string): boolean {
  const { state } = view
  const changes: ChangeSpec[] = []
  const ranges: { anchor: number; head: number }[] = []
  let delta = 0
  for (const range of state.selection.ranges) {
    const text = state.doc.sliceString(range.from, range.to)
    if (!text) {
      changes.push({ from: range.from, insert: marker + marker })
      ranges.push({ anchor: range.from + marker.length + delta, head: range.from + marker.length + delta })
      delta += marker.length * 2
    } else {
      changes.push({ from: range.from, to: range.to, insert: `${marker}${text}${marker}` })
      ranges.push({ anchor: range.from + marker.length + delta, head: range.from + marker.length + text.length + delta })
      delta += marker.length * 2
    }
  }
  view.dispatch({
    changes,
    selection: EditorSelection.create(ranges.map((r) => EditorSelection.range(r.anchor, r.head))),
  })
  view.focus()
  return true
}

export function markdownKeymap(): KeyBinding[] {
  return [
    { key: 'Enter', run: continueList },
    { key: 'Tab', run: (view) => indentLines(view, 1) },
    { key: 'Shift-Tab', run: (view) => indentLines(view, -1) },
    { key: 'Mod-b', run: (view) => wrapMarker(view, '**') },
    { key: 'Mod-i', run: (view) => wrapMarker(view, '*') },
    { key: 'Mod-e', run: (view) => wrapMarker(view, '`') },
    {
      key: 'Mod-Enter',
      run: (view) => {
        const pos = view.state.selection.main.head
        const line = view.state.doc.lineAt(pos)
        const task = /^\s*[-*+]\s+\[([ xX])\]/.exec(line.text)
        if (task) {
          const bracket = line.from + line.text.indexOf('[') + 1
          const checked = task[1].toLowerCase() === 'x'
          view.dispatch({ changes: { from: bracket, to: bracket + 1, insert: checked ? ' ' : 'x' } })
          return true
        }
        return false
      },
    },
  ]
}
