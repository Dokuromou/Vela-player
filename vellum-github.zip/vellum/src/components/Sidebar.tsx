import { useEffect, useMemo, useState } from 'react'
import { Cpu, FileText, Search, X, Zap } from 'lucide-react'
import type { SearchHit } from '../types'
import { getSearchService } from '../lib/searchClient'
import { useStore } from '../store/useStore'
import { cls } from '../lib/utils'
import { FileTree } from './FileTree'
import { MiniCalendar } from './Calendar'

export function Sidebar() {
  const [query, setQuery] = useState('')
  const [hits, setHits] = useState<SearchHit[]>([])
  const [pending, setPending] = useState(false)
  const openNote = useStore((s) => s.openNote)
  const notes = useStore((s) => s.notes)
  const indexInfo = useStore((s) => s.indexInfo)
  const activePath = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ?? null
  })

  useEffect(() => {
    const q = query.trim()
    if (!q) {
      setHits([])
      setPending(false)
      return
    }
    setPending(true)
    let cancelled = false
    const timer = setTimeout(() => {
      void getSearchService()
        .query(q, 24)
        .then((results) => {
          if (cancelled) return
          setHits(results)
          setPending(false)
        })
    }, 90)
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [query, notes])

  const total = Object.keys(notes).length
  const results = useMemo(() => hits.map((h) => ({ ...h, title: h.title })), [hits])

  return (
    <aside className="flex w-[274px] shrink-0 flex-col border-r border-line bg-panel">
      <div className="flex items-center gap-1.5 border-b border-line px-2.5 py-2">
        <div className="flex flex-1 items-center gap-1.5 rounded-lg border border-line bg-elev px-2 py-[5px] focus-within:border-accent/50">
          <Search size={13} className="shrink-0 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && results[0]) {
                openNote(results[0].path)
                setQuery('')
              }
              if (e.key === 'Escape') setQuery('')
            }}
            placeholder="Search notes…"
            className="w-full bg-transparent text-[12.5px] text-ink outline-none placeholder:text-muted/80"
          />
          {query ? (
            <button type="button" onClick={() => setQuery('')} className="text-muted hover:text-ink">
              <X size={12} />
            </button>
          ) : null}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto py-1">
        {query.trim() ? (
          <div className="px-1.5">
            <div className="flex items-center justify-between px-1.5 pb-1 pt-1">
              <span className="text-[10px] font-semibold uppercase tracking-[0.09em] text-muted">
                {pending ? 'Searching…' : `${results.length} result${results.length === 1 ? '' : 's'}`}
              </span>
              <span className="flex items-center gap-1 text-[9.5px] text-muted">
                {indexInfo.worker ? <Zap size={9} /> : <Cpu size={9} />}
                {indexInfo.worker ? 'worker index' : 'local index'}
              </span>
            </div>
            {results.map((hit) => (
              <button
                key={hit.path}
                type="button"
                onClick={() => {
                  openNote(hit.path)
                  setQuery('')
                }}
                className={cls(
                  'mb-0.5 block w-full rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-elev',
                  hit.path === activePath && 'bg-accent-soft',
                )}
              >
                <div className="flex items-center gap-1.5">
                  <FileText size={12} className="shrink-0 text-muted" />
                  <span className="truncate text-[12.5px] font-medium text-ink">{hit.title}</span>
                </div>
                <div className="mt-0.5 line-clamp-2 pl-[18px] text-[11px] leading-snug text-muted">{hit.snippet}</div>
              </button>
            ))}
            {!results.length && !pending && (
              <div className="px-2 py-6 text-center text-[12px] text-muted">No notes match “{query}”.</div>
            )}
          </div>
        ) : (
          <FileTree activePath={activePath} onOpen={(path) => openNote(path)} />
        )}
      </div>

      <div className="shrink-0 space-y-1.5 border-t border-line p-2">
        <MiniCalendar />
        <div className="flex items-center justify-between px-1 text-[10px] text-muted">
          <span>{total} notes · offline ready</span>
          <span className="flex items-center gap-1">
            {indexInfo.worker ? <Zap size={9} className="text-accent" /> : <Cpu size={9} />}
            {indexInfo.worker ? 'worker' : 'local'}
          </span>
        </div>
      </div>
    </aside>
  )
}
