import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ChevronDown,
  ChevronRight,
  Columns3,
  Copy,
  CornerUpLeft,
  Download,
  FileText,
  Link2,
  MoreHorizontal,
  PanelRight,
  Pencil,
  Plus,
  Share2,
  Trash2,
  X,
} from 'lucide-react'
import type { Note } from '../types'
import { basename, computeBacklinks, dirname, wordCount } from '../lib/markdown'
import { cls, relativeTime, shortDate } from '../lib/utils'
import { useStore } from '../store/useStore'
import { downloadFile } from '../lib/vault'
import { focusDocStart } from '../editor/registry'
import { MarkdownEditor } from './MarkdownEditor'
import { Divider, EmptyState, IconButton, MenuItem, Popover } from './ui'

/* ------------------------------------------------------------------ tabs */
function TabBar({ paneIndex }: { paneIndex: number }) {
  const pane = useStore((s) => s.panes[paneIndex])
  const panes = useStore((s) => s.panes)
  const activePane = useStore((s) => s.activePane)
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const closeTab = useStore((s) => s.closeTab)
  const splitPane = useStore((s) => s.splitPane)
  const closePane = useStore((s) => s.closePane)
  const createNote = useStore((s) => s.createNote)
  const setActivePane = useStore((s) => s.setActivePane)

  if (!pane) return null

  return (
    <div
      className={cls(
        'flex h-9 shrink-0 items-center gap-1 border-b border-line px-1.5',
        activePane === paneIndex ? 'bg-panel' : 'bg-panel/60',
      )}
    >
      <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto no-scrollbar">
        {pane.tabs.map((path) => {
          const note = notes[path]
          const active = pane.active === path
          return (
            <div
              key={path}
              onClick={() => {
                setActivePane(paneIndex)
                openNote(path, paneIndex)
              }}
              className={cls(
                'group flex max-w-[190px] shrink-0 cursor-pointer items-center gap-1.5 rounded-md border px-2 py-[3px] text-[12px] transition-colors',
                active
                  ? 'border-line bg-elev text-ink'
                  : 'border-transparent text-muted hover:bg-elev/70 hover:text-ink',
              )}
              title={path}
            >
              <FileText size={11} className={active ? 'text-accent' : 'text-muted'} />
              <span className="truncate">{note?.title ?? basename(path)}</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  closeTab(paneIndex, path)
                }}
                className="rounded p-0.5 text-muted opacity-0 hover:bg-panel hover:text-ink group-hover:opacity-100"
              >
                <X size={11} />
              </button>
            </div>
          )
        })}
        <button
          type="button"
          onClick={() => createNote('')}
          title="New note"
          className="shrink-0 rounded p-1 text-muted hover:bg-elev hover:text-ink"
        >
          <Plus size={13} />
        </button>
      </div>
      <div className="flex shrink-0 items-center gap-0.5">
        {panes.length < 2 ? <IconButton icon={PanelRight} label="Split pane" onClick={splitPane} size={13} /> : (
          <IconButton icon={X} label="Close this pane" onClick={() => closePane(paneIndex)} size={13} />
        )}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------- note header */
const STATUS_COLORS: Record<string, string> = {
  backlog: 'var(--muted)',
  todo: 'var(--muted)',
  'in progress': '#e9a13b',
  doing: '#e9a13b',
  done: '#35c48a',
  complete: '#35c48a',
  blocked: '#ef6b6b',
}
const STATUS_CYCLE = ['Backlog', 'In Progress', 'Done']

function statusColor(value: string): string {
  return STATUS_COLORS[value.toLowerCase()] || 'var(--accent)'
}

function NoteHeader({ note }: { note: Note }) {
  const renameNote = useStore((s) => s.renameNote)
  const deleteNote = useStore((s) => s.deleteNote)
  const duplicateNote = useStore((s) => s.duplicateNote)
  const setFrontmatter = useStore((s) => s.setFrontmatter)
  const setView = useStore((s) => s.setView)
  const setGraphOpen = useStore((s) => s.setGraphOpen)
  const [draft, setDraft] = useState(note.title)
  const inputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    setDraft(note.title)
  }, [note.path, note.title])

  const folder = dirname(note.path)
  const words = useMemo(() => wordCount(note.content), [note.content])
  const tasks = useMemo(() => {
    const done = (note.body.match(/^\s*[-*+]\s\[[xX]\]/gm) || []).length
    const open = (note.body.match(/^\s*[-*+]\s\[ \]/gm) || []).length
    return { done, open, total: done + open }
  }, [note.body])

  const commitTitle = () => {
    if (draft.trim() && draft.trim() !== note.title) renameNote(note.path, draft.trim())
    else setDraft(note.title)
  }

  const props: { key: string; label: string; value: string }[] = []
  const known = new Set(['title', 'tags', 'tag'])
  for (const [key, raw] of Object.entries(note.fm)) {
    if (known.has(key)) continue
    if (raw === null || raw === undefined) continue
    const value = Array.isArray(raw) ? raw.join(', ') : String(raw)
    if (!value) continue
    props.push({ key, label: key, value })
  }

  return (
    <div className="pane-header shrink-0 border-b border-line px-6 pt-3 pb-2.5">
      <div className="flex items-center gap-1.5 text-[11px] text-muted">
        <button
          type="button"
          onClick={() => setView({ mode: 'table', folder })}
          className="max-w-[38%] shrink-0 truncate rounded px-1 py-0.5 hover:bg-elev hover:text-ink"
        >
          {folder || 'vault root'}
        </button>
        <span className="shrink-0 opacity-50">/</span>
        <span className="min-w-0 flex-1 truncate text-ink/70">{basename(note.path)}</span>
        <span className="ml-auto flex shrink-0 items-center gap-2 whitespace-nowrap">
          <span>{words} words</span>
          {tasks.total > 0 && (
            <span className="flex items-center gap-1.5" title={`${tasks.done} of ${tasks.total} tasks done`}>
              <span className="h-1 w-14 overflow-hidden rounded-full bg-line">
                <span
                  className="block h-full rounded-full bg-accent transition-all"
                  style={{ width: `${Math.round((tasks.done / tasks.total) * 100)}%` }}
                />
              </span>
              {tasks.done}/{tasks.total}
            </span>
          )}
          <span className="hidden sm:inline">{relativeTime(note.modified)}</span>
        </span>
      </div>

      <div className="mt-1 flex items-start gap-2">
        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commitTitle}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              inputRef.current?.blur()
            }
            if (e.key === 'Escape') {
              setDraft(note.title)
              inputRef.current?.blur()
            }
          }}
          spellCheck={false}
          className="min-w-0 flex-1 bg-transparent text-[25px] font-bold leading-tight tracking-[-0.02em] text-ink outline-none"
        />
        <div className="flex shrink-0 items-center gap-0.5 pt-1">
          <IconButton icon={Share2} label="Local graph" size={14} onClick={() => setGraphOpen(true, note.path)} />
          <IconButton icon={Columns3} label="Folder as database" size={14} onClick={() => setView({ mode: 'kanban', folder })} />
          <Popover
            align="right"
            width={212}
            trigger={() => (
              <button type="button" className="inline-flex size-8 items-center justify-center rounded-lg text-muted hover:bg-elev hover:text-ink" title="Note actions">
                <MoreHorizontal size={15} />
              </button>
            )}
          >
            {(close) => (
              <>
                <MenuItem
                  icon={Copy}
                  onClick={() => {
                    void navigator.clipboard?.writeText(`[[${note.path.replace(/\.md$/i, '')}]]`)
                    close()
                  }}
                >
                  Copy wiki-link
                </MenuItem>
                <MenuItem
                  icon={Copy}
                  onClick={() => {
                    duplicateNote(note.path)
                    close()
                  }}
                >
                  Duplicate note
                </MenuItem>
                <MenuItem
                  icon={Download}
                  onClick={() => {
                    downloadFile(note.path, note.content)
                    close()
                  }}
                >
                  Export .md
                </MenuItem>
                <Divider />
                <MenuItem
                  icon={Trash2}
                  danger
                  onClick={() => {
                    close()
                    if (window.confirm(`Delete “${note.title}”? This removes the file.`)) deleteNote(note.path)
                  }}
                >
                  Delete note
                </MenuItem>
              </>
            )}
          </Popover>
        </div>
      </div>

      {(props.length > 0 || note.tags.length > 0) && (
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
          {props.map((p) => {
            const isStatus = p.key === 'status'
            return (
              <button
                key={p.key}
                type="button"
                onClick={() => {
                  if (!isStatus) return
                  const idx = STATUS_CYCLE.findIndex((s) => s.toLowerCase() === p.value.toLowerCase())
                  const next = STATUS_CYCLE[(idx + 1) % STATUS_CYCLE.length]
                  setFrontmatter(note.path, 'status', next)
                }}
                title={isStatus ? 'Click to move to the next column' : undefined}
                className={cls(
                  'inline-flex items-center gap-1.5 rounded-md border border-line bg-elev px-1.5 py-[2px] text-[11px]',
                  isStatus ? 'cursor-pointer hover:border-accent/40' : 'cursor-default',
                )}
              >
                <span className="text-muted">{p.label}</span>
                <span className="flex items-center gap-1 font-medium text-ink">
                  {isStatus ? <span className="size-1.5 rounded-full" style={{ background: statusColor(p.value) }} /> : null}
                  {/^\d{4}-\d{2}-\d{2}/.test(p.value) ? shortDate(p.value) : p.value}
                </span>
              </button>
            )
          })}
          {note.tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center rounded-md px-1.5 py-[2px] text-[11px] font-medium"
              style={{ background: 'var(--tag-bg)', color: 'var(--tag-ink)' }}
            >
              #{tag}
            </span>
          ))}
          {note.fm.status === undefined && (
            <button
              type="button"
              onClick={() => setFrontmatter(note.path, 'status', 'Backlog')}
              className="rounded-md border border-dashed border-line px-1.5 py-[2px] text-[11px] text-muted hover:border-accent/50 hover:text-ink"
            >
              + status
            </button>
          )}
          <button
            type="button"
            onClick={() => focusDocStart()}
            title="Edit raw frontmatter (shows the YAML block)"
            className="inline-flex items-center gap-1 rounded-md px-1.5 py-[2px] text-[11px] text-muted hover:bg-elev hover:text-ink"
          >
            <Pencil size={10} /> properties
          </button>
        </div>
      )}

      <div className="mt-1 flex items-center gap-2">
        <span className="flex items-center gap-1 text-[10.5px] text-muted">
          <Link2 size={10} />
          {note.links.length} link{note.links.length === 1 ? '' : 's'}
        </span>
        <span className="text-[10.5px] text-muted">·</span>
        <span className="text-[10.5px] text-muted">{note.headings.length} headings</span>
      </div>
    </div>
  )
}

/* ---------------------------------------------------------- backlinks foot */
function BacklinksFooter({ path }: { path: string }) {
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const [open, setOpen] = useState(false)
  const backlinks = useMemo(() => computeBacklinks(notes)[path] || [], [notes, path])

  if (!backlinks.length) return null

  return (
    <div className="shrink-0 border-t border-line bg-panel">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-2 px-6 py-1.5 text-[11.5px] text-muted hover:text-ink"
      >
        {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
        <CornerUpLeft size={12} />
        <span className="shrink-0 whitespace-nowrap font-medium">
          {backlinks.length} backlink{backlinks.length === 1 ? '' : 's'}
        </span>
        <span className="min-w-0 flex-1 truncate text-left opacity-70">{backlinks.map((b) => b.title).join(' · ')}</span>
      </button>
      {open && (
        <div className="max-h-[180px] overflow-y-auto px-4 pb-2">
          {backlinks.map((b) => (
            <button
              key={b.path}
              type="button"
              onClick={() => openNote(b.path)}
              className="mb-1 block w-full rounded-lg border border-line bg-elev px-2.5 py-1.5 text-left hover:border-accent/40"
            >
              <div className="flex items-center gap-1.5 text-[12px] font-medium text-ink">
                <FileText size={11} className="text-muted" />
                {b.title}
              </div>
              {b.snippets.slice(0, 2).map((s, i) => (
                <div key={i} className="mt-0.5 line-clamp-2 pl-[17px] text-[11px] leading-snug text-muted">
                  {s}
                </div>
              ))}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ pane */
export function EditorPane({ paneIndex }: { paneIndex: number }) {
  const pane = useStore((s) => s.panes[paneIndex])
  const note = useStore((s) => (pane?.active ? s.notes[pane.active] ?? null : null))
  const setActivePane = useStore((s) => s.setActivePane)
  const openNote = useStore((s) => s.openNote)
  const notes = useStore((s) => s.notes)
  const setPalette = useStore((s) => s.setPalette)

  const recent = useMemo(() => Object.values(notes).slice(0, 4), [notes])

  return (
    <div
      className="pane-shell flex min-w-0 flex-1 flex-col bg-app"
      onMouseDown={() => setActivePane(paneIndex)}
    >
      <TabBar paneIndex={paneIndex} />
      {note ? (
        <>
          <NoteHeader note={note} />
          <MarkdownEditor key={note.path} paneIndex={paneIndex} path={note.path} content={note.content} />
          <BacklinksFooter path={note.path} />
        </>
      ) : (
        <div className="flex-1">
          <EmptyState
            icon={Pencil}
            title="No note open"
            hint="Pick a note from the sidebar, or press ⌘P to search your vault."
            action={
              <div className="mt-2 flex flex-wrap justify-center gap-1.5">
                {recent.slice(0, 3).map((n) => (
                  <button
                    key={n.path}
                    type="button"
                    onClick={() => openNote(n.path)}
                    className="rounded-lg border border-line bg-panel px-2 py-1 text-[11.5px] text-ink/80 hover:border-accent/40 hover:text-ink"
                  >
                    {n.title}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setPalette(true, 'files')}
                  className="rounded-lg border border-line bg-panel px-2 py-1 text-[11.5px] text-accent hover:border-accent/40"
                >
                  Search notes…
                </button>
              </div>
            }
          />
        </div>
      )}
    </div>
  )
}
