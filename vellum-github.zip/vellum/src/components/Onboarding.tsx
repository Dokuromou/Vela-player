import { BookOpen, Command, FolderOpen, HardDrive, Link2, Moon, Share2, Sparkles, Sun, X } from 'lucide-react'
import { THEMES } from '../lib/theme'
import { MOD_KEY } from '../lib/utils'
import { useStore } from '../store/useStore'
import { Kbd } from './ui'

export function Onboarding() {
  const dismiss = useStore((s) => s.dismissOnboarding)
  const openFolder = useStore((s) => s.openFolder)
  const theme = useStore((s) => s.theme)
  const setTheme = useStore((s) => s.setTheme)
  const setPalette = useStore((s) => s.setPalette)

  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center bg-black/50 p-4 backdrop-blur-[3px]">
      <div className="w-full max-w-[520px] overflow-hidden rounded-2xl border border-line bg-elev card-shadow anim-pop">
        <div className="relative border-b border-line bg-panel px-6 py-5">
          <button
            type="button"
            onClick={dismiss}
            className="absolute right-3 top-3 rounded-lg p-1.5 text-muted hover:bg-elev hover:text-ink"
            title="Dismiss"
          >
            <X size={15} />
          </button>
          <div className="flex items-center gap-2.5">
            <div className="flex size-9 items-center justify-center rounded-xl bg-accent text-[16px] font-black text-app">V</div>
            <div>
              <h1 className="text-[17px] font-bold tracking-[-0.02em]">Welcome to Vellum</h1>
              <p className="text-[12px] text-muted">Local-first Markdown notes. No plugins, no accounts, no cloud.</p>
            </div>
          </div>
        </div>

        <div className="space-y-3 px-6 py-4">
          <Feature icon={Link2} title="Wiki-links & backlinks" text="Type [[ anywhere to link a note or a #heading. Incoming links appear at the bottom of every note." />
          <Feature icon={Share2} title="Knowledge graph" text="A live force-directed view of how your notes connect, colour-coded by tag." />
          <Feature icon={Sparkles} title="Databases from frontmatter" text="Any folder becomes a table or Kanban board using status, tags and date — no plugins." />
          <Feature icon={Command} title="Everything is keyboard-first" text="Command palette, slash menu, daily notes and split panes are one shortcut away." />
        </div>

        <div className="flex items-center gap-2 border-t border-line px-6 py-3">
          <span className="text-[11px] text-muted">Theme</span>
          <div className="flex items-center gap-1.5">
            {THEMES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTheme(t.id)}
                className="flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[11.5px] transition-colors"
                style={{
                  borderColor: theme === t.id ? 'var(--accent)' : 'var(--line)',
                  background: theme === t.id ? 'var(--accent-soft)' : 'transparent',
                }}
              >
                {t.id === 'dark' ? <Moon size={11} /> : t.id === 'light' ? <Sun size={11} /> : <BookOpen size={11} />}
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t border-line bg-panel px-6 py-3.5">
          <button
            type="button"
            onClick={() => {
              dismiss()
              void openFolder()
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-[12.5px] font-semibold text-app hover:opacity-90"
          >
            <FolderOpen size={13} /> Open a local folder
          </button>
          <button
            type="button"
            onClick={dismiss}
            className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-[12.5px] font-medium text-ink hover:border-accent/50"
          >
            <HardDrive size={13} /> Explore the sample vault
          </button>
          <button
            type="button"
            onClick={() => {
              dismiss()
              setPalette(true, 'files')
            }}
            className="ml-auto flex items-center gap-1.5 text-[11px] text-muted hover:text-ink"
          >
            <Kbd>{MOD_KEY}P</Kbd> to search
          </button>
        </div>
      </div>
    </div>
  )
}

function Feature({ icon: Icon, title, text }: { icon: typeof Link2; title: string; text: string }) {
  return (
    <div className="flex gap-3">
      <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg border border-line bg-panel text-accent">
        <Icon size={14} />
      </div>
      <div>
        <div className="text-[12.5px] font-semibold text-ink">{title}</div>
        <div className="text-[11.5px] leading-relaxed text-muted">{text}</div>
      </div>
    </div>
  )
}
