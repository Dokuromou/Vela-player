/** Minimal promise-based IndexedDB helpers used for the local vault fallback
 *  (and for persisting the File System Access directory handle / UI prefs). */

const DB_NAME = 'vellum-vault'
const DB_VERSION = 1
export const STORE_NOTES = 'notes'
export const STORE_KV = 'kv'

let dbPromise: Promise<IDBDatabase> | null = null

export function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE_NOTES)) {
        const notes = db.createObjectStore(STORE_NOTES, { keyPath: 'path' })
        notes.createIndex('modified', 'modified')
      }
      if (!db.objectStoreNames.contains(STORE_KV)) {
        db.createObjectStore(STORE_KV, { keyPath: 'key' })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
  return dbPromise
}

function tx<T>(storeName: string, mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDB().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const transaction = db.transaction(storeName, mode)
        const store = transaction.objectStore(storeName)
        const req = fn(store)
        req.onsuccess = () => resolve(req.result as T)
        req.onerror = () => reject(req.error)
      }),
  )
}

export interface StoredNote {
  path: string
  content: string
  modified: number
}

export function idbAllNotes(): Promise<StoredNote[]> {
  return tx<StoredNote[]>(STORE_NOTES, 'readonly', (s) => s.getAll() as IDBRequest<StoredNote[]>)
}

export function idbPutNote(note: StoredNote): Promise<IDBValidKey> {
  return tx(STORE_NOTES, 'readwrite', (s) => s.put(note))
}

export function idbDeleteNote(path: string): Promise<undefined> {
  return tx(STORE_NOTES, 'readwrite', (s) => s.delete(path))
}

export function idbClearNotes(): Promise<undefined> {
  return tx(STORE_NOTES, 'readwrite', (s) => s.clear())
}

export async function kvGet<T = unknown>(key: string): Promise<T | null> {
  const row = await tx<{ key: string; value: T } | undefined>(STORE_KV, 'readonly', (s) => s.get(key))
  return row ? row.value : null
}

export async function kvSet(key: string, value: unknown): Promise<void> {
  await tx(STORE_KV, 'readwrite', (s) => s.put({ key, value }))
}

export async function kvDelete(key: string): Promise<void> {
  await tx(STORE_KV, 'readwrite', (s) => s.delete(key))
}
