import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  // relative asset URLs: works from /, from /<repo>/ on GitHub Pages, or from a file:// bundle
  base: './',
  plugins: [react(), tailwindcss()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    cors: true,
  },
  worker: { format: 'es' },
  build: { target: 'es2020', chunkSizeWarningLimit: 1600 },
})
