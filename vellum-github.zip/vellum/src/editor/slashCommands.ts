import {
  Braces,
  Calendar,
  CheckSquare,
  Code2,
  Columns3,
  FileText,
  Heading1,
  Heading2,
  Heading3,
  List,
  Minus,
  MessageSquareQuote,
  NotebookPen,
  Quote,
  Sparkles,
  Table,
  Wand2,
  type LucideIcon,
} from 'lucide-react'
import { todayISO } from '../lib/utils'

export interface Insertion {
  text: string
  /** offset from the start of the inserted text where the caret should land */
  cursor?: number
}

export interface SlashCommand {
  id: string
  label: string
  hint: string
  icon: LucideIcon
  keywords: string
  group: 'Blocks' | 'Lists' | 'Templates' | 'Insert'
  make: () => Insertion
}

/** place the caret at a marker inside the inserted text (marker is kept) */
const caret = (text: string, marker: string): Insertion => {
  const at = text.indexOf(marker)
  return { text, cursor: at === -1 ? text.length : at }
}

export const SLASH_COMMANDS: SlashCommand[] = [
  {
    id: 'table',
    label: 'Table',
    hint: '3×3 Markdown table',
    icon: Table,
    keywords: 'table grid rows columns',
    group: 'Blocks',
    make: () => caret('| Column | Column | Column |\n| --- | --- | --- |\n|  |  |  |\n|  |  |  |\n', '| Column'),
  },
  {
    id: 'callout-note',
    label: 'Callout · Note',
    hint: 'Neutral callout block',
    icon: MessageSquareQuote,
    keywords: 'callout note info box',
    group: 'Blocks',
    make: () => caret('> [!note] Title\n> Write something here.\n', 'Title'),
  },
  {
    id: 'callout-tip',
    label: 'Callout · Tip',
    hint: 'Green highlighted tip',
    icon: Sparkles,
    keywords: 'callout tip hint success',
    group: 'Blocks',
    make: () => caret('> [!tip] Title\n> A useful suggestion.\n', 'Title'),
  },
  {
    id: 'callout-warning',
    label: 'Callout · Warning',
    hint: 'Amber warning block',
    icon: MessageSquareQuote,
    keywords: 'callout warning caution danger',
    group: 'Blocks',
    make: () => caret('> [!warning] Careful\n> Something to watch out for.\n', 'Careful'),
  },
  {
    id: 'code',
    label: 'Code block',
    hint: 'Fenced code',
    icon: Code2,
    keywords: 'code block fence snippet',
    group: 'Blocks',
    make: () => ({ text: '```ts\n\n```\n', cursor: 6 }),
  },
  {
    id: 'quote',
    label: 'Quote',
    hint: 'Blockquote',
    icon: Quote,
    keywords: 'quote blockquote citation',
    group: 'Blocks',
    make: () => ({ text: '> ' }),
  },
  {
    id: 'divider',
    label: 'Divider',
    hint: 'Horizontal rule',
    icon: Minus,
    keywords: 'divider hr rule separator line',
    group: 'Blocks',
    make: () => ({ text: '---\n' }),
  },
  {
    id: 'task',
    label: 'Task list',
    hint: 'Checklist item',
    icon: CheckSquare,
    keywords: 'task todo checkbox checklist',
    group: 'Lists',
    make: () => ({ text: '- [ ] ' }),
  },
  {
    id: 'bullet',
    label: 'Bullet list',
    hint: 'Unordered list',
    icon: List,
    keywords: 'bullet list unordered',
    group: 'Lists',
    make: () => ({ text: '- ' }),
  },
  {
    id: 'h1',
    label: 'Heading 1',
    hint: 'Section title',
    icon: Heading1,
    keywords: 'heading h1 title',
    group: 'Blocks',
    make: () => ({ text: '# ' }),
  },
  {
    id: 'h2',
    label: 'Heading 2',
    hint: 'Sub-section',
    icon: Heading2,
    keywords: 'heading h2 subtitle',
    group: 'Blocks',
    make: () => ({ text: '## ' }),
  },
  {
    id: 'h3',
    label: 'Heading 3',
    hint: 'Small heading',
    icon: Heading3,
    keywords: 'heading h3',
    group: 'Blocks',
    make: () => ({ text: '### ' }),
  },
  {
    id: 'template-meeting',
    label: 'Template · Meeting notes',
    hint: 'Attendees, agenda, actions',
    icon: NotebookPen,
    keywords: 'template meeting notes agenda',
    group: 'Templates',
    make: () =>
      caret(
        `---
date: ${todayISO()}
tags: [meeting]
status: In Progress
---

# Meeting — ${new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}

**Attendees:** 

## Agenda

- 

## Notes

- 

## Actions

- [ ] 
`,
        'Attendees:** ',
      ),
  },
  {
    id: 'template-project',
    label: 'Template · Project note',
    hint: 'Frontmatter, scope, tasks',
    icon: Columns3,
    keywords: 'template project kanban status',
    group: 'Templates',
    make: () =>
      caret(
        `---
title: New project
status: Backlog
tags: [project]
date: ${todayISO()}
owner: 
priority: Medium
---

# New project

> [!info] Goal
> One sentence on why this exists.

## Scope

- 

## Tasks

- [ ] 
`,
        'title: New project',
      ),
  },
  {
    id: 'template-decision',
    label: 'Template · Decision log',
    hint: 'Context, options, outcome',
    icon: FileText,
    keywords: 'template decision adr log',
    group: 'Templates',
    make: () =>
      caret(
        `## Decision — title

**Context:** 

**Options**

1. 
2. 

**Outcome**

- 

**Consequences**

- 
`,
        'title',
      ),
  },
  {
    id: 'template-daily',
    label: 'Template · Daily log',
    hint: 'Focus, log, notes',
    icon: Calendar,
    keywords: 'template daily journal log today',
    group: 'Templates',
    make: () =>
      caret(
        `## Focus

- [ ] 

## Log

- 

## Notes

> [!tip] Intention
> 
`,
        'Intention',
      ),
  },
  {
    id: 'date',
    label: "Insert today's date",
    hint: todayISO(),
    icon: Calendar,
    keywords: 'date today now',
    group: 'Insert',
    make: () => ({ text: todayISO() }),
  },
  {
    id: 'frontmatter',
    label: 'Frontmatter properties',
    hint: 'status · tags · date',
    icon: Braces,
    keywords: 'frontmatter yaml properties metadata',
    group: 'Insert',
    make: () => caret(`---\nstatus: Backlog\ntags: [ ]\ndate: ${todayISO()}\n---\n`, 'Backlog'),
  },
  {
    id: 'wikilink',
    label: 'Wiki-link',
    hint: 'Link to another note',
    icon: Wand2,
    keywords: 'link wikilink reference',
    group: 'Insert',
    make: () => ({ text: '[[' }),
  },
]

export const SLASH_GROUPS: SlashCommand['group'][] = ['Blocks', 'Lists', 'Templates', 'Insert']
