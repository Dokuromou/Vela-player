import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { LucideIcon } from 'lucide-react'
import { cls } from '../lib/utils'

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="rounded border border-line bg-panel px-1 py-[1px] font-sans text-[10px] font-medium leading-[15px] text-muted">
      {children}
    </kbd>
  )
}

interface IconButtonProps {
  icon: LucideIcon
  label: string
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void
  active?: boolean
  shortcut?: string
  size?: number
  className?: string
  disabled?: boolean
}

export function IconButton({ icon: Icon, label, onClick, active, shortcut, size = 15, className, disabled }: IconButtonProps) {
  return (
    <button
      type="button"
      title={shortcut ? `${label}  ${shortcut}` : label}
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      onClick={onClick}
      className={cls(
        'inline-flex size-8 items-center justify-center rounded-lg border border-transparent transition-colors',
        active ? 'bg-accent-soft text-accent' : 'text-muted hover:bg-elev hover:text-ink',
        disabled && 'opacity-40',
        className,
      )}
    >
      <Icon size={size} strokeWidth={1.9} />
    </button>
  )
}

interface PopoverProps {
  trigger: (open: boolean) => ReactNode
  children: (close: () => void) => ReactNode
  align?: 'left' | 'right'
  width?: number
  className?: string
}

export function Popover({ trigger, children, align = 'left', width = 240, className }: PopoverProps) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (!open) return
    const onDown = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false)
    }
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <div ref={ref} className={cls('relative', className)}>
      <div onClick={() => setOpen((o) => !o)}>{trigger(open)}</div>
      {open && (
        <div
          className={cls(
            'absolute z-50 mt-1.5 overflow-hidden rounded-xl border border-line bg-elev p-1 card-shadow anim-in',
            align === 'right' ? 'right-0' : 'left-0',
          )}
          style={{ width }}
        >
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  )
}

export function MenuItem({
  icon: Icon,
  children,
  onClick,
  shortcut,
  danger,
  active,
}: {
  icon?: LucideIcon
  children: ReactNode
  onClick?: () => void
  shortcut?: string
  danger?: boolean
  active?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cls(
        'flex w-full items-center gap-2.5 rounded-lg px-2 py-[6px] text-left text-[13px] transition-colors',
        danger ? 'text-[#ef6b6b] hover:bg-[#ef6b6b]/10' : 'text-ink/90 hover:bg-accent-soft',
        active && 'bg-accent-soft text-accent',
      )}
    >
      {Icon ? <Icon size={14} className={danger ? '' : 'text-muted'} /> : <span className="w-[14px]" />}
      <span className="flex-1 truncate">{children}</span>
      {shortcut ? <span className="text-[10px] text-muted">{shortcut}</span> : null}
    </button>
  )
}

export function MenuLabel({ children }: { children: ReactNode }) {
  return <div className="px-2 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-[0.09em] text-muted">{children}</div>
}

export function Divider() {
  return <div className="my-1 h-px bg-line" />
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T
  options: { id: T; label: string; icon?: LucideIcon }[]
  onChange: (id: T) => void
}) {
  return (
    <div className="inline-flex rounded-lg border border-line bg-panel p-[2px]">
      {options.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          type="button"
          onClick={() => onChange(id)}
          className={cls(
            'inline-flex items-center gap-1.5 rounded-[6px] px-2 py-1 text-[12px] font-medium transition-colors',
            value === id ? 'bg-elev text-ink shadow-sm' : 'text-muted hover:text-ink',
          )}
        >
          {Icon ? <Icon size={12} /> : null}
          {label}
        </button>
      ))}
    </div>
  )
}

export function EmptyState({ icon: Icon, title, hint, action }: { icon: LucideIcon; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-2 p-8 text-center">
      <div className="flex size-11 items-center justify-center rounded-xl border border-line bg-panel text-muted">
        <Icon size={19} />
      </div>
      <div className="text-sm font-medium text-ink">{title}</div>
      {hint ? <div className="max-w-[280px] text-[12px] leading-relaxed text-muted">{hint}</div> : null}
      {action}
    </div>
  )
}
