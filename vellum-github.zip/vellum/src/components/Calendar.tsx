import { useMemo, useState } from 'react'
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react'
import { useStore } from '../store/useStore'
import { cls, pad2, toISODate, todayISO } from '../lib/utils'

const WEEKDAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S']

export function MiniCalendar() {
  const notes = useStore((s) => s.notes)
  const dailyFolder = useStore((s) => s.dailyFolder)
  const openDaily = useStore((s) => s.openDaily)
  const activePath = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ?? null
  })
  const today = todayISO()
  const [viewDate, setViewDate] = useState(() => {
    const d = new Date()
    return new Date(d.getFullYear(), d.getMonth(), 1)
  })

  const dailyPaths = useMemo(() => {
    const set = new Set<string>()
    for (const path of Object.keys(notes)) {
      if (dailyFolder && path.startsWith(`${dailyFolder}/`)) {
        set.add(path.slice(dailyFolder.length + 1).replace(/\.md$/i, ''))
      }
    }
    return set
  }, [notes, dailyFolder])

  const cells = useMemo(() => {
    const year = viewDate.getFullYear()
    const month = viewDate.getMonth()
    const first = new Date(year, month, 1)
    const offset = (first.getDay() + 6) % 7 // monday-first
    const daysInMonth = new Date(year, month + 1, 0).getDate()
    const list: (Date | null)[] = []
    for (let i = 0; i < offset; i++) list.push(null)
    for (let d = 1; d <= daysInMonth; d++) list.push(new Date(year, month, d))
    while (list.length % 7 !== 0) list.push(null)
    return list
  }, [viewDate])

  const monthLabel = viewDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })
  const shift = (delta: number) => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + delta, 1))

  return (
    <div className="rounded-xl border border-line bg-elev p-2">
      <div className="mb-1.5 flex items-center justify-between">
        <div className="flex items-center gap-1.5 pl-1 text-[11.5px] font-semibold capitalize text-ink/90">
          <CalendarDays size={12} className="text-muted" />
          {monthLabel}
        </div>
        <div className="flex items-center gap-0.5">
          <button type="button" onClick={() => shift(-1)} className="rounded p-1 text-muted hover:bg-panel hover:text-ink" title="Previous month">
            <ChevronLeft size={12} />
          </button>
          <button
            type="button"
            onClick={() => {
              const d = new Date()
              setViewDate(new Date(d.getFullYear(), d.getMonth(), 1))
              openDaily(today)
            }}
            className="rounded px-1 py-0.5 text-[10px] font-medium text-muted hover:bg-panel hover:text-ink"
            title="Go to today"
          >
            today
          </button>
          <button type="button" onClick={() => shift(1)} className="rounded p-1 text-muted hover:bg-panel hover:text-ink" title="Next month">
            <ChevronRight size={12} />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-[2px] text-center">
        {WEEKDAYS.map((d, i) => (
          <div key={i} className="pb-0.5 text-[9.5px] font-semibold uppercase text-muted">
            {d}
          </div>
        ))}
        {cells.map((date, i) => {
          if (!date) return <div key={`e${i}`} />
          const iso = `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`
          const has = dailyPaths.has(iso)
          const isToday = iso === today
          const isActive = activePath === `${dailyFolder}/${iso}.md`
          return (
            <button
              key={iso}
              type="button"
              onClick={() => openDaily(iso)}
              title={has ? `${iso} — open note` : `${iso} — create note`}
              className={cls(
                'relative flex h-[22px] items-center justify-center rounded-md text-[11px] transition-colors',
                isToday
                  ? 'bg-accent font-semibold text-app'
                  : isActive
                    ? 'bg-accent-soft text-accent'
                    : has
                      ? 'text-ink hover:bg-accent-soft'
                      : 'text-muted hover:bg-accent-soft hover:text-ink',
              )}
            >
              {date.getDate()}
              {has && !isToday ? (
                <span className="absolute bottom-[2px] left-1/2 size-[3px] -translate-x-1/2 rounded-full bg-accent" />
              ) : null}
            </button>
          )
        })}
      </div>
      <button
        type="button"
        onClick={() => openDaily(today)}
        className="mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-line bg-panel py-1 text-[11px] font-medium text-ink/80 hover:border-accent/40 hover:text-ink"
      >
        Open today · {toISODate(new Date())}
      </button>
    </div>
  )
}
