import { useMemo, useState } from 'react'
import { ArrowDown, ArrowUp, Columns3, FilePlus2, Folder, Rows3, Table2, X } from 'lucide-react'
import type { Note, ViewMode } from '../types'
import { dirname, excerpt } from '../lib/markdown'
import { cls, shortDate } from '../lib/utils'
import { useStore } from '../store/useStore'
import { Segmented } from './ui'

const CANONICAL = ['Backlog', 'Todo', 'In Progress', 'Blocked', 'Done']
const STATUS_DOT: Record<string, string> = {
  backlog: 'var(--muted)',
  todo: 'var(--muted)',
  'in progress': '#e9a13b',
  doing: '#e9a13b',
  blocked: '#ef6b6b',
  done: '#35c48a',
}

function fmString(note: Note, key: string): string {
  const v = note.fm[key]
  if (v === undefined || v === null) return ''
  if (Array.isArray(v)) return v.map(String).join(', ')
  return String(v)
}

function statusOf(note: Note): string {
  const v = fmString(note, 'status')
  return v || 'Backlog'
}

export function DatabaseViews() {
  const view = useStore((s) => s.view)
  const notes = useStore((s) => s.notes)
  const setView = useStore((s) => s.setView)
  const openNote = useStore((s) => s.openNote)
  const setFrontmatter = useStore((s) => s.setFrontmatter)
  const createNote = useStore((s) => s.createNote)
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 }>({ key: 'title', dir: 1 })
  const [dragOver, setDragOver] = useState<string | null>(null)

  const folder = view?.folder ?? ''
  const mode: ViewMode = view?.mode ?? 'table'
  const folders = useMemo(() => {
    const set = new Set<string>([''])
    for (const p of Object.keys(notes)) set.add(dirname(p))
    return [...set].sort((a, b) => (a === '' ? -1 : b === '' ? 1 : a.localeCompare(b)))
  }, [notes])

  const rows = useMemo(() => {
    const list = Object.values(notes).filter((n) => dirname(n.path) === folder)
    const sorted = [...list]
    sorted.sort((a, b) => {
      if (sort.key === 'title') return a.title.localeCompare(b.title) * sort.dir
      const av = a.fm[sort.key]
      const bv = b.fm[sort.key]
      const as = Array.isArray(av) ? av.join(',') : av === undefined ? '' : String(av)
      const bs = Array.isArray(bv) ? bv.join(',') : bv === undefined ? '' : String(bv)
      return as.localeCompare(bs) * sort.dir
    })
    return sorted
  }, [notes, folder, sort])

  const columns = useMemo(() => {
    const keys: string[] = []
    const priority = ['status', 'tags', 'date', 'due', 'owner', 'priority']
    for (const key of priority) {
      if (rows.some((r) => r.fm[key] !== undefined)) keys.push(key)
    }
    for (const row of rows) {
      for (const key of Object.keys(row.fm)) {
        if (key === 'title' || keys.includes(key)) continue
        keys.push(key)
      }
    }
    return keys
  }, [rows])

  const statuses = useMemo(() => {
    const found = new Set<string>()
    for (const r of rows) if (r.fm.status !== undefined) found.add(statusOf(r))
    const ordered = CANONICAL.filter((s) => found.has(s) || ['Backlog', 'In Progress', 'Done'].includes(s))
    for (const s of found) if (!ordered.includes(s)) ordered.push(s)
    return ordered
  }, [rows])

  if (!view) return null

  const toggleSort = (key: string) => {
    setSort((prev) => (prev.key === key ? { key, dir: prev.dir === 1 ? -1 : 1 } : { key, dir: 1 }))
  }

  const addNote = (status?: string) => {
    const body = `---\nstatus: ${status || 'Backlog'}\ntags: []\ndate: ${new Date().toISOString().slice(0, 10)}\n---\n\n# Untitled\n\n`
    createNote(folder, 'Untitled', body)
    setView(null)
  }

  return (
    <div className="flex min-w-0 flex-1 flex-col bg-app">
      <div className="flex h-12 shrink-0 flex-wrap items-center gap-2 border-b border-line px-4">
        <div className="flex items-center gap-1.5 text-[13px] font-semibold text-ink">
          <Folder size={14} className="text-accent" />
          <select
            value={folder}
            onChange={(e) => setView({ mode, folder: e.target.value })}
            className="max-w-[220px] cursor-pointer rounded-md border border-transparent bg-transparent py-0.5 pr-1 text-[13px] font-semibold text-ink outline-none hover:border-line"
          >
            {folders.map((f) => (
              <option key={f || 'root'} value={f}>
                {f || 'vault root'}
              </option>
            ))}
          </select>
        </div>
        <span className="rounded-md border border-line bg-panel px-1.5 py-0.5 text-[10.5px] text-muted">{rows.length} notes</span>
        <div className="ml-2">
          <Segmented
            value={mode}
            onChange={(m) => setView({ mode: m, folder })}
            options={[
              { id: 'table' as ViewMode, label: 'Table', icon: Table2 },
              { id: 'kanban' as ViewMode, label: 'Kanban', icon: Columns3 },
            ]}
          />
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => addNote()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-line bg-elev px-2 py-1 text-[12px] text-ink/85 hover:border-accent/40 hover:text-ink"
          >
            <FilePlus2 size={13} /> New note
          </button>
          <button
            type="button"
            onClick={() => setView(null)}
            className="inline-flex size-8 items-center justify-center rounded-lg text-muted hover:bg-elev hover:text-ink"
            title="Close database view"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      {mode === 'table' ? (
        <div className="min-h-0 flex-1 overflow-auto p-4">
          <div className="min-w-[720px] overflow-hidden rounded-xl border border-line bg-panel">
            <table className="w-full border-collapse text-left text-[12.5px]">
              <thead>
                <tr className="border-b border-line bg-elev/60">
                  <th className="w-[34%] px-3 py-2 font-semibold text-muted">
                    <button type="button" onClick={() => toggleSort('title')} className="inline-flex items-center gap-1 hover:text-ink">
                      Note
                      {sort.key === 'title' ? sort.dir === 1 ? <ArrowUp size={11} /> : <ArrowDown size={11} /> : null}
                    </button>
                  </th>
                  {columns.map((key) => (
                    <th key={key} className="px-3 py-2 font-semibold text-muted">
                      <button type="button" onClick={() => toggleSort(key)} className="inline-flex items-center gap-1 hover:text-ink">
                        {key}
                        {sort.key === key ? sort.dir === 1 ? <ArrowUp size={11} /> : <ArrowDown size={11} /> : null}
                      </button>
                    </th>
                  ))}
                  <th className="w-[28%] px-3 py-2 font-semibold text-muted">Preview</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((note) => (
                  <tr key={note.path} className="group border-b border-line/70 last:border-b-0 hover:bg-elev/50">
                    <td className="px-3 py-1.5">
                      <button type="button" onClick={() => openNote(note.path)} className="truncate text-left font-medium text-ink hover:text-accent">
                        {note.title}
                      </button>
                    </td>
                    {columns.map((key) => (
                      <td key={key} className="px-3 py-1.5 align-middle">
                        <Cell note={note} field={key} statuses={statuses} onChange={(v) => setFrontmatter(note.path, key, v)} />
                      </td>
                    ))}
                    <td className="max-w-[280px] truncate px-3 py-1.5 text-muted">{excerpt(note.body, 90)}</td>
                  </tr>
                ))}
                {!rows.length && (
                  <tr>
                    <td colSpan={columns.length + 2} className="px-3 py-10 text-center text-[12px] text-muted">
                      No notes in this folder yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <p className="mt-2 px-1 text-[11px] text-muted">
            Values come from YAML frontmatter — edit a status cell and the file on disk changes.
          </p>
        </div>
      ) : (
        <div className="min-h-0 flex-1 overflow-x-auto overflow-y-hidden p-4">
          <div className="flex h-full min-w-max gap-3">
            {statuses.map((status) => {
              const cards = rows.filter((r) => statusOf(r) === status)
              return (
                <div
                  key={status}
                  onDragOver={(e) => {
                    e.preventDefault()
                    setDragOver(status)
                  }}
                  onDragLeave={() => setDragOver((s) => (s === status ? null : s))}
                  onDrop={(e) => {
                    e.preventDefault()
                    const path = e.dataTransfer.getData('text/plain')
                    if (path) setFrontmatter(path, 'status', status)
                    setDragOver(null)
                  }}
                  className={cls(
                    'flex h-full w-[264px] shrink-0 flex-col rounded-xl border bg-panel',
                    dragOver === status ? 'border-accent/60 bg-accent-soft/40' : 'border-line',
                  )}
                >
                  <div className="flex items-center gap-1.5 px-2.5 py-2">
                    <span className="size-2 rounded-full" style={{ background: STATUS_DOT[status.toLowerCase()] || 'var(--accent)' }} />
                    <span className="text-[12px] font-semibold text-ink">{status}</span>
                    <span className="rounded border border-line px-1 text-[10px] text-muted">{cards.length}</span>
                    <button
                      type="button"
                      onClick={() => addNote(status)}
                      className="ml-auto rounded p-1 text-muted hover:bg-elev hover:text-ink"
                      title={`New note in ${status}`}
                    >
                      <FilePlus2 size={12} />
                    </button>
                  </div>
                  <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto px-2 pb-2">
                    {cards.map((note) => (
                      <div
                        key={note.path}
                        draggable
                        onDragStart={(e) => {
                          e.dataTransfer.setData('text/plain', note.path)
                          e.dataTransfer.effectAllowed = 'move'
                        }}
                        onClick={() => openNote(note.path)}
                        className="cursor-grab rounded-lg border border-line bg-elev p-2 shadow-sm transition-colors hover:border-accent/40 active:cursor-grabbing"
                      >
                        <div className="text-[12.5px] font-medium leading-snug text-ink">{note.title}</div>
                        <div className="mt-1 flex flex-wrap items-center gap-1">
                          {note.tags.slice(0, 3).map((t) => (
                            <span
                              key={t}
                              className="rounded px-1 py-[1px] text-[9.5px] font-medium"
                              style={{ background: 'var(--tag-bg)', color: 'var(--tag-ink)' }}
                            >
                              #{t}
                            </span>
                          ))}
                          {note.fm.date ? <span className="ml-auto text-[9.5px] text-muted">{shortDate(note.fm.date)}</span> : null}
                        </div>
                      </div>
                    ))}
                    {!cards.length && (
                      <div className="rounded-lg border border-dashed border-line px-2 py-4 text-center text-[11px] text-muted">
                        Drop a card here
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
            {!statuses.length && (
              <div className="flex items-center gap-2 text-[12px] text-muted">
                <Rows3 size={14} /> No frontmatter status found — add <code className="font-mono">status:</code> to a note.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function Cell({
  note,
  field,
  statuses,
  onChange,
}: {
  note: Note
  field: string
  statuses: string[]
  onChange: (value: string) => void
}) {
  const raw = note.fm[field]
  const value = fmString(note, field)

  if (field === 'status') {
    const options = [...new Set([...statuses, value || 'Backlog'])]
    return (
      <div className="inline-flex items-center gap-1.5">
        <span className="size-1.5 shrink-0 rounded-full" style={{ background: STATUS_DOT[(value || 'backlog').toLowerCase()] || 'var(--accent)' }} />
        <select
          value={value || 'Backlog'}
          onChange={(e) => onChange(e.target.value)}
          className="cursor-pointer rounded border border-transparent bg-transparent py-0.5 pr-1 text-[12px] text-ink outline-none hover:border-line focus:border-accent/50"
        >
          {options.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      </div>
    )
  }

  if (field === 'tags') {
    const tags = Array.isArray(raw) ? raw.map(String) : value ? value.split(/[,\s]+/).filter(Boolean) : []
    if (!tags.length) return <span className="text-muted">—</span>
    return (
      <div className="flex flex-wrap gap-1">
        {tags.map((t) => (
          <span
            key={t}
            className="rounded px-1 py-[1px] text-[10px] font-medium"
            style={{ background: 'var(--tag-bg)', color: 'var(--tag-ink)' }}
          >
            #{t}
          </span>
        ))}
      </div>
    )
  }

  if (!value) return <span className="text-muted">—</span>
  if (/^\d{4}-\d{2}-\d{2}/.test(value)) return <span className="text-ink/80">{shortDate(value)}</span>
  if (field === 'priority') {
    const color = /high/i.test(value) ? '#ef6b6b' : /med/i.test(value) ? '#e9a13b' : '#35c48a'
    return (
      <span className="inline-flex items-center gap-1 text-ink/80">
        <span className="size-1.5 rounded-full" style={{ background: color }} />
        {value}
      </span>
    )
  }
  return <span className="truncate text-ink/80">{value}</span>
}
