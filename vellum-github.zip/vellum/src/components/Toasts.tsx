import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react'
import { useStore } from '../store/useStore'

const ICONS = { info: Info, success: CheckCircle2, error: AlertTriangle }

export function Toasts() {
  const toasts = useStore((s) => s.toasts)
  const dismiss = useStore((s) => s.dismissToast)

  return (
    <div className="pointer-events-none fixed bottom-9 right-3 z-[70] flex w-[300px] flex-col gap-1.5">
      {toasts.map((toast) => {
        const Icon = ICONS[toast.kind]
        return (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-start gap-2 rounded-xl border border-line bg-elev px-2.5 py-2 card-shadow anim-in"
          >
            <Icon
              size={14}
              className={toast.kind === 'error' ? 'mt-[1px] shrink-0 text-[#ef6b6b]' : toast.kind === 'success' ? 'mt-[1px] shrink-0 text-[#35c48a]' : 'mt-[1px] shrink-0 text-accent'}
            />
            <span className="flex-1 text-[12px] leading-snug text-ink/90">{toast.text}</span>
            <button type="button" onClick={() => dismiss(toast.id)} className="text-muted hover:text-ink">
              <X size={12} />
            </button>
          </div>
        )
      })}
    </div>
  )
}
