package com.vela.player

import android.app.Application
import android.content.ContentResolver
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import android.media.audiofx.Equalizer
import com.vela.player.data.Mix
import com.vela.player.data.Track
import com.vela.player.data.VelaDatabase
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlayerViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = VelaDatabase.get(application).dao()
    private val prefs = application.getSharedPreferences("vela-playback", 0)
    val tracks: StateFlow<List<Track>> = dao.allTracks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val mixes: StateFlow<List<Mix>> = dao.mixes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _currentUri = MutableStateFlow<String?>(null)
    val currentUri = _currentUri.asStateFlow()
    private val _playing = MutableStateFlow(false)
    val playing = _playing.asStateFlow()
    private val _position = MutableStateFlow(0L)
    val position = _position.asStateFlow()
    private val _duration = MutableStateFlow(0L)
    val duration = _duration.asStateFlow()
    private val _audioSession = MutableStateFlow(0)
    val audioSession = _audioSession.asStateFlow()
    private val _eqBands = MutableStateFlow(0)
    val eqBands = _eqBands.asStateFlow()
    private val _eqRange = MutableStateFlow(-12f to 12f)
    val eqRange = _eqRange.asStateFlow()
    private val _volume = MutableStateFlow(prefs.getFloat("volume", .8f))
    val volume = _volume.asStateFlow()
    private val _shuffle = MutableStateFlow(prefs.getBoolean("shuffle", false))
    val shuffle = _shuffle.asStateFlow()
    private val _repeat = MutableStateFlow(prefs.getInt("repeat", Player.REPEAT_MODE_ALL))
    val repeat = _repeat.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    val player: ExoPlayer = ExoPlayer.Builder(application).build().apply {
        setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        volume = _volume.value
        repeatMode = _repeat.value
        shuffleModeEnabled = _shuffle.value
        addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { _playing.value = isPlaying; savePlayback() }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                _currentUri.value = mediaItem?.localConfiguration?.uri?.toString()
                _position.value = currentPosition.coerceAtLeast(0)
                _duration.value = duration.coerceAtLeast(0)
                savePlayback()
            }
            override fun onPlaybackStateChanged(playbackState: Int) { _duration.value = duration.coerceAtLeast(0) }
        })
        addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(eventTime: AnalyticsListener.EventTime, audioSessionId: Int) {
                _audioSession.value = audioSessionId
                attachEqualizer(audioSessionId)
            }
        })
    }

    private var equalizer: Equalizer? = null
    private var mixSession: MediaSession? = null

    init {
        setupMediaSession()
        viewModelScope.launch {
            val savedUri = prefs.getString("currentUri", null)
            val savedPosition = prefs.getLong("position", 0L)
            if (savedUri != null) {
                val library = dao.tracksOnce()
                val index = library.indexOfFirst { it.uri == savedUri }
                if (index >= 0) {
                    player.setMediaItems(library.map { MediaItem.fromUri(Uri.parse(it.uri)) }, index, savedPosition)
                    player.prepare()
                    _currentUri.value = savedUri
                    _position.value = savedPosition
                }
            }
        }
    }

    private fun setupMediaSession() {
        try {
            mixSession = MediaSession.Builder(getApplication(), player).build()
        } catch (e: Exception) { android.util.Log.w("Vela", "MediaSession unavailable", e) }
    }

    private fun attachEqualizer(sessionId: Int) {
        try {
            equalizer?.release()
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            _eqBands.value = equalizer?.numberOfBands?.toInt() ?: 0
            equalizer?.bandLevelRange?.let { _eqRange.value = (it[0] / 100f) to (it[1] / 100f) }
        } catch (e: Exception) { android.util.Log.w("Vela", "Device equalizer unavailable", e); _eqBands.value = 0 }
    }

    fun setEqBand(index: Int, db: Float) {
        try { equalizer?.setBandLevel(index.toShort(), (db * 100).toInt().toShort()) } catch (_: Exception) { }
    }

    fun refreshPosition() {
        _position.value = player.currentPosition.coerceAtLeast(0)
        _duration.value = player.duration.takeIf { it > 0 } ?: 0
        if (_playing.value) savePlayback()
    }

    private var lastSave = 0L
    private fun savePlayback() {
        val now = System.currentTimeMillis()
        if (now - lastSave < 4_000 && _playing.value) return
        lastSave = now
        prefs.edit().putString("currentUri", player.currentMediaItem?.localConfiguration?.uri?.toString())
            .putLong("position", player.currentPosition.coerceAtLeast(0)).putFloat("volume", player.volume)
            .putBoolean("shuffle", player.shuffleModeEnabled).putInt("repeat", player.repeatMode).apply()
    }

    fun importUris(uris: List<Uri>) = viewModelScope.launch {
        _busy.value = true
        val imported = withContext(Dispatchers.IO) { uris.mapNotNull { readTrack(it, true) } }
        if (imported.isNotEmpty()) { dao.putAll(imported); android.widget.Toast.makeText(getApplication(), "${imported.size} tracks added to Vela", android.widget.Toast.LENGTH_SHORT).show() }
        _busy.value = false
    }

    fun importFolder(treeUri: Uri) = viewModelScope.launch {
        _busy.value = true
        try {
            val root = DocumentFile.fromTreeUri(getApplication(), treeUri)
            val list = mutableListOf<Uri>()
            fun walk(dir: DocumentFile?) { dir?.listFiles()?.forEach { f -> if (f.isDirectory) walk(f) else if (f.type?.startsWith("audio/") == true || f.name.orEmpty().matches(Regex("(?i).+\\.(mp3|flac|wav|aac|ogg|m4a|opus)$"))) list += f.uri } }
            walk(root)
            val imported = withContext(Dispatchers.IO) { list.mapNotNull { readTrack(it, false) } }
            dao.putAll(imported)
            android.widget.Toast.makeText(getApplication(), "${imported.size} tracks added", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { android.util.Log.e("Vela", "Folder import failed", e) }
        _busy.value = false
    }

    private suspend fun readTrack(uri: Uri, persistPermission: Boolean): Track? = withContext(Dispatchers.IO) {
        try {
            if (dao.find(uri.toString()) != null) return@withContext null
            if (persistPermission) try { getApplication<Application>().contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
            val resolver = getApplication<Application>().contentResolver
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(getApplication(), uri)
            val displayName = resolver.displayName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Unknown track"
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: displayName.substringBeforeLast('.')
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown artist"
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Single"
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val year = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
            val genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            val art = retriever.embeddedPicture?.takeIf { it.size <= 1_500_000 }
            retriever.release()
            Track(uri.toString(), title, artist, album, duration, year, genre, null, art)
        } catch (e: Exception) { android.util.Log.w("Vela", "Skipping unreadable audio $uri", e); null }
    }

    fun play(track: Track, library: List<Track>) {
        val list = library.ifEmpty { listOf(track) }
        val index = list.indexOfFirst { it.uri == track.uri }.coerceAtLeast(0)
        player.setMediaItems(list.map { MediaItem.fromUri(Uri.parse(it.uri)) }, index, 0)
        player.prepare(); player.play(); _currentUri.value = track.uri; _position.value = 0
    }
    fun togglePlay() { if (player.mediaItemCount == 0) return; if (player.isPlaying) player.pause() else player.play() }
    fun next() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(0, 0); player.play() }
    fun previous() { if (player.currentPosition > 3_000) player.seekTo(0) else if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0, 0); player.play() }
    fun seek(ms: Long) { player.seekTo(ms); _position.value = ms; savePlayback() }
    fun setVolume(value: Float) { val v=value.coerceIn(0f,1f);player.volume=v;_volume.value=v;prefs.edit().putFloat("volume",v).apply() }
    fun toggleShuffle() { val enabled=!player.shuffleModeEnabled;player.shuffleModeEnabled=enabled;_shuffle.value=enabled;prefs.edit().putBoolean("shuffle",enabled).apply() }
    fun cycleRepeat() { val next=when(player.repeatMode){Player.REPEAT_MODE_OFF->Player.REPEAT_MODE_ALL;Player.REPEAT_MODE_ALL->Player.REPEAT_MODE_ONE;else->Player.REPEAT_MODE_OFF};player.repeatMode=next;_repeat.value=next;prefs.edit().putInt("repeat",next).apply() }
    fun toggleFavorite(uri: String) = viewModelScope.launch { dao.toggleFavorite(uri) }
    fun remove(track: Track) = viewModelScope.launch { if (_currentUri.value == track.uri) { player.stop();_currentUri.value=null }; dao.remove(track.uri) }
    fun createMix(name: String, tracks: List<Track>) = viewModelScope.launch { dao.createMix(Mix(name=name,trackUris=tracks.joinToString("\n"){it.uri})) }
    fun playMix(mix: Mix, allTracks: List<Track>) { val ids=mix.trackUris.lines().toSet();val list=allTracks.filter{it.uri in ids};if(list.isNotEmpty())play(list.first(),list) }

    override fun onCleared() {
        savePlayback(); equalizer?.release(); mixSession?.release(); player.release(); super.onCleared()
    }
}

private fun ContentResolver.displayName(uri: Uri): String? = query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
