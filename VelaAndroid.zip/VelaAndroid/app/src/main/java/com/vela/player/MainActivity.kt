package com.vela.player

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.Slider
import androidx.compose.foundation.lazy.rememberLazyListState
import com.vela.player.data.Mix
import com.vela.player.data.Track
import kotlinx.coroutines.delay

private val Back = Color(0xFF111510)
private val Surface = Color(0xFF191F19)
private val Surface2 = Color(0xFF222A21)
private val Stroke = Color(0xFF30392F)
private val Lime = Color(0xFFC2E682)
private val Text = Color(0xFFEAF0E5)
private val Muted = Color(0xFF899385)
private val Warm = Color(0xFFE3916D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(17, 21, 16)
        window.navigationBarColor = android.graphics.Color.rgb(17, 21, 16)
        setContent { VelaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VelaApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val mixes by vm.mixes.collectAsStateWithLifecycle()
    val currentUri by vm.currentUri.collectAsStateWithLifecycle()
    val playing by vm.playing.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val duration by vm.duration.collectAsStateWithLifecycle()
    val volume by vm.volume.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val repeat by vm.repeat.collectAsStateWithLifecycle()
    val eqBands by vm.eqBands.collectAsStateWithLifecycle()
    val eqRange by vm.eqRange.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val current = tracks.firstOrNull { it.uri == currentUri }
    val openFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> -> if (uris.isNotEmpty()) vm.importUris(uris) }
    val openFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) { try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: SecurityException) { }; vm.importFolder(uri) } }
    var tab by remember { mutableStateOf("Library") }
    var query by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var showPlayer by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var showMixDialog by remember { mutableStateOf(false) }
    var selectedArtist by remember { mutableStateOf<String?>(null) }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    var eqValues by remember { mutableStateOf(List(10) { 0f }) }
    val listState = rememberLazyListState()
    LaunchedEffect(playing) { while (playing) { vm.refreshPosition(); delay(500) } }
    val filtered = remember(tracks, tab, query, selectedArtist, selectedAlbum) {
        var result = when (tab) {
            "Favorites" -> tracks.filter { it.favorite }
            "Artists" -> selectedArtist?.let { name -> tracks.filter { it.artist == name } } ?: tracks
            "Albums" -> selectedAlbum?.let { name -> tracks.filter { it.album == name } } ?: tracks
            "Recent" -> tracks.sortedByDescending { it.addedAt }
            "Mixes" -> tracks
            else -> tracks
        }
        if (query.isNotBlank()) result = result.filter { "${it.title} ${it.artist} ${it.album}".contains(query, true) }
        result
    }
    val selectedMix = mixes.firstOrNull { it.name == tab.removePrefix("Mix: ") }?.takeIf { tab.startsWith("Mix: ") }
    val displayTracks = if (selectedMix != null) { val ids = selectedMix.trackUris.lines().toSet(); tracks.filter { it.uri in ids } } else filtered

    MaterialTheme(colorScheme = darkColorScheme(background = Back, surface = Surface, primary = Lime, onPrimary = Back, onBackground = Text, onSurface = Text)) {
        Box(Modifier.fillMaxSize().background(Back)) {
            Column(Modifier.fillMaxSize()) {
                TopBar(searchOpen, query, { searchOpen = !searchOpen; if (!searchOpen) query = "" }, { openFiles.launch(arrayOf("audio/*")) }, { showMixDialog = true })
                AnimatedVisibility(searchOpen) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clip(RoundedCornerShape(8.dp)).background(Surface2).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Search, null, tint = Muted, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(9.dp))
                        BasicTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Text, fontSize = 13.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Search tracks, artists, albums", color = Muted, fontSize = 12.sp); inner() })
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, null, tint = Muted) }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Library", "Artists", "Albums", "Favorites", "Recent", "Mixes").forEach { name -> NavPill(name, tab == name) { tab = name; selectedArtist = null; selectedAlbum = null } }
                    mixes.forEach { mix -> NavPill(mix.name, tab == "Mix: ${mix.name}") { tab = "Mix: ${mix.name}" } }
                }
                if (tracks.isEmpty()) {
                    EmptyLibrary(onFiles = { openFiles.launch(arrayOf("audio/*")) }, onFolder = { openFolder.launch(null) })
                } else {
                    LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { WelcomeCard(tracks.size, current, playing) { if (current != null) vm.togglePlay() else tracks.firstOrNull()?.let { vm.play(it, tracks) } } }
                        if (tab == "Artists" && selectedArtist == null) {
                            item { SectionTitle("Artists", "${tracks.map { it.artist }.distinct().size} voices") }
                            items(tracks.groupBy { it.artist }.toList(), key = { it.first }) { (artist, group) -> EntityRow(artist, "${group.size} tracks · ${group.map { it.album }.distinct().size} albums", group.first(), false) { selectedArtist = artist } }
                        } else if (tab == "Albums" && selectedAlbum == null) {
                            item { SectionTitle("Albums", "${tracks.map { it.album }.distinct().size} records") }
                            items(tracks.groupBy { it.album }.toList(), key = { it.first }) { (album, group) -> EntityRow(album, "${group.first().artist} · ${group.size} tracks", group.first(), true) { selectedAlbum = album } }
                        } else {
                            item { Row(Modifier.fillMaxWidth().padding(top = 15.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) { Column(Modifier.weight(1f)) { Text(if (selectedArtist != null) selectedArtist!! else if (selectedAlbum != null) selectedAlbum!! else selectedMix?.name ?: when (tab) { "Favorites" -> "Loved tracks"; "Recent" -> "Recently added"; else -> "Your collection" }, color = Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("${displayTracks.size} TRACKS · ON THIS DEVICE", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp) }; Text("TITLE  /  ARTIST", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp) } }
                            if (displayTracks.isEmpty()) item { Text("No tracks here yet.", Modifier.padding(vertical = 24.dp), color = Muted, fontSize = 12.sp) }
                            items(displayTracks, key = { it.uri }) { track -> TrackRow(track, currentUri == track.uri, playing, onPlay = { vm.play(track, displayTracks) }, onFavorite = { vm.toggleFavorite(track.uri) }, onMore = { vm.remove(track) }) }
                        }
                    }
                }
                current?.let { MiniPlayer(it, playing, position, duration, vm, onExpand = { showPlayer = true }) }
            }
            if (busy) Box(Modifier.fillMaxSize().background(Back.copy(alpha=.7f)), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(color = Lime); Spacer(Modifier.height(10.dp)); Text("Reading your music locally…", color = Text, fontSize = 12.sp) } }
            if (showPlayer && current != null) FullPlayer(current, playing, position, duration, shuffle, repeat, tracks, vm, onClose = { showPlayer = false }, onEq = { showEq = true })
            if (showEq) EqualizerDialog(eqBands, eqRange, eqValues, onValues = { eqValues = it }, onBand = vm::setEqBand, onClose = { showEq = false })
            if (showMixDialog) MixDialog(onDismiss = { showMixDialog = false }, onCreate = { name -> vm.createMix(name, tracks); showMixDialog = false })
        }
    }
}

@Composable private fun TopBar(searchOpen: Boolean, query: String, search: () -> Unit, import: () -> Unit, createMix: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(60.dp).background(Color(0xFF151A15)).padding(horizontal = 17.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomEnd = 10.dp, bottomStart = 3.dp)).background(Lime), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.GraphicEq, null, tint = Back, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("vela", color = Text, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.7).sp); Text("LOCAL AUDIO", color = Muted, fontSize = 7.sp, letterSpacing = 1.7.sp) }
        IconButton(onClick = search) { Icon(if (searchOpen) Icons.Rounded.Close else Icons.Rounded.Search, "Search", tint = Text) }
        IconButton(onClick = createMix) { Icon(Icons.Rounded.QueueMusic, "New mix", tint = Text) }
        IconButton(onClick = import) { Icon(Icons.Rounded.Add, "Import music", tint = Lime) }
    }
}

@Composable private fun NavPill(name: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(22.dp)).background(if (selected) Color(0xFF3B4932) else Surface).border(1.dp, if (selected) Color(0xFF617647) else Stroke, RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (selected) { Icon(Icons.Rounded.GraphicEq, null, tint = Lime, modifier = Modifier.size(13.dp)); Spacer(Modifier.width(5.dp)) }
        Text(name, color = if (selected) Lime else Color(0xFFADB5A8), fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable private fun WelcomeCard(count: Int, current: Track?, playing: Boolean, onPlay: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(Color(0xFF263027), Color(0xFF20261F), Color(0xFF34412D)))).padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(6.dp).clip(CircleShape).background(Lime)); Spacer(Modifier.width(6.dp)); Text("YOUR LISTENING ROOM", color = Color(0xFFA7B39A), fontSize = 7.sp, letterSpacing = 1.35.sp) }
            Spacer(Modifier.height(9.dp)); Text(if (count == 0) "Your sound.\nYour space." else "Pick up where\nyou left off.", color = Text, fontSize = 22.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.5).sp)
            Text(if (current != null) "${current.title} · ${current.artist}" else "$count tracks, stored on this device", color = Color(0xFFADB6A8), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
            Row(Modifier.padding(top = 12.dp).clip(RoundedCornerShape(5.dp)).background(Lime).clickable(onClick = onPlay).padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Back, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text(if (playing) "Pause session" else if (current != null) "Continue listening" else "Explore library", color = Back, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
        }
        Box(Modifier.padding(start = 8.dp).size(92.dp), contentAlignment = Alignment.Center) { VinylGraphic(Modifier.size(91.dp), Color(0xFF171C17), Lime) }
    }
}

@Composable private fun EmptyLibrary(onFiles: () -> Unit, onFolder: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(165.dp), contentAlignment = Alignment.Center) { VinylGraphic(Modifier.size(150.dp), Color(0xFF202620), Lime); Box(Modifier.align(Alignment.TopEnd).size(40.dp).clip(RoundedCornerShape(12.dp)).background(Warm), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White) } }
        Spacer(Modifier.height(20.dp)); Text("A quieter kind of music app.", color = Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(7.dp)); Text("Bring in your tracks. Vela keeps the files and their details right here on your phone.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp); Spacer(Modifier.height(17.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onFiles, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Back), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp)) { Icon(Icons.Rounded.Add, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("Choose audio", fontSize = 10.sp) }; OutlinedButton(onClick = onFolder, border = BorderStroke(1.dp, Stroke), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp)) { Icon(Icons.Rounded.FolderOpen, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("Folder", fontSize = 10.sp) } }
        Spacer(Modifier.height(18.dp)); Text("MP3  ·  FLAC  ·  WAV  ·  AAC  ·  OGG  ·  M4A", color = Color(0xFF697465), fontSize = 8.sp, letterSpacing = 1.sp)
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) { Row(Modifier.fillMaxWidth().padding(top = 15.dp, bottom = 6.dp), verticalAlignment = Alignment.Bottom) { Text(title, color = Text, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f)); Text(subtitle.uppercase(), color = Muted, fontSize = 8.sp, letterSpacing = 1.sp) } }

@Composable private fun EntityRow(name: String, detail: String, track: Track, album: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Surface).clickable(onClick = onClick).padding(9.dp), verticalAlignment = Alignment.CenterVertically) { TrackArt(track, 48); Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(name, color = Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(detail, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp)) }; Icon(if (album) Icons.Rounded.Album else Icons.Rounded.ChevronRight, null, tint = Lime, modifier = Modifier.size(18.dp)) }
}

@Composable private fun TrackRow(track: Track, current: Boolean, playing: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit, onMore: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(59.dp).clip(RoundedCornerShape(7.dp)).background(if (current) Color(0xFF20281E) else Surface).clickable(onClick = onPlay).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(29.dp), contentAlignment = Alignment.Center) { if (current && playing) MiniBars() else Text(if (current) "▶" else "${track.trackNumber ?: "·"}", color = if (current) Lime else Muted, fontSize = 9.sp) }
        TrackArt(track, 40); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = if (current) Lime else Text, fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis); Spacer(Modifier.height(3.dp)); Text(track.artist, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        Column(horizontalAlignment = Alignment.End) { IconButton(onClick = onFavorite, modifier = Modifier.size(28.dp)) { Icon(Icons.Rounded.Favorite, null, tint = if (track.favorite) Warm else Color(0xFF606B5D), modifier = Modifier.size(16.dp)) }; Text(formatDuration(track.durationMs), color = Color(0xFF879182), fontSize = 8.sp) }
    }
}

@Composable private fun MiniPlayer(track: Track, playing: Boolean, position: Long, duration: Long, vm: PlayerViewModel, onExpand: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF222A21)).clickable(onClick = onExpand)) {
        Slider(value = if (duration > 0) (position.toFloat()/duration).coerceIn(0f,1f) else 0f, onValueChange = { vm.seek((it*duration).toLong()) }, modifier = Modifier.fillMaxWidth().height(12.dp).padding(horizontal = 4.dp), colors = SliderDefaults.colors(thumbColor = Lime, activeTrackColor = Lime, inactiveTrackColor = Color(0xFF485244)))
        Row(Modifier.fillMaxWidth().height(62.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) { TrackArt(track, 40); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 8.sp) }; IconButton(onClick = { vm.previous() }) { Icon(Icons.Rounded.SkipPrevious, null, tint = Text) }; IconButton(onClick = vm::togglePlay) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Lime, modifier = Modifier.size(28.dp)) }; IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, null, tint = Text) } }
    }
}

@Composable private fun FullPlayer(track: Track, playing: Boolean, position: Long, duration: Long, shuffle: Boolean, repeat: Int, library: List<Track>, vm: PlayerViewModel, onClose: () -> Unit, onEq: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Back).padding(horizontal = 22.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Minimize player", tint = Text, modifier = Modifier.size(28.dp)) }; Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { Text("NOW PLAYING", color = Muted, fontSize = 8.sp, letterSpacing = 1.5.sp); Text("VELA LISTENING ROOM", color = Lime, fontSize = 7.sp, letterSpacing = 1.sp) }; IconButton(onClick = onEq) { Icon(Icons.Rounded.GraphicEq, "Equalizer", tint = Text) } }
            Spacer(Modifier.weight(.65f)); Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(13.dp)).background(Surface2), contentAlignment = Alignment.Center) { TrackArt(track, 268); Canvas(Modifier.fillMaxSize()) { drawCircle(Color.White.copy(alpha=.06f), size.minDimension*.48f, center); drawCircle(Color.Transparent, size.minDimension*.4f, center, style=androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx())) } }
            Spacer(Modifier.weight(.55f)); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(track.title, color = Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }; IconButton(onClick = { vm.toggleFavorite(track.uri) }) { Icon(Icons.Rounded.Favorite, null, tint = if (track.favorite) Warm else Muted) } }
            Spacer(Modifier.height(18.dp)); Slider(value = if (duration>0)(position.toFloat()/duration).coerceIn(0f,1f) else 0f, onValueChange = { vm.seek((it*duration).toLong()) }, colors = SliderDefaults.colors(thumbColor = Lime, activeTrackColor = Lime, inactiveTrackColor = Stroke)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatDuration(position), color = Muted, fontSize = 9.sp); Text(formatDuration(duration), color = Muted, fontSize = 9.sp) }
            Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = vm::toggleShuffle) { Icon(Icons.Rounded.Shuffle, null, tint = if (shuffle) Lime else Muted) }; IconButton(onClick = vm::previous) { Icon(Icons.Rounded.SkipPrevious, null, tint = Text, modifier = Modifier.size(32.dp)) }; FilledIconButton(onClick = vm::togglePlay, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Lime, contentColor = Back), modifier = Modifier.size(62.dp)) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, modifier = Modifier.size(32.dp)) }; IconButton(onClick = vm::next) { Icon(Icons.Rounded.SkipNext, null, tint = Text, modifier = Modifier.size(32.dp)) }; IconButton(onClick = vm::cycleRepeat) { Icon(Icons.Rounded.Repeat, null, tint = if (repeat != 0) Lime else Muted) } }
            Spacer(Modifier.weight(1f)); Text("UP NEXT · ${library.size} TRACKS IN LIBRARY", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp); Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable private fun EqualizerDialog(bands: Int, range: Pair<Float,Float>, values: List<Float>, onValues: (List<Float>) -> Unit, onBand: (Int,Float) -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, containerColor = Surface, title = { Column { Text("Sound, shaped to you.", color = Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(if (bands>0) "$bands DEVICE EQ BANDS" else "DEVICE EQUALIZER UNAVAILABLE", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 5.dp)) } }, text = {
        if (bands > 0) Column(Modifier.heightIn(max = 400.dp)) {
            val count = minOf(bands, 8)
            (0 until count).forEach { i -> val value = values.getOrElse(i) { 0f }; Row(verticalAlignment = Alignment.CenterVertically) { Text(listOf("SUB","LOW","MID","HIGH","AIR","BAND ${i+1}").getOrElse(i){"BAND ${i+1}"}, color = Muted, fontSize = 8.sp, modifier = Modifier.width(44.dp)); Slider(value = value.coerceIn(range.first,range.second), onValueChange = { v -> val next=values.toMutableList();while(next.size<=i)next.add(0f);next[i]=v;onValues(next);onBand(i,v) }, valueRange = range, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = Lime, activeTrackColor = Lime)); Text("${value.toInt()} dB", color = Text, fontSize = 8.sp, modifier = Modifier.width(43.dp)) } }
        } else Text("This phone does not expose a system equalizer for the current audio session. Playback controls remain available.", color = Muted, fontSize = 12.sp)
    }, confirmButton = { TextButton(onClick = onClose) { Text("Done", color = Lime) } })
}

@Composable private fun MixDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Surface, title = { Text("Make a mix", color = Text) }, text = { Column { Text("Save the current library as a personal mix. You can add and reorder tracks later.", color = Muted, fontSize = 11.sp); Spacer(Modifier.height(12.dp)); OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Mix name") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Text, unfocusedTextColor = Text, focusedBorderColor = Lime, focusedLabelColor = Lime)) } }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }, enabled = name.isNotBlank()) { Text("Create", color = Lime) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } })
}

@Composable private fun TrackArt(track: Track, size: Int) {
    val bitmap = remember(track.uri, track.art?.size) { track.art?.let { BitmapFactory.decodeByteArray(it,0,it.size)?.asImageBitmap() } }
    if (bitmap != null) Image(bitmap, null, Modifier.size(size.dp).clip(RoundedCornerShape(6.dp))) else {
        val colors = listOf(Color(0xFFE9AA72),Color(0xFF798F89),Color(0xFF8693B0),Warm,Color(0xFFA0A27A)); val color=colors[(track.title.hashCode().absoluteValueSafe)%colors.size]
        Box(Modifier.size(size.dp).clip(RoundedCornerShape(6.dp)).background(Brush.linearGradient(listOf(color, Surface2))), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Album, null, tint = Color.White.copy(alpha=.78f), modifier = Modifier.size((size*.46f).dp)) }
    }
}

@Composable private fun VinylGraphic(modifier: Modifier, disc: Color, label: Color) {
    Canvas(modifier) { val r=size.minDimension/2; val center=Offset(size.width/2,size.height/2);drawCircle(disc,r,center);for(i in 1..9)drawCircle(Color.White.copy(alpha=.035f),r*i/10f,center,style=androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()));drawCircle(label,r*.28f,center);drawCircle(Back,r*.055f,center) }
}
@Composable private fun MiniBars() { Row(Modifier.height(15.dp),horizontalArrangement=Arrangement.spacedBy(2.dp),verticalAlignment=Alignment.Bottom) { listOf(8,13,6).forEach { h -> Box(Modifier.width(2.dp).height(h.dp).clip(RoundedCornerShape(2.dp)).background(Lime)) } } }
private fun formatDuration(ms: Long): String { val sec=(ms.coerceAtLeast(0)/1000).toInt();return "${sec/60}:${(sec%60).toString().padStart(2,'0')}" }
private val Int.absoluteValueSafe: Int get() = if (this == Int.MIN_VALUE) 0 else kotlin.math.abs(this)
