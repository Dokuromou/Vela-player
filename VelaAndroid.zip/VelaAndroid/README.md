# Vela for Android

Native Android local music player built with Kotlin, Jetpack Compose, Media3/ExoPlayer, Room, the Storage Access Framework, and Android's device equalizer API. This is an Android Studio project, not a web app.

## Open and build

1. Open this folder (`VelaAndroid`) in Android Studio.
2. Install Android SDK Platform 35 when prompted and allow Gradle to sync.
3. Run `app` on an Android 8.0+ device/emulator. Build an APK using **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Included

- Import selected audio files or recursively scan a user-selected folder; no broad storage permission is requested.
- Extract tags/artwork off the UI thread and persist track metadata, favorites, and mixes in Room.
- Play local content URIs with ExoPlayer, with seek, previous/next, shuffle/repeat, a media session, and saved playback position.
- Browse by artist or album, search the library, and open the device equalizer when available.

The project source was created in this workspace. This environment did not produce a verified APK; Android Studio will need network access for its first Gradle dependency sync.
