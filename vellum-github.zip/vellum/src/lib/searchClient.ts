import { SearchIndex } from './searchCore'
import type { SearchDoc, SearchHit } from '../types'

/**
 * Search facade that indexes in a Web Worker and transparently falls back to
 * an in-page index when workers are unavailable (or fail to boot).
 */
export class SearchService {
  private worker: Worker | null = null
  private local = new SearchIndex()
  private docs = new Map<string, SearchDoc>()
  private pending = new Map<number, (hits: SearchHit[]) => void>()
  private seq = 0
  private useWorker = false
  onStatus?: (info: { worker: boolean; size: number }) => void

  constructor() {
    try {
      this.worker = new Worker(new URL('../workers/search.worker.ts', import.meta.url), { type: 'module' })
      this.worker.onmessage = (e: MessageEvent) => this.handleMessage(e.data)
      this.worker.onerror = () => {
        this.useWorker = false
        this.worker?.terminate()
        this.worker = null
        this.rebuildLocal()
      }
      this.useWorker = true
    } catch {
      this.useWorker = false
    }
    this.onStatus?.({ worker: this.useWorker, size: 0 })
  }

  private handleMessage(data: { type: string; id?: number; hits?: SearchHit[]; size?: number }) {
    if (data.type === 'results' && typeof data.id === 'number') {
      const resolve = this.pending.get(data.id)
      if (resolve) {
        this.pending.delete(data.id)
        resolve(data.hits || [])
      }
    } else if (data.type === 'indexed') {
      this.onStatus?.({ worker: true, size: data.size || 0 })
    }
  }

  private rebuildLocal() {
    this.local.clear()
    for (const doc of this.docs.values()) this.local.upsert(doc)
    this.onStatus?.({ worker: false, size: this.local.size })
  }

  index(docs: SearchDoc[]): void {
    this.docs.clear()
    for (const d of docs) this.docs.set(d.path, d)
    if (this.useWorker && this.worker) {
      this.worker.postMessage({ type: 'index', docs })
    } else {
      this.rebuildLocal()
    }
  }

  upsert(doc: SearchDoc): void {
    this.docs.set(doc.path, doc)
    if (this.useWorker && this.worker) this.worker.postMessage({ type: 'upsert', doc })
    else this.local.upsert(doc)
  }

  remove(path: string): void {
    this.docs.delete(path)
    if (this.useWorker && this.worker) this.worker.postMessage({ type: 'remove', path })
    else this.local.remove(path)
  }

  query(q: string, limit = 40): Promise<SearchHit[]> {
    if (!q.trim()) return Promise.resolve([])
    if (this.useWorker && this.worker) {
      const id = ++this.seq
      return new Promise<SearchHit[]>((resolve) => {
        this.pending.set(id, resolve)
        this.worker!.postMessage({ type: 'query', id, q, limit })
        window.setTimeout(() => {
          if (this.pending.has(id)) {
            this.pending.delete(id)
            resolve(this.local.query(q, limit))
          }
        }, 1200)
      })
    }
    return Promise.resolve(this.local.query(q, limit))
  }
}

let singleton: SearchService | null = null
export function getSearchService(): SearchService {
  if (!singleton) singleton = new SearchService()
  return singleton
}
