import {
  CalendarDays,
  ChevronsUpDown,
  Columns3,
  Command,
  Download,
  FolderOpen,
  HardDrive,
  Moon,
  PanelLeft,
  PanelRight,
  Plus,
  Share2,
  Sparkles,
  Sun,
  FilePlus2,
  BookOpen,
} from 'lucide-react'
import { useStore } from '../store/useStore'
import { THEMES } from '../lib/theme'
import { MOD_KEY, todayISO } from '../lib/utils'
import { Divider, IconButton, Kbd, MenuItem, MenuLabel, Popover } from './ui'

export function TopBar() {
  const vaultName = useStore((s) => s.vaultName)
  const vaultKind = useStore((s) => s.vaultKind)
  const theme = useStore((s) => s.theme)
  const setTheme = useStore((s) => s.setTheme)
  const sidebarOpen = useStore((s) => s.sidebarOpen)
  const rightOpen = useStore((s) => s.rightOpen)
  const toggleSidebar = useStore((s) => s.toggleSidebar)
  const toggleRight = useStore((s) => s.toggleRight)
  const setPalette = useStore((s) => s.setPalette)
  const openDaily = useStore((s) => s.openDaily)
  const setGraphOpen = useStore((s) => s.setGraphOpen)
  const openFolder = useStore((s) => s.openFolder)
  const useLocalVault = useStore((s) => s.useLocalVault)
  const exportVault = useStore((s) => s.exportVault)
  const seedSamples = useStore((s) => s.seedSamples)
  const createNote = useStore((s) => s.createNote)
  const setView = useStore((s) => s.setView)
  const view = useStore((s) => s.view)
  const notes = useStore((s) => s.notes)

  const openViews = () => {
    // prefer the folder of the note you are reading, else the busiest folder
    const activePath = useStore.getState().panes[useStore.getState().activePane]?.active
    const activeFolder = activePath && activePath.includes('/') ? activePath.slice(0, activePath.lastIndexOf('/')) : ''
    const counts = new Map<string, number>()
    for (const p of Object.keys(notes)) {
      const folder = p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : ''
      counts.set(folder, (counts.get(folder) || 0) + 1)
    }
    let best = ''
    for (const [folder, count] of counts) {
      if (!best || count > (counts.get(best) || 0)) best = folder
    }
    const folder = counts.has(activeFolder) && (counts.get(activeFolder) || 0) > 1 ? activeFolder : best
    setView({ mode: 'table', folder })
  }

  return (
    <header className="flex h-12 shrink-0 items-center gap-1 border-b border-line bg-panel px-2">
      <IconButton icon={PanelLeft} label="Toggle sidebar" active={sidebarOpen} onClick={toggleSidebar} shortcut={`${MOD_KEY}B`} />

      <div className="ml-1 flex items-center gap-2 pr-1">
        <div className="flex size-[22px] items-center justify-center rounded-[7px] bg-accent text-[13px] font-black text-app">V</div>
        <span className="text-[13.5px] font-semibold tracking-[-0.01em]">Vellum</span>
      </div>

      <Popover
        width={268}
        trigger={() => (
          <button
            type="button"
            className="ml-1 flex items-center gap-1.5 rounded-lg border border-line bg-elev px-2 py-[5px] text-[12px] text-ink/90 hover:border-accent/40"
          >
            {vaultKind === 'fs' ? <FolderOpen size={13} className="text-accent" /> : <HardDrive size={13} className="text-muted" />}
            <span className="max-w-[150px] truncate">{vaultName}</span>
            <ChevronsUpDown size={12} className="text-muted" />
          </button>
        )}
      >
        {(close) => (
          <>
            <MenuLabel>Vault</MenuLabel>
            <div className="px-2 pb-1.5 text-[11px] leading-relaxed text-muted">
              {vaultKind === 'fs'
                ? 'Reading and writing real .md files in your folder.'
                : 'Stored locally in IndexedDB — works offline, no folder needed.'}
            </div>
            <MenuItem icon={FolderOpen} shortcut="folder" onClick={() => { close(); void openFolder() }}>
              Open local folder…
            </MenuItem>
            <MenuItem icon={HardDrive} onClick={() => { close(); void useLocalVault() }}>
              Use browser vault
            </MenuItem>
            <MenuItem icon={Sparkles} onClick={() => { close(); void seedSamples() }}>
              Add sample notes
            </MenuItem>
            <Divider />
            <MenuItem icon={Download} onClick={() => { close(); exportVault() }}>
              Export vault as JSON
            </MenuItem>
          </>
        )}
      </Popover>

      <div className="mx-1 h-5 w-px bg-line" />

      <button
        type="button"
        onClick={() => setPalette(true, 'files')}
        title={`Command palette  ${MOD_KEY}P`}
        className="flex items-center gap-2 rounded-lg px-2 py-[5px] text-muted hover:bg-elev hover:text-ink"
      >
        <Command size={14} />
        <span className="hidden text-[12px] md:inline">Search or run a command</span>
        <Kbd>{MOD_KEY}P</Kbd>
      </button>

      <div className="ml-auto flex items-center gap-0.5">
        <IconButton icon={FilePlus2} label="New note" onClick={() => createNote('')} shortcut={`${MOD_KEY}N`} />
        <IconButton icon={CalendarDays} label="Today's daily note" onClick={() => openDaily(todayISO())} shortcut={`${MOD_KEY}⇧D`} />
        <IconButton icon={Columns3} label="Database views" active={!!view} onClick={openViews} />
        <IconButton icon={Share2} label="Knowledge graph" onClick={() => setGraphOpen(true)} shortcut={`${MOD_KEY}G`} />
        <div className="mx-1 h-5 w-px bg-line" />
        <Popover
          align="right"
          width={190}
          trigger={() => (
            <button
              type="button"
              className="inline-flex size-8 items-center justify-center rounded-lg text-muted hover:bg-elev hover:text-ink"
              title="Theme"
            >
              {theme === 'dark' ? <Moon size={15} /> : theme === 'light' ? <Sun size={15} /> : <BookOpen size={15} />}
            </button>
          )}
        >
          {(close) => (
            <>
              <MenuLabel>Theme</MenuLabel>
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setTheme(t.id)
                    close()
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left text-[13px] hover:bg-accent-soft"
                >
                  <span className="size-3.5 rounded-full border border-line" style={{ background: t.bg }} />
                  <span className="flex-1">{t.label}</span>
                  {theme === t.id ? <span className="text-[11px] text-accent">✓</span> : null}
                </button>
              ))}
            </>
          )}
        </Popover>
        <IconButton icon={PanelRight} label="Toggle right sidebar" active={rightOpen} onClick={toggleRight} shortcut={`${MOD_KEY}⇧B`} />
      </div>
    </header>
  )
}
