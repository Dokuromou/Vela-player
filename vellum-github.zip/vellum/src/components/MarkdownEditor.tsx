import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { EditorState, Prec } from '@codemirror/state'
import {
  drawSelection,
  EditorView,
  highlightActiveLine,
  keymap,
  placeholder,
  scrollPastEnd,
} from '@codemirror/view'
import { defaultKeymap, history, historyKeymap } from '@codemirror/commands'
import { highlightSelectionMatches, searchKeymap } from '@codemirror/search'
import { bracketMatching } from '@codemirror/language'
import { markdown, markdownLanguage } from '@codemirror/lang-markdown'
import { FileText, Hash, Plus } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { velEditorTheme, velHighlighting } from '../editor/theme'
import { livePreview, toggleTask } from '../editor/livePreview'
import { markdownKeymap } from '../editor/keymap'
import { registerView, unregisterView } from '../editor/registry'
import { SLASH_COMMANDS } from '../editor/slashCommands'
import { useStore } from '../store/useStore'
import { cls, fuzzyScore } from '../lib/utils'
import { dirname } from '../lib/markdown'

interface SuggestState {
  mode: 'slash' | 'wikilink'
  query: string
  from: number
  to: number
  x: number
  y: number
  above: boolean
}

interface MenuItem {
  id: string
  label: string
  hint: string
  insert: string
  cursor?: number
  icon?: LucideIcon
  kind?: 'note' | 'heading' | 'command' | 'create'
}

interface Props {
  paneIndex: number
  path: string
  content: string
}

export function MarkdownEditor({ paneIndex, path, content }: Props) {
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const viewRef = useRef<EditorView | null>(null)
  const suggestRef = useRef<SuggestState | null>(null)
  const [suggest, setSuggestState] = useState<SuggestState | null>(null)
  const [activeIndex, setActiveIndex] = useState(0)
  const lastEmitted = useRef<string | null>(null)
  const notes = useStore((s) => s.notes)
  const updateNote = useStore((s) => s.updateNote)
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const setSuggest = useCallback((next: SuggestState | null) => {
    const prev = suggestRef.current
    if (next && (!prev || prev.mode !== next.mode || prev.query !== next.query)) setActiveIndex(0)
    suggestRef.current = next
    setSuggestState(next)
  }, [])

  /* ------------------------------------------------------------ suggestions */
  const computeSuggest = useCallback(
    (view: EditorView) => {
      const wrap = wrapRef.current
      if (!wrap) return
      const sel = view.state.selection.main
      if (!sel.empty || !view.hasFocus) {
        setSuggest(null)
        return
      }
      const pos = sel.head
      const line = view.state.doc.lineAt(pos)
      const before = view.state.doc.sliceString(line.from, pos)

      let mode: 'slash' | 'wikilink' | null = null
      let query = ''
      let from = pos
      const wiki = /\[\[([^\]\n|]*)$/.exec(before)
      const slash = /(?:^|\s)\/([A-Za-z]*)$/.exec(before)
      if (wiki) {
        mode = 'wikilink'
        query = wiki[1]
        from = line.from + wiki.index
      } else if (slash) {
        mode = 'slash'
        query = slash[1]
        from = line.from + slash.index + (slash[0].startsWith('/') ? 0 : 1)
      }
      if (!mode) {
        setSuggest(null)
        return
      }
      const coords = view.coordsAtPos(from)
      if (!coords) {
        setSuggest(null)
        return
      }
      const menuWidth = 330
      const menuHeight = 272
      const x = Math.min(Math.max(8, coords.left), Math.max(8, window.innerWidth - menuWidth - 8))
      const above = coords.bottom + menuHeight + 12 > window.innerHeight
      const y = above ? coords.top - 6 : coords.bottom + 6
      setSuggest({ mode, query, from, to: pos, x, y, above })
    },
    [setSuggest],
  )

  /* ------------------------------------------------------------------ items */
  const items = useMemo<MenuItem[]>(() => {
    if (!suggest) return []
    const q = suggest.query.trim()
    if (suggest.mode === 'slash') {
      return SLASH_COMMANDS.map((c) => ({
        c,
        score: q ? Math.max(fuzzyScore(q, c.label), fuzzyScore(q, c.keywords), fuzzyScore(q, c.hint)) : 1,
      }))
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 9)
        .map(({ c }) => {
          const ins = c.make()
          return {
            id: c.id,
            label: c.label,
            hint: c.hint,
            insert: ins.text,
            cursor: ins.cursor,
            icon: c.icon,
            kind: 'command' as const,
          }
        })
    }

    const out: { item: MenuItem; score: number }[] = []
    const noteList = Object.values(notes)
    for (const n of noteList) {
      const score = q ? Math.max(fuzzyScore(q, n.title), fuzzyScore(q, n.path)) : 1
      if (score <= 0) continue
      out.push({
        item: {
          id: n.path,
          label: n.title,
          hint: dirname(n.path) || 'vault root',
          insert: `[[${n.path.replace(/\.md$/i, '')}]]`,
          icon: FileText,
          kind: 'note',
        },
        score: score + 4,
      })
    }
    // headings — "note#heading" or the current note's outline
    const [headTitle, headQuery] = q.split('#')
    for (const n of noteList) {
      if (!n.headings.length) continue
      const titleMatches = !headTitle || fuzzyScore(headTitle, n.title) > 0
      if (!titleMatches) continue
      if (q.includes('#') && !titleMatches) continue
      if (!q.includes('#') && n.path !== path) continue
      for (const h of n.headings) {
        const label = `${n.title} › ${h.text}`
        const score = headQuery ? fuzzyScore(headQuery, h.text) : 1
        if (score <= 0) continue
        out.push({
          item: {
            id: `${n.path}#${h.text}`,
            label: h.text,
            hint: n.title,
            insert: `[[${n.path.replace(/\.md$/i, '')}#${h.text}]]`,
            icon: Hash,
            kind: 'heading',
          },
          score: score + 1,
        })
      }
    }
    if (q && !out.some((o) => o.item.label.toLowerCase() === q.toLowerCase())) {
      out.push({
        item: {
          id: `create:${q}`,
          label: `Create “${q}”`,
          hint: 'new note',
          insert: `[[${q}]]`,
          icon: Plus,
          kind: 'create',
        },
        score: 0.5,
      })
    }
    return out
      .sort((a, b) => b.score - a.score)
      .slice(0, 9)
      .map((o) => o.item)
  }, [suggest, notes, path])

  /* --------------------------------------------------------------- applying */
  const applyItem = useCallback(
    (item: MenuItem) => {
      const s = suggestRef.current
      const view = viewRef.current
      if (!s || !view) return
      const insert = item.insert
      const anchor = s.from + (item.cursor ?? insert.length)
      view.dispatch({
        changes: { from: s.from, to: s.to, insert },
        selection: { anchor },
        scrollIntoView: true,
      })
      setSuggest(null)
      view.focus()
    },
    [setSuggest],
  )

  /* ------------------------------------------------------------- key routing */
  const keyRef = useRef<(event: KeyboardEvent) => boolean>(() => false)
  useEffect(() => {
    keyRef.current = (event: KeyboardEvent) => {
      if (!suggestRef.current) {
        if (event.key === 'Escape') return false
        return false
      }
      if (event.key === 'Escape') {
        setSuggest(null)
        return true
      }
      if (event.key === 'ArrowDown') {
        setActiveIndex((i) => (items.length ? (i + 1) % items.length : 0))
        return true
      }
      if (event.key === 'ArrowUp') {
        setActiveIndex((i) => (items.length ? (i - 1 + items.length) % items.length : 0))
        return true
      }
      if (event.key === 'Enter' || (event.key === 'Tab' && items.length)) {
        const item = items[Math.min(activeIndex, items.length - 1)]
        if (item) {
          applyItem(item)
          return true
        }
      }
      return false
    }
  }, [items, activeIndex, applyItem, setSuggest])

  /* ------------------------------------------------------------ mount editor */
  useEffect(() => {
    const wrap = wrapRef.current
    if (!wrap) return

    const state = EditorState.create({
      doc: content,
      extensions: [
        history(),
        drawSelection(),
        highlightActiveLine(),
        highlightSelectionMatches(),
        bracketMatching(),
        scrollPastEnd(),
        EditorView.lineWrapping,
        markdown({ base: markdownLanguage, addKeymap: true }),
        velEditorTheme,
        velHighlighting,
        livePreview(),
        Prec.highest(
          keymap.of([
            {
              key: 'ArrowDown',
              run: () => keyRef.current(new KeyboardEvent('keydown', { key: 'ArrowDown' })),
            },
            {
              key: 'ArrowUp',
              run: () => keyRef.current(new KeyboardEvent('keydown', { key: 'ArrowUp' })),
            },
            {
              key: 'Enter',
              run: () => keyRef.current(new KeyboardEvent('keydown', { key: 'Enter' })),
            },
            {
              key: 'Escape',
              run: () => keyRef.current(new KeyboardEvent('keydown', { key: 'Escape' })),
            },
            {
              key: 'Tab',
              run: () => keyRef.current(new KeyboardEvent('keydown', { key: 'Tab' })),
            },
          ]),
        ),
        keymap.of([...markdownKeymap(), ...defaultKeymap, ...historyKeymap, ...searchKeymap]),
        placeholder('Start writing…  type “/” for blocks, “[[” to link a note'),
        EditorView.updateListener.of((update) => {
          if (update.docChanged) {
            const value = update.view.state.doc.toString()
            lastEmitted.current = value
            if (saveTimer.current) clearTimeout(saveTimer.current)
            saveTimer.current = setTimeout(() => {
              updateNote(path, value)
            }, 110)
          }
          if (update.docChanged || update.selectionSet || update.focusChanged) {
            const view = update.view
            requestAnimationFrame(() => {
              if (viewRef.current === view) computeSuggest(view)
            })
          }
        }),
        EditorView.domEventHandlers({
          mousedown: (event, view) => {
            const target = event.target as HTMLElement | null
            if (!target) return false
            const task = target.closest('[data-task-pos]') as HTMLElement | null
            if (task) {
              event.preventDefault()
              const pos = Number(task.getAttribute('data-task-pos'))
              if (Number.isFinite(pos)) toggleTask(view, pos)
              return true
            }
            const wiki = target.closest('[data-wikilink]') as HTMLElement | null
            if (wiki) {
              const dest = wiki.getAttribute('data-wikilink') || ''
              if (dest) {
                event.preventDefault()
                useStore.getState().openNote(dest)
                return true
              }
            }
            const link = target.closest('[data-href]') as HTMLElement | null
            if (link) {
              const href = link.getAttribute('data-href') || ''
              if (/^https?:/i.test(href)) {
                event.preventDefault()
                window.open(href, '_blank', 'noopener,noreferrer')
                return true
              }
            }
            return false
          },
        }),
      ],
    })

    const view = new EditorView({ state, parent: wrap })
    viewRef.current = view
    registerView(paneIndex, view)

    const onScroll = () => {
      if (suggestRef.current) computeSuggest(view)
    }
    view.scrollDOM.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      view.scrollDOM.removeEventListener('scroll', onScroll)
      if (saveTimer.current) clearTimeout(saveTimer.current)
      unregisterView(paneIndex, view)
      view.destroy()
      viewRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* ----------------------------------------------- external content updates */
  useEffect(() => {
    const view = viewRef.current
    if (!view) return
    if (lastEmitted.current === content) {
      lastEmitted.current = null
      return
    }
    const current = view.state.doc.toString()
    if (current === content) return
    const head = Math.min(view.state.selection.main.head, content.length)
    view.dispatch({
      changes: { from: 0, to: view.state.doc.length, insert: content },
      selection: { anchor: head },
    })
  }, [content])

  return (
    <div className="relative flex-1 min-h-0 vellum-editor">
      <div ref={wrapRef} className="absolute inset-0 overflow-hidden" />
      {suggest && items.length > 0 && (
        <div
          className="suggest-menu z-[45] w-[330px] max-h-[272px] overflow-y-auto rounded-xl border border-line bg-elev p-1.5 card-shadow"
          style={{
            left: suggest.x,
            top: suggest.y,
            transform: suggest.above ? 'translateY(-100%)' : undefined,
          }}
          onMouseDown={(e) => e.preventDefault()}
        >
          <div className="px-2 pb-1 pt-0.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-muted">
            {suggest.mode === 'slash' ? 'Insert block' : 'Link to note'}
          </div>
          {items.map((item, i) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onMouseEnter={() => setActiveIndex(i)}
                onClick={() => applyItem(item)}
                className={cls(
                  'flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left text-[13px]',
                  i === activeIndex ? 'bg-accent-soft text-ink' : 'text-ink/85 hover:bg-elev',
                )}
              >
                <span className="flex size-6 shrink-0 items-center justify-center rounded-md border border-line bg-panel text-muted">
                  {Icon ? <Icon size={13} /> : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{item.label}</span>
                  <span className="block truncate text-[11px] text-muted">{item.hint}</span>
                </span>
                {i === activeIndex && <span className="text-[10px] text-muted">↵</span>}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
