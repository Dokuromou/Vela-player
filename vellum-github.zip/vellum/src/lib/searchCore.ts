/** Pure search core — shared by the Web Worker and the main-thread fallback. */
import type { SearchDoc, SearchHit } from '../types'

const STOP = new Set(['the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'is', 'it', 'on', 'for', 'with', 'as', 'at', 'by'])

export function tokenize(text: string): string[] {
  const out: string[] = []
  const lower = text.toLowerCase()
  let i = 0
  const len = lower.length
  let buf = ''
  while (i < len) {
    const c = lower.charCodeAt(i)
    const isWord = (c >= 97 && c <= 122) || (c >= 48 && c <= 57) || c === 95 || c === 45 || c === 47
    if (isWord) {
      if (buf.length < 42) buf += lower[i]
    } else if (buf) {
      if (buf.length > 1) out.push(buf)
      buf = ''
    }
    i++
  }
  if (buf.length > 1) out.push(buf)
  return out
}

interface DocEntry extends SearchDoc {
  lowerTitle: string
  lowerText: string
  tokens: string[]
}

export class SearchIndex {
  private docs = new Map<string, DocEntry>()
  private postings = new Map<string, Map<string, number>>()

  get size(): number {
    return this.docs.size
  }

  clear(): void {
    this.docs.clear()
    this.postings.clear()
  }

  upsert(doc: SearchDoc): void {
    this.remove(doc.path)
    const tokens = tokenize(`${doc.title} ${doc.title} ${doc.text}`)
    const entry: DocEntry = {
      ...doc,
      lowerTitle: doc.title.toLowerCase(),
      lowerText: doc.text.toLowerCase(),
      tokens,
    }
    this.docs.set(doc.path, entry)
    for (const t of tokens) {
      let posting = this.postings.get(t)
      if (!posting) {
        posting = new Map()
        this.postings.set(t, posting)
      }
      posting.set(doc.path, (posting.get(doc.path) || 0) + 1)
    }
  }

  remove(path: string): void {
    const entry = this.docs.get(path)
    if (!entry) return
    const counts = new Map<string, number>()
    for (const t of entry.tokens) counts.set(t, (counts.get(t) || 0) + 1)
    for (const [t, c] of counts) {
      const posting = this.postings.get(t)
      if (!posting) continue
      const prev = posting.get(path) || 0
      const next = prev - c
      if (next > 0) posting.set(path, next)
      else posting.delete(path)
      if (!posting.size) this.postings.delete(t)
    }
    this.docs.delete(path)
  }

  query(rawQuery: string, limit = 40): SearchHit[] {
    const q = rawQuery.trim().toLowerCase()
    if (q.length === 0) return []
    const scores = new Map<string, number>()
    const tokens = tokenize(q)

    // phrase bonus / substring pass (handles punctuation-y queries)
    for (const [path, doc] of this.docs) {
      let s = 0
      const titleIdx = doc.lowerTitle.indexOf(q)
      if (titleIdx >= 0) s += 120 - titleIdx
      if (doc.lowerTitle.startsWith(q)) s += 80
      const textIdx = doc.lowerText.indexOf(q)
      if (textIdx >= 0) s += 24
      if (s > 0) scores.set(path, s)
    }

    for (const token of tokens) {
      if (STOP.has(token)) continue
      const posting = this.postings.get(token)
      if (posting) {
        for (const [path, count] of posting) {
          scores.set(path, (scores.get(path) || 0) + 8 + Math.min(18, Math.log2(1 + count) * 7))
        }
      }
      // prefix matches (typeahead: "desi" -> "design")
      if (token.length >= 2) {
        for (const [indexed, posting] of this.postings) {
          if (indexed === token || !indexed.startsWith(token)) continue
          for (const [path, count] of posting) {
            scores.set(path, (scores.get(path) || 0) + 3 + Math.min(8, Math.log2(1 + count) * 3))
          }
        }
      }
    }

    const hits: SearchHit[] = []
    for (const [path, score] of scores) {
      const doc = this.docs.get(path)
      if (!doc) continue
      hits.push({ path, title: doc.title, score, snippet: snippet(doc, q, tokens) })
    }
    hits.sort((a, b) => b.score - a.score || a.title.localeCompare(b.title))
    return hits.slice(0, limit)
  }
}

function snippet(doc: DocEntry, q: string, tokens: string[]): string {
  const text = doc.text
  const lower = doc.lowerText
  let idx = lower.indexOf(q)
  if (idx < 0) {
    for (const t of tokens) {
      idx = lower.indexOf(t)
      if (idx >= 0) break
    }
  }
  if (idx < 0) return text.replace(/\s+/g, ' ').slice(0, 140)
  const start = Math.max(0, idx - 48)
  const end = Math.min(text.length, idx + 110)
  const piece = text.slice(start, end).replace(/\s+/g, ' ').trim()
  return `${start > 0 ? '…' : ''}${piece}${end < text.length ? '…' : ''}`
}
