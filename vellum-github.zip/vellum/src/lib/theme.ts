import type { Theme } from '../types'

export function applyTheme(theme: Theme): void {
  if (typeof document === 'undefined') return
  document.documentElement.dataset.theme = theme
  try {
    localStorage.setItem('vellum.theme', theme)
  } catch {
    /* ignore */
  }
  const meta = document.querySelector('meta[name="theme-color"]')
  if (meta) {
    meta.setAttribute('content', theme === 'dark' ? '#0d0f14' : theme === 'light' ? '#ffffff' : '#f7efe1')
  }
}

export function loadTheme(): Theme {
  try {
    const t = localStorage.getItem('vellum.theme')
    if (t === 'dark' || t === 'light' || t === 'paper') return t
  } catch {
    /* ignore */
  }
  return 'dark'
}

export const THEMES: { id: Theme; label: string; swatch: string; bg: string }[] = [
  { id: 'dark', label: 'Dark', swatch: '#7c9cff', bg: '#0d0f14' },
  { id: 'light', label: 'Light', swatch: '#3b62e8', bg: '#ffffff' },
  { id: 'paper', label: 'Warm Paper', swatch: '#b06a34', bg: '#f7efe1' },
]
