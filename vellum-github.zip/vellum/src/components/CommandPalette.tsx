import { useEffect, useMemo, useRef, useState } from 'react'
import {
  BookOpen,
  CalendarDays,
  Columns3,
  Command,
  Download,
  FilePlus2,
  FileText,
  FolderOpen,
  HardDrive,
  Moon,
  PanelLeft,
  PanelRight,
  Search,
  Share2,
  Sparkles,
  Sun,
  SplitSquareHorizontal,
  CornerDownLeft,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useStore } from '../store/useStore'
import { cls, fuzzyScore, MOD_KEY, todayISO } from '../lib/utils'
import { dirname } from '../lib/markdown'

interface PaletteItem {
  id: string
  label: string
  hint: string
  icon: LucideIcon
  group: 'Notes' | 'Commands'
  run: () => void
}

export function CommandPalette() {
  const open = useStore((s) => s.paletteOpen)
  const initialMode = useStore((s) => s.paletteMode)
  const setPalette = useStore((s) => s.setPalette)
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const createNote = useStore((s) => s.createNote)
  const openDaily = useStore((s) => s.openDaily)
  const openFolder = useStore((s) => s.openFolder)
  const useLocalVault = useStore((s) => s.useLocalVault)
  const setTheme = useStore((s) => s.setTheme)
  const toggleSidebar = useStore((s) => s.toggleSidebar)
  const toggleRight = useStore((s) => s.toggleRight)
  const setGraphOpen = useStore((s) => s.setGraphOpen)
  const setView = useStore((s) => s.setView)
  const splitPane = useStore((s) => s.splitPane)
  const exportVault = useStore((s) => s.exportVault)
  const seedSamples = useStore((s) => s.seedSamples)
  const activePath = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ?? null
  })

  const [query, setQuery] = useState('')
  const [index, setIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement | null>(null)
  const listRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (open) {
      setQuery(initialMode === 'commands' ? '>' : '')
      setIndex(0)
      requestAnimationFrame(() => inputRef.current?.focus())
    }
  }, [open, initialMode])

  const commands: PaletteItem[] = useMemo(() => {
    const close = () => setPalette(false)
    const folder = activePath ? dirname(activePath) : ''
    return [
      {
        id: 'cmd:new',
        label: 'New note',
        hint: 'create a note in the vault root',
        icon: FilePlus2,
        group: 'Commands',
        run: () => {
          close()
          createNote('')
        },
      },
      {
        id: 'cmd:daily',
        label: "Open today's daily note",
        hint: todayISO(),
        icon: CalendarDays,
        group: 'Commands',
        run: () => {
          close()
          openDaily(todayISO())
        },
      },
      {
        id: 'cmd:graph',
        label: 'Open knowledge graph',
        hint: 'global force-directed graph',
        icon: Share2,
        group: 'Commands',
        run: () => {
          close()
          setGraphOpen(true)
        },
      },
      {
        id: 'cmd:table',
        label: 'Current folder as table',
        hint: folder || 'vault root',
        icon: Columns3,
        group: 'Commands',
        run: () => {
          close()
          setView({ mode: 'table', folder })
        },
      },
      {
        id: 'cmd:kanban',
        label: 'Current folder as Kanban',
        hint: folder || 'vault root',
        icon: Columns3,
        group: 'Commands',
        run: () => {
          close()
          setView({ mode: 'kanban', folder })
        },
      },
      {
        id: 'cmd:split',
        label: 'Split editor',
        hint: 'two notes side by side',
        icon: SplitSquareHorizontal,
        group: 'Commands',
        run: () => {
          close()
          splitPane()
        },
      },
      {
        id: 'cmd:sidebar',
        label: 'Toggle sidebar',
        hint: 'file tree & search',
        icon: PanelLeft,
        group: 'Commands',
        run: () => {
          close()
          toggleSidebar()
        },
      },
      {
        id: 'cmd:right',
        label: 'Toggle right sidebar',
        hint: 'outline · backlinks · graph',
        icon: PanelRight,
        group: 'Commands',
        run: () => {
          close()
          toggleRight()
        },
      },
      {
        id: 'cmd:theme-dark',
        label: 'Theme: Dark',
        hint: 'switch appearance',
        icon: Moon,
        group: 'Commands',
        run: () => {
          close()
          setTheme('dark')
        },
      },
      {
        id: 'cmd:theme-light',
        label: 'Theme: Light',
        hint: 'switch appearance',
        icon: Sun,
        group: 'Commands',
        run: () => {
          close()
          setTheme('light')
        },
      },
      {
        id: 'cmd:theme-paper',
        label: 'Theme: Warm Paper',
        hint: 'switch appearance',
        icon: BookOpen,
        group: 'Commands',
        run: () => {
          close()
          setTheme('paper')
        },
      },
      {
        id: 'cmd:folder',
        label: 'Open local folder…',
        hint: 'File System Access API',
        icon: FolderOpen,
        group: 'Commands',
        run: () => {
          close()
          void openFolder()
        },
      },
      {
        id: 'cmd:local',
        label: 'Switch to browser vault',
        hint: 'IndexedDB storage',
        icon: HardDrive,
        group: 'Commands',
        run: () => {
          close()
          void useLocalVault()
        },
      },
      {
        id: 'cmd:samples',
        label: 'Add sample notes',
        hint: 'seed the demo vault',
        icon: Sparkles,
        group: 'Commands',
        run: () => {
          close()
          void seedSamples()
        },
      },
      {
        id: 'cmd:export',
        label: 'Export vault',
        hint: 'download every note as JSON',
        icon: Download,
        group: 'Commands',
        run: () => {
          close()
          exportVault()
        },
      },
    ]
  }, [
    activePath,
    createNote,
    exportVault,
    openDaily,
    openFolder,
    seedSamples,
    setGraphOpen,
    setPalette,
    setTheme,
    setView,
    splitPane,
    toggleRight,
    toggleSidebar,
    useLocalVault,
  ])

  const isCommandMode = query.trimStart().startsWith('>')
  const term = isCommandMode ? query.trimStart().slice(1).trim() : query.trim()

  const items: PaletteItem[] = useMemo(() => {
    if (isCommandMode) {
      return commands
        .map((c) => ({ c, score: term ? Math.max(fuzzyScore(term, c.label), fuzzyScore(term, c.hint)) : 1 }))
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 12)
        .map((x) => x.c)
    }
    const noteItems = Object.values(notes)
      .map((n) => ({
        n,
        score: term ? Math.max(fuzzyScore(term, n.title), fuzzyScore(term, n.path) - 40) : n.path === activePath ? 50 : 1,
      }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score || a.n.title.localeCompare(b.n.title))
      .slice(0, 14)
      .map<PaletteItem>(({ n }) => ({
        id: `note:${n.path}`,
        label: n.title,
        hint: dirname(n.path) || 'vault root',
        icon: FileText,
        group: 'Notes',
        run: () => {
          setPalette(false)
          openNote(n.path)
        },
      }))
    if (!term) {
      return noteItems
    }
    const createItem: PaletteItem = {
      id: 'create',
      label: `Create “${term}”`,
      hint: 'new note in vault root',
      icon: FilePlus2,
      group: 'Notes',
      run: () => {
        setPalette(false)
        createNote('', term)
      },
    }
    return [...noteItems, createItem]
  }, [isCommandMode, term, commands, notes, openNote, createNote, setPalette, activePath])

  useEffect(() => {
    setIndex(0)
  }, [term, isCommandMode])

  useEffect(() => {
    if (!open) return
    const el = listRef.current?.querySelector<HTMLElement>(`[data-index="${index}"]`)
    el?.scrollIntoView({ block: 'nearest' })
  }, [index, open])

  if (!open) return null

  const groups: PaletteItem['group'][] = isCommandMode ? ['Commands'] : ['Notes']

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center bg-black/45 p-4 pt-[10vh] backdrop-blur-[2px]" onMouseDown={() => setPalette(false)}>
      <div
        className="w-full max-w-[620px] overflow-hidden rounded-2xl border border-line bg-elev card-shadow anim-pop"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 border-b border-line px-3.5 py-2.5">
          {isCommandMode ? <Command size={15} className="text-accent" /> : <Search size={15} className="text-muted" />}
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                e.preventDefault()
                setIndex((i) => (items.length ? (i + 1) % items.length : 0))
              } else if (e.key === 'ArrowUp') {
                e.preventDefault()
                setIndex((i) => (items.length ? (i - 1 + items.length) % items.length : 0))
              } else if (e.key === 'Enter') {
                e.preventDefault()
                items[index]?.run()
              } else if (e.key === 'Escape') {
                e.preventDefault()
                setPalette(false)
              }
            }}
            placeholder="Search notes…  (type > for commands)"
            className="w-full bg-transparent text-[14px] text-ink outline-none placeholder:text-muted/80"
          />
          <span className="rounded border border-line bg-panel px-1.5 py-0.5 text-[10px] text-muted">esc</span>
        </div>

        <div ref={listRef} className="max-h-[46vh] overflow-y-auto p-1.5">
          {groups.map((group) => {
            const groupItems = items.filter((i) => i.group === group)
            if (!groupItems.length) return null
            return (
              <div key={group}>
                <div className="px-2 pb-1 pt-1.5 text-[10px] font-semibold uppercase tracking-[0.09em] text-muted">{group}</div>
                {groupItems.map((item) => {
                  const globalIndex = items.indexOf(item)
                  const Icon = item.icon
                  return (
                    <button
                      key={item.id}
                      data-index={globalIndex}
                      type="button"
                      onMouseEnter={() => setIndex(globalIndex)}
                      onClick={() => item.run()}
                      className={cls(
                        'flex w-full items-center gap-2.5 rounded-lg px-2 py-[7px] text-left text-[13px] transition-colors',
                        globalIndex === index ? 'bg-accent-soft text-ink' : 'text-ink/85 hover:bg-panel',
                      )}
                    >
                      <Icon size={14} className={globalIndex === index ? 'text-accent' : 'text-muted'} />
                      <span className="min-w-0 flex-1 truncate font-medium">{item.label}</span>
                      <span className="max-w-[45%] truncate text-[11px] text-muted">{item.hint}</span>
                      {globalIndex === index ? <CornerDownLeft size={12} className="text-muted" /> : null}
                    </button>
                  )
                })}
              </div>
            )
          })}
          {!items.length && <div className="px-3 py-8 text-center text-[12.5px] text-muted">Nothing matches “{term}”.</div>}
        </div>

        <div className="flex items-center gap-3 border-t border-line px-3 py-1.5 text-[10px] text-muted">
          <span className="flex items-center gap-1">
            <span className="rounded border border-line px-1">↑↓</span> navigate
          </span>
          <span className="flex items-center gap-1">
            <span className="rounded border border-line px-1">↵</span> open
          </span>
          <span className="ml-auto">
            {MOD_KEY}P files · {MOD_KEY}⇧P commands
          </span>
        </div>
      </div>
    </div>
  )
}
