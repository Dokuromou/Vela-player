import { HighlightStyle, syntaxHighlighting } from '@codemirror/language'
import { EditorView } from '@codemirror/view'
import { tags as t } from '@lezer/highlight'

export const velEditorTheme = EditorView.theme({
  '&': {
    height: '100%',
    backgroundColor: 'transparent',
    color: 'var(--ink)',
    fontSize: '16px',
  },
  '.cm-scroller': {
    fontFamily: 'var(--font-sans)',
    lineHeight: '1.78',
    overflowY: 'auto',
  },
  '.cm-content': {
    caretColor: 'var(--accent)',
    maxWidth: '860px',
    margin: '0 auto',
  },
  '.cm-line': {
    padding: '0 56px',
  },
  '.cm-activeLine': {
    backgroundColor: 'color-mix(in srgb, var(--accent) 5%, transparent)',
  },
  '&.cm-focused .cm-cursor': {
    borderLeftColor: 'var(--accent)',
  },
  '.cm-panels': {
    backgroundColor: 'var(--panel)',
    color: 'var(--ink)',
  },
  '.cm-tooltip': {
    backgroundColor: 'var(--elev)',
    border: '1px solid var(--line)',
    borderRadius: '10px',
    boxShadow: 'var(--shadow)',
    color: 'var(--ink)',
    fontFamily: 'var(--font-sans)',
  },
  '.cm-tooltip-autocomplete > ul > li[aria-selected]': {
    backgroundColor: 'var(--accent-soft)',
    color: 'var(--ink)',
  },
})

export const velHighlightStyle = HighlightStyle.define([
  { tag: t.heading1, color: 'var(--syn-head)', fontWeight: '700' },
  { tag: t.heading2, color: 'var(--syn-head)', fontWeight: '700' },
  { tag: t.heading3, color: 'var(--syn-head)', fontWeight: '600' },
  { tag: t.heading4, color: 'var(--syn-head)', fontWeight: '600' },
  { tag: t.heading5, color: 'var(--syn-head)', fontWeight: '600' },
  { tag: t.heading6, color: 'var(--syn-head)', fontWeight: '600' },
  { tag: t.strong, color: 'var(--syn-strong)', fontWeight: '700' },
  { tag: t.emphasis, fontStyle: 'italic' },
  { tag: t.strikethrough, textDecoration: 'line-through' },
  { tag: t.monospace, fontFamily: 'var(--font-mono)', color: 'var(--syn-code)' },
  { tag: t.link, color: 'var(--syn-link)' },
  { tag: t.url, color: 'var(--muted)' },
  { tag: t.quote, color: 'var(--muted)' },
  { tag: t.list, color: 'var(--accent)' },
  { tag: t.contentSeparator, color: 'var(--syn-marker)' },
  { tag: t.processingInstruction, color: 'var(--syn-marker)' },
  { tag: t.labelName, color: 'var(--muted)' },
  { tag: t.meta, color: 'var(--muted)' },
])

export const velHighlighting = syntaxHighlighting(velHighlightStyle)
