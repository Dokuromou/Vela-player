import { Decoration, type DecorationSet, EditorView, ViewPlugin, type ViewUpdate, WidgetType } from '@codemirror/view'
import type { Range } from '@codemirror/state'
import { buildTitleIndex, resolveLink, splitFrontmatter } from '../lib/markdown'
import { useStore } from '../store/useStore'

/* ------------------------------------------------------------------ widgets */
class TaskWidget extends WidgetType {
  constructor(readonly pos: number, readonly checked: boolean) {
    super()
  }
  eq(other: TaskWidget) {
    return other.pos === this.pos && other.checked === this.checked
  }
  toDOM() {
    const span = document.createElement('span')
    span.className = 'vel-task-widget'
    span.setAttribute('data-task-pos', String(this.pos))
    span.setAttribute('role', 'checkbox')
    span.setAttribute('aria-checked', String(this.checked))
    span.innerHTML =
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>'
    return span
  }
  ignoreEvent() {
    return false
  }
}

class BulletWidget extends WidgetType {
  eq() {
    return true
  }
  toDOM() {
    const span = document.createElement('span')
    span.className = 'vel-bullet'
    span.textContent = '•'
    return span
  }
}

class HrWidget extends WidgetType {
  eq() {
    return true
  }
  toDOM() {
    const span = document.createElement('span')
    span.className = 'vel-hr-widget'
    return span
  }
}

class TableRowWidget extends WidgetType {
  constructor(
    readonly cells: string[],
    readonly widths: number[],
    readonly header: boolean,
    readonly first: boolean,
    readonly last: boolean,
    readonly divider: boolean,
  ) {
    super()
  }
  eq(other: TableRowWidget) {
    return (
      other.header === this.header &&
      other.first === this.first &&
      other.last === this.last &&
      other.divider === this.divider &&
      other.cells.join('\u0001') === this.cells.join('\u0001') &&
      other.widths.join(',') === this.widths.join(',')
    )
  }
  toDOM() {
    if (this.divider) {
      const div = document.createElement('div')
      div.className = 'vel-tdivider'
      return div
    }
    const row = document.createElement('div')
    row.className = `vel-trow${this.header ? ' is-header' : ''}${this.first ? ' is-first' : ''}${this.last ? ' is-last' : ''}`
    row.style.gridTemplateColumns = this.widths.map((w) => `minmax(0, ${w}fr)`).join(' ')
    for (const cellText of this.cells) {
      const cell = document.createElement('div')
      cell.className = 'vel-tcell'
      cell.appendChild(renderCell(cellText))
      row.appendChild(cell)
    }
    return row
  }
  ignoreEvent() {
    return false
  }
}

/** very small inline renderer for table cells: bold, code, wiki-links */
function renderCell(text: string): DocumentFragment {
  const frag = document.createDocumentFragment()
  const re = /(!?\[\[([^\]\n]+?)\]\])|(\*\*([^*]+)\*\*)|(`([^`]+)`)/g
  let last = 0
  let m: RegExpExecArray | null
  while ((m = re.exec(text))) {
    if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)))
    if (m[1]) {
      const inner = m[2]
      const [targetPart, alias] = inner.split('|')
      const [tRaw, heading] = targetPart.split('#')
      const label = alias?.trim() || (heading ? `${tRaw.trim()} › ${heading.trim()}` : tRaw.trim())
      const span = document.createElement('span')
      span.className = 'vel-wikilink'
      span.setAttribute('data-wikilink', tRaw.trim())
      span.textContent = label
      frag.appendChild(span)
    } else if (m[3]) {
      const strong = document.createElement('strong')
      strong.textContent = m[4]
      frag.appendChild(strong)
    } else if (m[5]) {
      const code = document.createElement('span')
      code.className = 'vel-code'
      code.textContent = m[6]
      frag.appendChild(code)
    }
    last = m.index + m[0].length
  }
  if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)))
  return frag
}

class WikiLinkWidget extends WidgetType {
  constructor(readonly target: string, readonly label: string, readonly missing: boolean) {
    super()
  }
  eq(other: WikiLinkWidget) {
    return other.target === this.target && other.label === this.label && other.missing === this.missing
  }
  toDOM() {
    const span = document.createElement('span')
    span.className = `vel-wikilink${this.missing ? ' is-missing' : ''}`
    span.setAttribute('data-wikilink', this.target)
    span.textContent = this.label
    span.title = this.missing ? `${this.target} — click to create` : this.target
    return span
  }
  ignoreEvent() {
    return false
  }
}

class CalloutHeaderWidget extends WidgetType {
  constructor(readonly type: string, readonly title: string, readonly icon: string) {
    super()
  }
  eq(other: CalloutHeaderWidget) {
    return other.type === this.type && other.title === this.title
  }
  toDOM() {
    const span = document.createElement('span')
    span.className = 'vel-callout-head'
    const icon = document.createElement('span')
    icon.className = 'vel-callout-icon'
    icon.textContent = this.icon
    span.appendChild(icon)
    const label = document.createElement('span')
    label.textContent = this.title
    span.appendChild(label)
    return span
  }
}

const CALLOUT_ICONS: Record<string, string> = {
  note: 'ℹ',
  info: 'ℹ',
  tip: '✦',
  hint: '✦',
  success: '✓',
  check: '✓',
  warning: '⚠',
  caution: '⚠',
  danger: '⛔',
  error: '⛔',
  quote: '❞',
  todo: '☑',
  example: '❖',
  question: '?',
}

const CALLOUT_TYPES = Object.keys(CALLOUT_ICONS)
const hide = Decoration.replace({})

function isTableLine(text: string): boolean {
  return /^\s*\|.*\|\s*$/.test(text)
}

function isDividerLine(raw: string): boolean {
  return /^\|[\s:|-]+\|$/.test(raw) && raw.includes('-')
}

export function splitCells(raw: string): string[] {
  const inner = raw.replace(/^\|/, '').replace(/\|$/, '')
  return inner.split('|').map((c) => c.trim())
}
const lineDeco = (cls: string) => Decoration.line({ class: cls })

type Item = { from: number; to: number; deco: Decoration; isLine?: boolean }

/* --------------------------------------------------------------- decorator */
function build(view: EditorView): DecorationSet {
  const { doc, selection } = view.state
  const focused = view.hasFocus
  const activeLines = new Set<number>()
  if (focused) {
    for (const range of selection.ranges) {
      const from = doc.lineAt(range.from).number
      const to = doc.lineAt(range.to).number
      for (let l = from; l <= to; l++) activeLines.add(l)
    }
  }

  const notes = useStore.getState().notes
  const titleIndex = buildTitleIndex(notes)

  const out: Range<Decoration>[] = []
  let startLine = 1

  // ---- frontmatter: styled dim, and collapsed while the cursor is elsewhere
  if (doc.lines >= 2 && doc.line(1).text.trim() === '---') {
    let closeLine = -1
    for (let i = 2; i <= doc.lines; i++) {
      if (doc.line(i).text.trim() === '---') {
        closeLine = i
        break
      }
    }
    if (closeLine > 0) {
      let inside = false
      for (const l of activeLines) if (l >= 1 && l <= closeLine) inside = true
      for (let i = 1; i <= closeLine; i++) {
        const line = doc.line(i)
        const collapsed = !inside
        out.push(
          lineDeco(`vel-fm-line${collapsed ? ' vel-fm-collapsed' : ''}`).range(line.from, line.from),
        )
      }
      startLine = closeLine + 1
    }
  }

  let inFence = false
  let calloutOpen = false

  for (let i = startLine; i <= doc.lines; i++) {
    const line = doc.line(i)
    const text = line.text
    const active = activeLines.has(i)
    const lineFrom = line.from
    const lineItems: Item[] = []
    const occupied: [number, number][] = []

    const add = (from: number, to: number, deco: Decoration) => {
      const start = Math.max(lineFrom, from)
      const end = Math.min(line.to, to)
      if (start >= end) return
      if (occupied.some(([a, b]) => start < b && end > a)) return
      occupied.push([start, end])
      lineItems.push({ from: start, to: end, deco })
    }
    const addLine = (cls: string) => lineItems.push({ from: lineFrom, to: lineFrom, deco: lineDeco(cls), isLine: true })

    // ---- fenced code
    const fenceMatch = /^\s*(```+|~~~+)/.exec(text)
    if (fenceMatch) {
      inFence = !inFence
      addLine('vel-code-fence')
      if (!active) {
        // hide the fence itself, and tag the line so it reads as a code block edge
        if (!inFence) add(lineFrom, line.to, hide)
        else add(lineFrom, line.to, hide)
      }
      pushLine(out, lineItems)
      continue
    }
    if (inFence) {
      addLine('vel-code-line')
      pushLine(out, lineItems)
      continue
    }

    // ---- horizontal rule
    if (!active && /^\s*([-*_])(\s*\1){2,}\s*$/.test(text)) {
      add(lineFrom, line.to, Decoration.replace({ widget: new HrWidget() }))
      pushLine(out, lineItems)
      continue
    }

    // ---- tables (rendered as a real table; raw while the caret is inside)
    if (isTableLine(text)) {
      let end = i
      while (end < doc.lines && isTableLine(doc.line(end + 1).text)) end++
      let editing = false
      for (let k = i; k <= end; k++) if (activeLines.has(k)) editing = true

      const rows: string[][] = []
      let dividerIndex = -1
      for (let k = i; k <= end; k++) {
        const raw = doc.line(k).text.trim()
        if (isDividerLine(raw)) dividerIndex = k - i
        rows.push(splitCells(raw))
      }
      const colCount = Math.max(...rows.map((r) => r.length), 1)
      const widths = Array.from({ length: colCount }, (_, c) =>
        Math.min(26, Math.max(6, ...rows.map((r) => (r[c] || '').length))),
      )

      void editing
      for (let k = i; k <= end; k++) {
        const line = doc.line(k)
        if (activeLines.has(k)) {
          lineItems.push({ from: line.from, to: line.from, deco: lineDeco('vel-table-raw'), isLine: true })
        } else {
          const isDivider = k - i === dividerIndex
          const isHeader = dividerIndex > 0 ? k - i < dividerIndex : k === i
          const widget = new TableRowWidget(
            isDivider ? [] : rows[k - i],
            widths,
            isHeader,
            k === i,
            k === end,
            isDivider,
          )
          out.push(lineDeco('vel-table-line').range(line.from, line.from))
          out.push(Decoration.replace({ widget }).range(line.from, line.to))
        }
      }
      i = end
      continue
    }

    // ---- callout header
    const calloutMatch = /^(\s*)>\s*\[!(\w+)\]([+-]?)\s*(.*)$/.exec(text)
    if (calloutMatch) {
      const rawType = calloutMatch[2].toLowerCase()
      const type = CALLOUT_TYPES.includes(rawType) ? rawType : 'note'
      calloutOpen = true
      addLine(`vel-callout vel-callout-${type}`)
      if (!active) {
        const title = calloutMatch[4].trim() || type.charAt(0).toUpperCase() + type.slice(1)
        add(
          lineFrom,
          line.to,
          Decoration.replace({ widget: new CalloutHeaderWidget(type, title, CALLOUT_ICONS[type] || 'ℹ') }),
        )
      }
      pushLine(out, lineItems)
      continue
    }

    // ---- blockquote continuation
    const quoteMatch = /^(\s*)>\s?([\s\S]*)$/.exec(text)
    if (quoteMatch) {
      addLine(`vel-quote${calloutOpen ? ' vel-callout-body' : ''}`)
      if (!active) {
        const markerPos = lineFrom + quoteMatch[1].length
        add(markerPos, markerPos + 1, hide)
        const rest = quoteMatch[2]
        const restFrom = lineFrom + text.length - rest.length
        if (rest.trim()) inlineScan(rest, restFrom, add, titleIndex)
      }
      pushLine(out, lineItems)
      continue
    }
    calloutOpen = false

    // ---- headings
    const headingMatch = /^(#{1,6})(\s+)([\s\S]*)$/.exec(text)
    if (headingMatch) {
      const level = headingMatch[1].length
      addLine(`vel-h vel-h${level}`)
      if (!active) {
        const markerEnd = lineFrom + headingMatch[1].length + headingMatch[2].length
        add(lineFrom, markerEnd, hide)
        if (headingMatch[3]) inlineScan(headingMatch[3], markerEnd, add, titleIndex)
      }
      pushLine(out, lineItems)
      continue
    }

    // ---- tasks
    const taskMatch = /^(\s*)([-*+])\s+\[([ xX])\]\s+/.exec(text)
    if (taskMatch) {
      const checked = taskMatch[3].toLowerCase() === 'x'
      addLine(`vel-task${checked ? ' vel-task-done' : ''}`)
      if (!active) {
        const bulletPos = lineFrom + taskMatch[1].length
        const bracketPos = lineFrom + taskMatch[0].indexOf('[')
        add(bulletPos, lineFrom + taskMatch[0].length, Decoration.replace({ widget: new TaskWidget(bracketPos, checked) }))
        const restFrom = lineFrom + taskMatch[0].length
        if (restFrom < line.to) inlineScan(doc.sliceString(restFrom, line.to), restFrom, add, titleIndex)
      }
      pushLine(out, lineItems)
      continue
    }

    // ---- bullets
    const bulletMatch = /^(\s*)([-*+])(\s+)/.exec(text)
    if (bulletMatch) {
      if (!active) {
        const bFrom = lineFrom + bulletMatch[1].length
        add(bFrom, bFrom + 1, Decoration.replace({ widget: new BulletWidget() }))
        const restFrom = lineFrom + bulletMatch[0].length
        if (restFrom < line.to) inlineScan(doc.sliceString(restFrom, line.to), restFrom, add, titleIndex)
      }
      pushLine(out, lineItems)
      continue
    }

    // ---- plain line
    if (!active && text.length) inlineScan(text, lineFrom, add, titleIndex)
    pushLine(out, lineItems)
  }

  return Decoration.set(out, true)
}

function pushLine(out: Range<Decoration>[], items: Item[]) {
  if (!items.length) return
  items.sort((a, b) => a.from - b.from || Number(b.isLine || false) - Number(a.isLine || false))
  const taken: [number, number][] = []
  for (const item of items) {
    if (!item.isLine) {
      const clash = taken.some(([a, b]) => item.from < b && item.to > a)
      if (clash) continue
      taken.push([item.from, item.to])
    }
    out.push(item.deco.range(item.from, item.to))
  }
}

/* ------------------------------------------------------------ inline scan */
type AddFn = (from: number, to: number, deco: Decoration) => void

function splitOnce(s: string, sep: string): [string, string | undefined] {
  const i = s.indexOf(sep)
  if (i === -1) return [s, undefined]
  return [s.slice(0, i), s.slice(i + 1)]
}

function inlineScan(text: string, base: number, add: AddFn, titleIndex: Map<string, string>) {
  if (!text) return
  let m: RegExpExecArray | null

  // wiki links & embeds
  const wikiRe = /!?\[\[([^\]\n]+?)\]\]/g
  while ((m = wikiRe.exec(text))) {
    const inner = m[1]
    const [beforeAlias, alias] = splitOnce(inner, '|')
    const [targetPart, heading] = splitOnce(beforeAlias, '#')
    const target = targetPart.trim()
    const resolved = target ? resolveLink(titleIndex, target) : null
    const noteName = resolved ? resolved.replace(/^.*\//, '').replace(/\.md$/i, '') : target
    const label = alias?.trim() || (heading ? `${noteName} › ${heading.trim()}` : noteName)
    const missing = target ? !resolved : false
    add(base + m.index, base + m.index + m[0].length, Decoration.replace({ widget: new WikiLinkWidget(target, label, missing) }))
  }

  // inline code
  const codeRe = /`([^`\n]+)`/g
  while ((m = codeRe.exec(text))) {
    const from = base + m.index
    const to = from + m[0].length
    add(from, from + 1, hide)
    add(from + 1, to - 1, Decoration.mark({ class: 'vel-code' }))
    add(to - 1, to, hide)
  }

  // bold
  const boldRe = /\*\*(?=\S)([\s\S]*?\S)\*\*/g
  while ((m = boldRe.exec(text))) {
    const from = base + m.index
    const to = from + m[0].length
    add(from, from + 2, hide)
    add(from + 2, to - 2, Decoration.mark({ class: 'vel-strong' }))
    add(to - 2, to, hide)
  }

  // strikethrough
  const strikeRe = /~~(?=\S)([\s\S]*?\S)~~/g
  while ((m = strikeRe.exec(text))) {
    const from = base + m.index
    const to = from + m[0].length
    add(from, from + 2, hide)
    add(from + 2, to - 2, Decoration.mark({ class: 'vel-strike' }))
    add(to - 2, to, hide)
  }

  // markdown links
  const linkRe = /\[([^\]\n]+)\]\(([^)\n]*)\)/g
  while ((m = linkRe.exec(text))) {
    const from = base + m.index
    const to = from + m[0].length
    const labelEnd = from + 1 + m[1].length
    add(from, from + 1, hide)
    add(from + 1, labelEnd, Decoration.mark({ class: 'vel-link', attributes: { 'data-href': m[2] } }))
    add(labelEnd, to, hide)
  }

  // italic — *text* or _text_
  const italicRe = /(^|[\s(])([*_])(?=\S)([^*_\n]*?\S)\2(?=[\s).,;:!?]|$)/g
  while ((m = italicRe.exec(text))) {
    const markerOffset = m[0].indexOf(m[2])
    const start = base + m.index + markerOffset
    const end = start + 1 + m[3].length + 1
    add(start, start + 1, hide)
    add(start + 1, end - 1, Decoration.mark({ class: 'vel-em' }))
    add(end - 1, end, hide)
  }

  // #tags
  const tagRe = /(^|[\s(])#([A-Za-z][\w/-]*)/g
  while ((m = tagRe.exec(text))) {
    const start = base + m.index + m[0].length - (1 + m[2].length)
    add(start, start + 1 + m[2].length, Decoration.mark({ class: 'vel-tag' }))
  }
}

/* ------------------------------------------------------------------- plugin */
export function livePreview() {
  return ViewPlugin.fromClass(
    class {
      decorations: DecorationSet
      constructor(view: EditorView) {
        this.decorations = build(view)
      }
      update(update: ViewUpdate) {
        if (update.docChanged || update.selectionSet || update.focusChanged || update.viewportChanged) {
          this.decorations = build(update.view)
        }
      }
    },
    {
      decorations: (v) => v.decorations,
    },
  )
}

/** Toggle a `- [ ]` checkbox: `bracketPos` is the offset of the "[" character. */
export function toggleTask(view: EditorView, bracketPos: number) {
  const charPos = bracketPos + 1
  const current = view.state.doc.sliceString(bracketPos, bracketPos + 3)
  if (!/^\[[ xX]\]$/.test(current)) return
  const checked = /x/i.test(current[1])
  view.dispatch({ changes: { from: charPos, to: charPos + 1, insert: checked ? ' ' : 'x' } })
}

export { splitFrontmatter }
