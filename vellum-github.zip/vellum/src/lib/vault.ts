import { idbAllNotes, idbClearNotes, idbDeleteNote, idbPutNote, kvGet, kvSet, kvDelete } from './db'
import type { VaultFile, VaultKind, VaultSnapshot } from '../types'

/* eslint-disable @typescript-eslint/no-explicit-any */
type DirHandle = any
type FileHandle = any

export interface Vault {
  kind: VaultKind
  name: string
  load(): Promise<VaultFile[]>
  write(path: string, content: string): Promise<void>
  remove(path: string): Promise<void>
  /** create an empty folder (File System vaults only; IndexedDB folders are implicit) */
  makeFolder?(path: string): Promise<void>
  /** re-request permissions after a reload */
  ensurePermission?(): Promise<boolean>
  forget?(): Promise<void>
}

const FS_HANDLE_KEY = 'fs-directory-handle'
const IDB_NAME_KEY = 'idb-vault-name'

/* ------------------------------------------------------------------ IndexedDB */
export class IdbVault implements Vault {
  kind: VaultKind = 'idb'
  name: string

  constructor(name = 'Local Vault') {
    this.name = name
  }

  static async restore(): Promise<IdbVault> {
    const name = (await kvGet<string>(IDB_NAME_KEY)) || 'Local Vault'
    return new IdbVault(name)
  }

  async load(): Promise<VaultFile[]> {
    const rows = await idbAllNotes()
    return rows.map((r) => ({ path: r.path, content: r.content }))
  }

  async write(path: string, content: string): Promise<void> {
    await idbPutNote({ path, content, modified: Date.now() })
  }

  async remove(path: string): Promise<void> {
    await idbDeleteNote(path)
  }

  async clear(): Promise<void> {
    await idbClearNotes()
  }

  async setName(name: string): Promise<void> {
    this.name = name
    await kvSet(IDB_NAME_KEY, name)
  }
}

/* --------------------------------------------------------- File System Access */
export function fsSupported(): boolean {
  return typeof window !== 'undefined' && typeof (window as any).showDirectoryPicker === 'function'
}

async function walk(dir: DirHandle, prefix = '', out: VaultFile[] = []): Promise<VaultFile[]> {
  for await (const entry of dir.values()) {
    const name: string = entry.name
    if (entry.kind === 'directory') {
      if (name.startsWith('.') || name === 'node_modules') continue
      await walk(entry, `${prefix}${name}/`, out)
    } else if (entry.kind === 'file' && /\.(md|markdown)$/i.test(name)) {
      try {
        const file = await entry.getFile()
        const content = await file.text()
        const path = `${prefix}${name}`
        out.push({ path: /\.(txt)$/i.test(path) ? path : path, content })
      } catch {
        /* unreadable file — skip */
      }
    }
  }
  return out
}

async function resolveDir(root: DirHandle, segments: string[], create: boolean): Promise<DirHandle> {
  let dir = root
  for (const seg of segments) {
    dir = await dir.getDirectoryHandle(seg, { create })
  }
  return dir
}

export class FsVault implements Vault {
  kind: VaultKind = 'fs'
  name: string
  private root: DirHandle

  constructor(root: DirHandle) {
    this.root = root
    this.name = root.name || 'Vault'
  }

  /** Prompt the user for a directory (must be called from a user gesture). */
  static async pick(): Promise<FsVault> {
    const picker = (window as any).showDirectoryPicker
    if (!picker) throw new Error('unsupported')
    const handle = await picker({ mode: 'readwrite', id: 'vellum-vault' })
    const vault = new FsVault(handle)
    await vault.ensurePermission()
    try {
      await kvSet(FS_HANDLE_KEY, handle)
    } catch {
      /* handle may not be structured-cloneable in some browsers */
    }
    return vault
  }

  static async restore(): Promise<FsVault | null> {
    try {
      const handle = await kvGet<DirHandle>(FS_HANDLE_KEY)
      if (!handle) return null
      const vault = new FsVault(handle)
      const ok = await vault.ensurePermission()
      return ok ? vault : vault
    } catch {
      return null
    }
  }

  async ensurePermission(): Promise<boolean> {
    try {
      const opts = { mode: 'readwrite' as const }
      if ((await this.root.queryPermission(opts)) === 'granted') return true
      if ((await this.root.requestPermission(opts)) === 'granted') return true
      return false
    } catch {
      return false
    }
  }

  async load(): Promise<VaultFile[]> {
    const files = await walk(this.root)
    return files.sort((a, b) => a.path.localeCompare(b.path))
  }

  private split(path: string): { dirs: string[]; file: string } {
    const parts = path.split('/').filter(Boolean)
    const file = parts.pop() as string
    return { dirs: parts, file }
  }

  async write(path: string, content: string): Promise<void> {
    const { dirs, file } = this.split(path)
    const dir = await resolveDir(this.root, dirs, true)
    const handle = (await dir.getFileHandle(file, { create: true })) as FileHandle
    const writable = await handle.createWritable()
    await writable.write(content)
    await writable.close()
  }

  async remove(path: string): Promise<void> {
    const { dirs, file } = this.split(path)
    try {
      const dir = await resolveDir(this.root, dirs, false)
      await dir.removeEntry(file)
    } catch {
      /* already gone */
    }
  }

  async makeFolder(path: string): Promise<void> {
    const dirs = path.split('/').filter(Boolean)
    await resolveDir(this.root, dirs, true)
  }

  async forget(): Promise<void> {
    await kvDelete(FS_HANDLE_KEY)
  }
}

/* ------------------------------------------------------------------ helpers */
export function snapshotOf(vault: Vault, files: VaultFile[]): VaultSnapshot {
  return { name: vault.name, kind: vault.kind, files }
}

export function downloadFile(path: string, content: string): void {
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = path.split('/').pop() || 'note.md'
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

export function downloadVaultZipLike(vaultName: string, files: VaultFile[]): void {
  // No zip library: export a single JSON blob that can be re-imported, plus md text.
  const payload = JSON.stringify({ vault: vaultName, exportedAt: new Date().toISOString(), files }, null, 2)
  const blob = new Blob([payload], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${vaultName.replace(/\s+/g, '-').toLowerCase()}-export.json`
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
