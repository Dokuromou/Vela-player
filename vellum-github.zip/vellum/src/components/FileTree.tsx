import { useMemo, useState } from 'react'
import { ChevronRight, Columns3, FilePlus2, FileText, Folder, FolderOpen, FolderPlus, MoreHorizontal, Pencil, Copy, Trash2 } from 'lucide-react'
import type { Note } from '../types'
import { dirname } from '../lib/markdown'
import { cls } from '../lib/utils'
import { useStore } from '../store/useStore'
import { MenuItem } from './ui'

interface TreeFolder {
  name: string
  path: string
  folders: TreeFolder[]
  notes: { path: string; title: string }[]
}

function buildTree(notes: Record<string, Note>): TreeFolder {
  const root: TreeFolder = { name: '', path: '', folders: [], notes: [] }
  const folderMap = new Map<string, TreeFolder>([['', root]])

  const ensure = (path: string): TreeFolder => {
    const existing = folderMap.get(path)
    if (existing) return existing
    const parent = ensure(dirname(path))
    const folder: TreeFolder = { name: path.slice(path.lastIndexOf('/') + 1), path, folders: [], notes: [] }
    parent.folders.push(folder)
    folderMap.set(path, folder)
    return folder
  }

  for (const note of Object.values(notes)) {
    const dir = dirname(note.path)
    const parent = dir ? ensure(dir) : root
    parent.notes.push({ path: note.path, title: note.title })
  }

  const sortTree = (folder: TreeFolder) => {
    folder.folders.sort((a, b) => a.name.localeCompare(b.name))
    folder.notes.sort((a, b) => a.title.localeCompare(b.title))
    folder.folders.forEach(sortTree)
  }
  sortTree(root)
  return root
}

interface Props {
  activePath: string | null
  onOpen: (path: string) => void
}

export function FileTree({ activePath, onOpen }: Props) {
  const notes = useStore((s) => s.notes)
  const createNote = useStore((s) => s.createNote)
  const renameNote = useStore((s) => s.renameNote)
  const deleteNote = useStore((s) => s.deleteNote)
  const duplicateNote = useStore((s) => s.duplicateNote)
  const setView = useStore((s) => s.setView)
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set())
  const [menu, setMenu] = useState<{ path: string; x: number; y: number } | null>(null)

  const tree = useMemo(() => buildTree(notes), [notes])

  const toggle = (path: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev)
      if (next.has(path)) next.delete(path)
      else next.add(path)
      return next
    })
  }

  const row = (path: string, title: string, depth: number) => {
    const active = path === activePath
    return (
      <div
        key={path}
        onClick={() => onOpen(path)}
        onContextMenu={(e) => {
          e.preventDefault()
          setMenu({ path, x: e.clientX, y: e.clientY })
        }}
        className={cls(
          'tree-row group flex cursor-pointer items-center gap-1.5 rounded-md py-[3px] pr-1 text-[12.5px]',
          active ? 'bg-accent-soft text-accent' : 'text-ink/80',
        )}
        style={{ paddingLeft: 6 + depth * 12 }}
      >
        <FileText size={13} className={cls('shrink-0', active ? 'text-accent' : 'text-muted')} />
        <span className="min-w-0 flex-1 truncate">{title}</span>
        <button
          type="button"
          title="Note actions"
          onClick={(e) => {
            e.stopPropagation()
            const rect = (e.target as HTMLElement).getBoundingClientRect()
            setMenu({ path, x: rect.left, y: rect.bottom + 4 })
          }}
          className="hidden shrink-0 rounded p-0.5 text-muted hover:text-ink group-hover:block"
        >
          <MoreHorizontal size={13} />
        </button>
      </div>
    )
  }

  const folderRow = (folder: TreeFolder, depth: number) => {
    const isCollapsed = collapsed.has(folder.path)
    const count = countNotes(folder)
    return (
      <div key={folder.path}>
        <div
          onClick={() => toggle(folder.path)}
          className="tree-row group flex cursor-pointer items-center gap-1 rounded-md py-[3px] pr-1 text-[12.5px] text-ink/75"
          style={{ paddingLeft: 2 + depth * 12 }}
        >
          <ChevronRight size={12} className={cls('shrink-0 text-muted transition-transform', !isCollapsed && 'rotate-90')} />
          {isCollapsed ? (
            <Folder size={13} className="shrink-0 text-muted" />
          ) : (
            <FolderOpen size={13} className="shrink-0 text-accent/80" />
          )}
          <span className="min-w-0 flex-1 truncate font-medium">{folder.name}</span>
          <span className="shrink-0 text-[10px] text-muted">{count}</span>
          <button
            type="button"
            title="Open as database"
            onClick={(e) => {
              e.stopPropagation()
              setView({ mode: 'table', folder: folder.path })
            }}
            className="hidden shrink-0 rounded p-0.5 text-muted hover:text-accent group-hover:block"
          >
            <Columns3 size={12} />
          </button>
          <button
            type="button"
            title="New note in folder"
            onClick={(e) => {
              e.stopPropagation()
              createNote(folder.path)
            }}
            className="hidden shrink-0 rounded p-0.5 text-muted hover:text-accent group-hover:block"
          >
            <FilePlus2 size={12} />
          </button>
        </div>
        {!isCollapsed && (
          <div>
            {folder.folders.map((child) => folderRow(child, depth + 1))}
            {folder.notes.map((n) => row(n.path, n.title, depth + 1))}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="px-1.5 pb-2">
      <div className="mb-1 flex items-center justify-between px-1.5 pt-1">
        <span className="text-[10px] font-semibold uppercase tracking-[0.09em] text-muted">Vault</span>
        <div className="flex items-center gap-0.5">
          <button
            type="button"
            title="New note"
            onClick={() => createNote('')}
            className="rounded p-1 text-muted hover:bg-elev hover:text-ink"
          >
            <FilePlus2 size={13} />
          </button>
          <button
            type="button"
            title="New folder"
            onClick={() => {
              const name = window.prompt('Folder name')
              if (!name) return
              const clean = name.replace(/[\\/:*?"<>|]/g, '-').trim()
              if (!clean) return
              createNote(clean, 'Untitled')
            }}
            className="rounded p-1 text-muted hover:bg-elev hover:text-ink"
          >
            <FolderPlus size={13} />
          </button>
        </div>
      </div>
      <div className="space-y-[1px]">
        {tree.notes.map((n) => row(n.path, n.title, 0))}
        {tree.folders.map((folder) => folderRow(folder, 0))}
        {!tree.notes.length && !tree.folders.length && (
          <div className="px-2 py-6 text-center text-[12px] text-muted">Vault is empty</div>
        )}
      </div>

      {menu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setMenu(null)} onContextMenu={(e) => { e.preventDefault(); setMenu(null) }} />
          <div
            className="fixed z-50 w-[188px] rounded-xl border border-line bg-elev p-1 card-shadow anim-in"
            style={{ left: Math.min(menu.x, window.innerWidth - 200), top: Math.min(menu.y, window.innerHeight - 190) }}
          >
            <MenuItem
              icon={Pencil}
              onClick={() => {
                const note = notes[menu.path]
                setMenu(null)
                if (!note) return
                const next = window.prompt('Rename note', note.title)
                if (next) renameNote(menu.path, next)
              }}
            >
              Rename
            </MenuItem>
            <MenuItem
              icon={Copy}
              onClick={() => {
                duplicateNote(menu.path)
                setMenu(null)
              }}
            >
              Duplicate
            </MenuItem>
            <MenuItem
              icon={Columns3}
              onClick={() => {
                setView({ mode: 'table', folder: dirname(menu.path) })
                setMenu(null)
              }}
            >
              Folder database
            </MenuItem>
            <div className="my-1 h-px bg-line" />
            <MenuItem
              icon={Trash2}
              danger
              onClick={() => {
                const note = notes[menu.path]
                setMenu(null)
                if (note && window.confirm(`Delete “${note.title}”? This removes the file.`)) deleteNote(menu.path)
              }}
            >
              Delete
            </MenuItem>
          </div>
        </>
      )}
    </div>
  )
}

function countNotes(folder: TreeFolder): number {
  return folder.notes.length + folder.folders.reduce((sum, f) => sum + countNotes(f), 0)
}
