import { CloudOff, Cpu, FolderOpen, HardDrive, Zap } from 'lucide-react'
import { useMemo } from 'react'
import { wordCount } from '../lib/markdown'
import { MOD_KEY, relativeTime } from '../lib/utils'
import { useStore } from '../store/useStore'

export function StatusBar() {
  const vaultName = useStore((s) => s.vaultName)
  const vaultKind = useStore((s) => s.vaultKind)
  const notes = useStore((s) => s.notes)
  const saveState = useStore((s) => s.saveState)
  const lastSavedAt = useStore((s) => s.lastSavedAt)
  const indexInfo = useStore((s) => s.indexInfo)
  const activeNote = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ? s.notes[pane.active] ?? null : null
  })
  const words = useMemo(() => (activeNote ? wordCount(activeNote.content) : 0), [activeNote])

  return (
    <footer className="flex h-[26px] shrink-0 items-center gap-3 border-t border-line bg-panel px-3 text-[10.5px] text-muted">
      <span className="flex items-center gap-1">
        {vaultKind === 'fs' ? <FolderOpen size={10} /> : <HardDrive size={10} />}
        {vaultName}
      </span>
      <span className="opacity-40">|</span>
      <span>{Object.keys(notes).length} notes</span>
      <span className="opacity-40">|</span>
      <span className="flex items-center gap-1">
        {indexInfo.worker ? <Zap size={10} className="text-accent" /> : <Cpu size={10} />}
        {indexInfo.worker ? 'background index' : 'main-thread index'}
      </span>
      <span className="ml-auto flex items-center gap-3">
        {activeNote ? <span>{words} words</span> : null}
        <span className="flex items-center gap-1">
          <CloudOff size={10} />
          offline ready
        </span>
        <span className="min-w-[74px] text-right">
          {saveState === 'saving' ? 'Saving…' : lastSavedAt ? `Saved ${relativeTime(lastSavedAt)}` : 'All changes saved'}
        </span>
        <span className="hidden opacity-70 sm:inline">{MOD_KEY}P palette</span>
      </span>
    </footer>
  )
}
