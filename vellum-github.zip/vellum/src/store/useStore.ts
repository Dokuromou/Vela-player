import { create } from 'zustand'
import type { Frontmatter, Note, PaneState, Theme, VaultKind, ViewMode } from '../types'
import { parseNote, noteTitle, dirname, basename, setFrontmatterKey, buildTitleIndex, resolveLink } from '../lib/markdown'
import { DAILY_TEMPLATE, SAMPLE_NOTES } from '../lib/samples'
import { FsVault, IdbVault, type Vault } from '../lib/vault'
import { getSearchService } from '../lib/searchClient'
import { applyTheme, loadTheme } from '../lib/theme'
import { fromISODate, prettyDate, toISODate, todayISO } from '../lib/utils'

const LS = {
  lastNote: 'vellum.lastNote',
  onboarded: 'vellum.onboarded',
  sidebar: 'vellum.sidebarOpen',
  right: 'vellum.rightOpen',
}

export interface Toast {
  id: number
  text: string
  kind: 'info' | 'success' | 'error'
}

export interface VellumState {
  ready: boolean
  vaultKind: VaultKind
  vaultName: string
  notes: Record<string, Note>
  panes: PaneState[]
  activePane: number
  theme: Theme
  sidebarOpen: boolean
  rightOpen: boolean
  rightSections: { outline: boolean; backlinks: boolean; graph: boolean }
  view: { mode: ViewMode; folder: string } | null
  graphOpen: boolean
  paletteOpen: boolean
  paletteMode: 'files' | 'commands'
  searchQuery: string
  onboarding: boolean
  saveState: 'idle' | 'saving' | 'saved'
  lastSavedAt: number
  indexInfo: { worker: boolean; size: number }
  dailyFolder: string
  toasts: Toast[]
  graphFocus: string | null

  init: () => Promise<void>
  openNote: (path: string, pane?: number) => void
  closeTab: (pane: number, path: string) => void
  setActivePane: (pane: number) => void
  splitPane: () => void
  closePane: (pane: number) => void
  updateNote: (path: string, content: string) => void
  createNote: (folder: string, name?: string, content?: string) => string
  createNoteAtPath: (path: string) => void
  renameNote: (path: string, nextTitle: string) => void
  deleteNote: (path: string) => void
  duplicateNote: (path: string) => void
  setFrontmatter: (path: string, key: string, value: unknown) => void
  setTheme: (theme: Theme) => void
  toggleSidebar: () => void
  toggleRight: () => void
  toggleRightSection: (key: 'outline' | 'backlinks' | 'graph') => void
  setView: (view: { mode: ViewMode; folder: string } | null) => void
  setGraphOpen: (open: boolean, focus?: string | null) => void
  setPalette: (open: boolean, mode?: 'files' | 'commands') => void
  setSearch: (q: string) => void
  dismissOnboarding: () => void
  openDaily: (date?: string) => void
  openFolder: () => Promise<void>
  useLocalVault: () => Promise<void>
  seedSamples: () => Promise<void>
  toast: (text: string, kind?: Toast['kind']) => void
  dismissToast: (id: number) => void
  exportVault: () => void
}

/* ------------------------------------------------------------------ helpers */
let currentVault: Vault | null = null
const saveTimers = new Map<string, ReturnType<typeof setTimeout>>()
const indexFlushTimers = new Map<string, ReturnType<typeof setTimeout>>()
const search = getSearchService()

function noteMapFromFiles(files: { path: string; content: string }[]): Record<string, Note> {
  const out: Record<string, Note> = {}
  for (const f of files) out[f.path] = parseNote(f.path, f.content, Date.now())
  return out
}

function uniquePath(notes: Record<string, Note>, folder: string, base: string): string {
  const safe = base.replace(/[\\/:*?"<>|#^[\]]/g, '-').trim() || 'Untitled'
  const prefix = folder ? `${folder}/` : ''
  let candidate = `${prefix}${safe}.md`
  let i = 2
  while (notes[candidate]) {
    candidate = `${prefix}${safe} ${i}.md`
    i++
  }
  return candidate
}

function scheduleSave(path: string, content: string, set: (partial: Partial<VellumState>) => void) {
  const existing = saveTimers.get(path)
  if (existing) clearTimeout(existing)
  set({ saveState: 'saving' })
  const timer = setTimeout(async () => {
    saveTimers.delete(path)
    try {
      await currentVault?.write(path, content)
      set({ saveState: 'saved', lastSavedAt: Date.now() })
    } catch {
      set({ saveState: 'saved' })
    }
  }, 420)
  saveTimers.set(path, timer)
}

function reindexAll(notes: Record<string, Note>) {
  search.index(Object.values(notes).map((n) => ({ path: n.path, title: n.title, text: n.body })))
}

export const useStore = create<VellumState>()((set, get) => ({
  ready: false,
  vaultKind: 'idb',
  vaultName: 'Local Vault',
  notes: {},
  panes: [{ tabs: [], active: null }],
  activePane: 0,
  theme: loadTheme(),
  sidebarOpen: true,
  rightOpen: true,
  rightSections: { outline: true, backlinks: true, graph: true },
  view: null,
  graphOpen: false,
  paletteOpen: false,
  paletteMode: 'files',
  searchQuery: '',
  onboarding: false,
  saveState: 'idle',
  lastSavedAt: 0,
  indexInfo: { worker: true, size: 0 },
  dailyFolder: 'Daily',
  toasts: [],
  graphFocus: null,

  init: async () => {
    applyTheme(get().theme)

    // 1. vault: prefer a previously connected folder, else the local IndexedDB vault
    let vault: Vault | null = null
    try {
      const fs = await FsVault.restore()
      if (fs) {
        const ok = await fs.ensurePermission()
        if (ok) vault = fs
      }
    } catch {
      /* ignore */
    }
    let files: { path: string; content: string }[] = []
    if (vault) {
      try {
        files = await vault.load()
      } catch {
        vault = null
      }
    }
    if (!vault) {
      const idb = await IdbVault.restore()
      vault = idb
      files = await idb.load()
    }
    currentVault = vault

    // 2. first launch → seed the sample vault
    if (!files.length) {
      for (const sample of SAMPLE_NOTES) await vault.write(sample.path, sample.content)
      files = SAMPLE_NOTES.map((s) => ({ ...s }))
    }

    const notes = noteMapFromFiles(files)
    const last = (() => {
      try {
        return localStorage.getItem(LS.lastNote) || ''
      } catch {
        return ''
      }
    })()
    let start = notes[last] ? last : ''
    if (!start) start = notes['Welcome to Vellum.md'] ? 'Welcome to Vellum.md' : Object.keys(notes).sort()[0] || ''

    search.onStatus = (info) => set({ indexInfo: info })
    reindexAll(notes)

    let onboarded = false
    try {
      onboarded = localStorage.getItem(LS.onboarded) === '1'
    } catch {
      /* ignore */
    }

    set({
      ready: true,
      vaultKind: vault.kind,
      vaultName: vault.name,
      notes,
      panes: [{ tabs: start ? [start] : [], active: start || null }],
      onboarding: !onboarded,
      sidebarOpen: localStorage.getItem(LS.sidebar) !== '0',
      rightOpen: localStorage.getItem(LS.right) !== '0',
      indexInfo: { worker: (search as unknown as { useWorker?: boolean }).useWorker ?? true, size: Object.keys(notes).length },
    })
    if (start) {
      try {
        localStorage.setItem(LS.lastNote, start)
      } catch {
        /* ignore */
      }
    }
  },

  openNote: (path, pane) => {
    const state = get()
    if (!state.notes[path]) {
      get().createNoteAtPath(path)
      return
    }
    const panes = state.panes.map((p) => ({ ...p, tabs: [...p.tabs] }))
    const paneIdx = pane ?? state.activePane
    // already open somewhere? focus it
    for (let i = 0; i < panes.length; i++) {
      if (panes[i].tabs.includes(path)) {
        panes[i].active = path
        set({ panes, activePane: i })
        try {
          localStorage.setItem(LS.lastNote, path)
        } catch {
          /* ignore */
        }
        return
      }
    }
    const target = panes[Math.min(paneIdx, panes.length - 1)]
    target.tabs.push(path)
    target.active = path
    set({ panes, activePane: Math.min(paneIdx, panes.length - 1), view: null })
    try {
      localStorage.setItem(LS.lastNote, path)
    } catch {
      /* ignore */
    }
  },

  createNoteAtPath: (path) => {
    const withExt = /\.(md|markdown|txt)$/i.test(path) ? path : `${path}.md`
    const state = get()
    if (state.notes[withExt]) {
      get().openNote(withExt)
      return
    }
    const content = `---\nstatus: Backlog\ntags: []\n---\n\n# ${noteTitle(withExt)}\n\n`
    const note = parseNote(withExt, content, Date.now())
    set({ notes: { ...state.notes, [withExt]: note } })
    void currentVault?.write(withExt, content)
    search.upsert({ path: withExt, title: note.title, text: note.body })
    get().openNote(withExt)
    get().toast(`Created “${note.title}”`, 'success')
  },

  closeTab: (pane, path) => {
    const state = get()
    const panes = state.panes.map((p) => ({ ...p, tabs: [...p.tabs] }))
    const p = panes[pane]
    if (!p) return
    const idx = p.tabs.indexOf(path)
    if (idx === -1) return
    p.tabs.splice(idx, 1)
    if (p.active === path) p.active = p.tabs[Math.min(idx, p.tabs.length - 1)] || null
    set({ panes })
  },

  setActivePane: (pane) => set({ activePane: pane }),

  splitPane: () => {
    const state = get()
    if (state.panes.length > 1) return
    const current = state.panes[0].active
    const panes: PaneState[] = [
      { tabs: [...state.panes[0].tabs], active: current },
      { tabs: current ? [current] : [], active: current },
    ]
    // second pane should show a *different* note when possible
    const others = Object.keys(state.notes).filter((p) => p !== current)
    if (others.length) {
      const pick = others.find((p) => /^Projects\//.test(p)) || others[0]
      panes[1] = { tabs: [pick], active: pick }
    }
    set({ panes, activePane: 1 })
  },

  closePane: (pane) => {
    const state = get()
    if (state.panes.length < 2) return
    const panes = state.panes.filter((_, i) => i !== pane)
    set({ panes, activePane: 0 })
  },

  updateNote: (path, content) => {
    const state = get()
    const prev = state.notes[path]
    const note = prev && prev.content === content ? prev : parseNote(path, content, Date.now())
    set({ notes: { ...state.notes, [path]: note } })
    scheduleSave(path, content, set as unknown as (p: Partial<VellumState>) => void)
    const prevTimer = indexFlushTimers.get(path)
    if (prevTimer) clearTimeout(prevTimer)
    indexFlushTimers.set(
      path,
      setTimeout(() => search.upsert({ path, title: note.title, text: note.body }), 700),
    )
  },

  createNote: (folder, name, content) => {
    const state = get()
    const path = uniquePath(state.notes, folder, name || 'Untitled')
    const body = content ?? `---\nstatus: Backlog\ntags: []\ndate: ${todayISO()}\n---\n\n# ${noteTitle(path)}\n\n`
    const note = parseNote(path, body, Date.now())
    set({ notes: { ...state.notes, [path]: note } })
    void currentVault?.write(path, body)
    search.upsert({ path, title: note.title, text: note.body })
    get().openNote(path)
    return path
  },

  renameNote: (path, nextTitle) => {
    const state = get()
    const note = state.notes[path]
    if (!note) return
    const folder = dirname(path)
    const cleaned = nextTitle.trim().replace(/\.md$/i, '').replace(/[\\/:*?"<>|#^[\]]/g, '-')
    if (!cleaned || cleaned === note.title) return
    const newPath = uniquePath(state.notes, folder, cleaned)
    if (newPath === path) return
    const newTitle = noteTitle(newPath)

    const notes = { ...state.notes }
    delete notes[path]
    notes[newPath] = { ...note, path: newPath, title: newTitle }

    // rewrite links that pointed at the old note
    for (const p of Object.keys(notes)) {
      const n = notes[p]
      if (!n.links.some((l) => resolveLink(buildTitleIndex(state.notes), l.path || l.target) === path)) continue
      const nextContent = n.content.replace(/\[\[([^\]\n]+)\]\]/g, (match, inner: string) => {
        const [targetPart, alias] = inner.split('|')
        const [tRaw, heading] = targetPart.split('#')
        const resolved = resolveLink(buildTitleIndex(state.notes), tRaw.trim())
        if (resolved !== path) return match
        const newTarget = tRaw.includes('/') ? newPath.replace(/\.md$/i, '') : newTitle
        const suffix = alias ? `|${alias}` : ''
        return `[[${newTarget}${heading ? `#${heading}` : ''}${suffix}]]`
      })
      if (nextContent !== n.content) {
        notes[p] = parseNote(p, nextContent, Date.now())
        void currentVault?.write(p, nextContent)
      }
    }

    const panes = state.panes.map((pane) => ({
      tabs: pane.tabs.map((t) => (t === path ? newPath : t)),
      active: pane.active === path ? newPath : pane.active,
    }))

    set({ notes, panes })
    void currentVault?.write(newPath, note.content)
    void currentVault?.remove(path)
    search.remove(path)
    search.upsert({ path: newPath, title: newTitle, text: note.body })
    reindexAll(notes)
    get().toast(`Renamed to “${newTitle}”`, 'success')
  },

  deleteNote: (path) => {
    const state = get()
    const notes = { ...state.notes }
    delete notes[path]
    const panes = state.panes.map((pane) => {
      const tabs = pane.tabs.filter((t) => t !== path)
      return { tabs, active: pane.active === path ? tabs[tabs.length - 1] || null : pane.active }
    })
    set({ notes, panes })
    void currentVault?.remove(path)
    search.remove(path)
    get().toast(`Deleted “${noteTitle(path)}”`, 'info')
  },

  duplicateNote: (path) => {
    const note = get().notes[path]
    if (!note) return
    get().createNote(dirname(path), `${note.title} copy`, note.content)
  },

  setFrontmatter: (path, key, value) => {
    const note = get().notes[path]
    if (!note) return
    const content = setFrontmatterKey(note.content, key, value)
    get().updateNote(path, content)
    const timer = saveTimers.get(path)
    if (timer) clearTimeout(timer)
    saveTimers.delete(path)
    void currentVault?.write(path, content)
    set({ saveState: 'saved', lastSavedAt: Date.now() })
  },

  setTheme: (theme) => {
    applyTheme(theme)
    set({ theme })
  },

  toggleSidebar: () => {
    const next = !get().sidebarOpen
    try {
      localStorage.setItem(LS.sidebar, next ? '1' : '0')
    } catch {
      /* ignore */
    }
    set({ sidebarOpen: next })
  },

  toggleRight: () => {
    const next = !get().rightOpen
    try {
      localStorage.setItem(LS.right, next ? '1' : '0')
    } catch {
      /* ignore */
    }
    set({ rightOpen: next })
  },

  toggleRightSection: (key) => {
    const sections = { ...get().rightSections, [key]: !get().rightSections[key] }
    set({ rightSections: sections })
  },

  setView: (view) => set({ view }),
  setGraphOpen: (open, focus = null) => set({ graphOpen: open, graphFocus: focus }),
  setPalette: (open, mode = 'files') => set({ paletteOpen: open, paletteMode: mode }),
  setSearch: (q) => set({ searchQuery: q }),

  dismissOnboarding: () => {
    try {
      localStorage.setItem(LS.onboarded, '1')
    } catch {
      /* ignore */
    }
    set({ onboarding: false })
  },

  openDaily: (date = todayISO()) => {
    const folder = get().dailyFolder
    const path = `${folder}/${date}.md`
    if (get().notes[path]) {
      get().openNote(path)
      return
    }
    const d = fromISODate(date)
    const prev = toISODate(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1))
    const next = toISODate(new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1))
    const content = DAILY_TEMPLATE.replace(/\{\{date\}\}/g, date)
      .replace(/\{\{prettyDate\}\}/g, prettyDate(d))
      .replace(/\{\{prev\}\}/g, `[[${prev}]]`)
      .replace(/\{\{next\}\}/g, `[[${next}]]`)
    const note = parseNote(path, content, Date.now())
    set({ notes: { ...get().notes, [path]: note } })
    void currentVault?.write(path, content)
    search.upsert({ path, title: note.title, text: note.body })
    get().openNote(path)
  },

  openFolder: async () => {
    try {
      const vault = await FsVault.pick()
      currentVault = vault
      let files = await vault.load()
      if (!files.length) {
        for (const s of SAMPLE_NOTES) await vault.write(s.path, s.content)
        files = SAMPLE_NOTES.map((s) => ({ ...s }))
      }
      const notes = noteMapFromFiles(files)
      const first = notes['Welcome to Vellum.md'] ? 'Welcome to Vellum.md' : Object.keys(notes).sort()[0] || ''
      set({
        vaultKind: 'fs',
        vaultName: vault.name,
        notes,
        panes: [{ tabs: first ? [first] : [], active: first || null }],
        activePane: 0,
      })
      reindexAll(notes)
      get().toast(`Opened “${vault.name}” — writing real files`, 'success')
    } catch (err) {
      const name = (err as { name?: string })?.name
      if (name === 'AbortError') return
      get().toast('Folder access is blocked here — staying on the local vault', 'error')
    }
  },

  useLocalVault: async () => {
    const vault = await IdbVault.restore()
    currentVault = vault
    let files = await vault.load()
    if (!files.length) {
      for (const s of SAMPLE_NOTES) await vault.write(s.path, s.content)
      files = SAMPLE_NOTES.map((s) => ({ ...s }))
    }
    const notes = noteMapFromFiles(files)
    const first = notes['Welcome to Vellum.md'] ? 'Welcome to Vellum.md' : Object.keys(notes).sort()[0] || ''
    set({
      vaultKind: 'idb',
      vaultName: vault.name,
      notes,
      panes: [{ tabs: first ? [first] : [], active: first || null }],
      activePane: 0,
    })
    reindexAll(notes)
  },

  seedSamples: async () => {
    const state = get()
    const notes = { ...state.notes }
    for (const s of SAMPLE_NOTES) {
      if (notes[s.path]) continue
      await currentVault?.write(s.path, s.content)
      notes[s.path] = parseNote(s.path, s.content, Date.now())
    }
    set({ notes })
    reindexAll(notes)
    get().toast('Sample notes added', 'success')
  },

  toast: (text, kind = 'info') => {
    const id = Date.now() + Math.random()
    set({ toasts: [...get().toasts, { id, text, kind }] })
    setTimeout(() => get().dismissToast(id), 4200)
  },

  dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),

  exportVault: () => {
    const files = Object.values(get().notes).map((n) => ({ path: n.path, content: n.content }))
    const payload = JSON.stringify({ vault: get().vaultName, exportedAt: new Date().toISOString(), files }, null, 2)
    const blob = new Blob([payload], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${get().vaultName.replace(/\s+/g, '-').toLowerCase()}-export.json`
    a.click()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
  },
}))

/* -------------------------------------------------------------- selectors */
export function useActiveNote(): Note | null {
  return useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ? s.notes[pane.active] ?? null : null
  })
}

export function allNotesSorted(notes: Record<string, Note>): Note[] {
  return Object.values(notes).sort((a, b) => a.title.localeCompare(b.title))
}

export function folderList(notes: Record<string, Note>): string[] {
  const set = new Set<string>()
  for (const p of Object.keys(notes)) {
    const d = dirname(p)
    if (d) set.add(d)
  }
  return [...set].sort()
}

export function frontmatterValue(note: Note, key: string): string | undefined {
  const v = note.fm[key]
  if (v === undefined || v === null) return undefined
  if (Array.isArray(v)) return v.join(', ')
  return String(v)
}

export type { Frontmatter, Note, Theme }
