import { useEffect, useRef } from 'react'
import type { GraphEdge, GraphNode } from '../types'
import { tagColor } from '../lib/utils'

interface Props {
  nodes: GraphNode[]
  edges: GraphEdge[]
  activeId?: string | null
  search?: string
  onOpen?: (id: string) => void
  mini?: boolean
  className?: string
}

interface SimNode extends GraphNode {
  x: number
  y: number
  vx: number
  vy: number
  r: number
}

const NODE_MIN = 4.5
const NODE_MAX = 15

export function ForceGraph({ nodes, edges, activeId, search = '', onOpen, mini = false, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const simRef = useRef<{ nodes: SimNode[]; edges: GraphEdge[]; alpha: number }>({ nodes: [], edges: [], alpha: 1 })
  const camRef = useRef({ x: 0, y: 0, scale: 1 })
  const hoverRef = useRef<string | null>(null)
  const dragRef = useRef<{ id: string | null; moved: number; panning: boolean; lastX: number; lastY: number }>({
    id: null,
    moved: 0,
    panning: false,
    lastX: 0,
    lastY: 0,
  })
  const rafRef = useRef<number | null>(null)
  const kickRef = useRef<() => void>(() => {})
  const fitRef = useRef(false)
  const nodesRef = useRef(nodes)
  const searchRef = useRef(search)
  const activeRef = useRef(activeId)
  const onOpenRef = useRef(onOpen)
  nodesRef.current = nodes
  searchRef.current = search
  activeRef.current = activeId
  onOpenRef.current = onOpen

  /* ------------------------------------------------------------- simulation */
  useEffect(() => {
    const count = nodes.length || 1
    const prev = new Map(simRef.current.nodes.map((n) => [n.id, n]))
    const maxDeg = Math.max(1, ...nodes.map((n) => n.degree))
    const next: SimNode[] = nodes.map((n, i) => {
      const existing = prev.get(n.id)
      const radius = NODE_MIN + (NODE_MAX - NODE_MIN) * Math.sqrt(n.degree / maxDeg)
      if (existing) return { ...existing, ...n, r: radius }
      const angle = (i / count) * Math.PI * 2 + (n.id.length % 7) * 0.2
      const dist = 90 + ((n.id.length * 37) % 160)
      return {
        ...n,
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        vx: 0,
        vy: 0,
        r: radius,
      }
    })
    const ids = new Set(next.map((n) => n.id))
    simRef.current = {
      nodes: next,
      edges: edges.filter((e) => ids.has(e.source) && ids.has(e.target)),
      alpha: 1,
    }
    camRef.current = { x: 0, y: 0, scale: 1 }
    fitRef.current = false
  }, [nodes, edges])

  /* ---------------------------------------------------------------- drawing */
  useEffect(() => {
    const canvas = canvasRef.current
    const wrap = wrapRef.current
    if (!canvas || !wrap) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let width = 0
    let height = 0
    const dpr = Math.min(window.devicePixelRatio || 1, 2)

    const resize = () => {
      const rect = wrap.getBoundingClientRect()
      width = Math.max(60, rect.width)
      height = Math.max(60, rect.height)
      canvas.width = Math.floor(width * dpr)
      canvas.height = Math.floor(height * dpr)
      canvas.style.width = `${width}px`
      canvas.style.height = `${height}px`
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(wrap)

    const styles = getComputedStyle(document.documentElement)
    const ink = styles.getPropertyValue('--ink').trim() || '#e7eaf0'
    const muted = styles.getPropertyValue('--muted').trim() || '#8b94a6'
    const accent = styles.getPropertyValue('--accent').trim() || '#7c9cff'
    const line = styles.getPropertyValue('--line').trim() || '#232936'
    const surface = styles.getPropertyValue('--panel').trim() || '#11141b'

    const buildNeighbours = () => {
      const map = new Map<string, Set<string>>()
      for (const e of simRef.current.edges) {
        if (!map.has(e.source)) map.set(e.source, new Set())
        if (!map.has(e.target)) map.set(e.target, new Set())
        map.get(e.source)!.add(e.target)
        map.get(e.target)!.add(e.source)
      }
      return map
    }

    const step = () => {
      const sim = simRef.current
      const { nodes: sn, edges: se } = sim
      if (!sn.length) {
        ctx.clearRect(0, 0, width, height)
        return
      }
      // forces
      if (sim.alpha > 0.002) {
        const repulsion = mini ? 1500 : 4200
        for (let i = 0; i < sn.length; i++) {
          const a = sn[i]
          for (let j = i + 1; j < sn.length; j++) {
            const b = sn[j]
            let dx = a.x - b.x
            let dy = a.y - b.y
            let d2 = dx * dx + dy * dy
            if (d2 < 0.01) {
              dx = (Math.random() - 0.5) * 2
              dy = (Math.random() - 0.5) * 2
              d2 = 1
            }
            const d = Math.sqrt(d2)
            const force = repulsion / d2
            const fx = (dx / d) * force
            const fy = (dy / d) * force
            a.vx += fx
            a.vy += fy
            b.vx -= fx
            b.vy -= fy
          }
        }
        const ideal = mini ? 48 : 132
        const byId = new Map(sn.map((n) => [n.id, n]))
        for (const e of se) {
          const a = byId.get(e.source)
          const b = byId.get(e.target)
          if (!a || !b) continue
          const dx = b.x - a.x
          const dy = b.y - a.y
          const d = Math.hypot(dx, dy) || 1
          const force = (d - ideal) * 0.012
          const fx = (dx / d) * force
          const fy = (dy / d) * force
          a.vx += fx
          a.vy += fy
          b.vx -= fx
          b.vy -= fy
        }
        for (const n of sn) {
          // gentle gravity toward the middle so the graph stays on screen
          n.vx -= n.x * (mini ? 0.0026 : 0.0014)
          n.vy -= n.y * (mini ? 0.0026 : 0.0014)
          n.vx *= 0.86
          n.vy *= 0.86
          n.x += n.vx
          n.y += n.vy
        }
        sim.alpha *= 0.985
      }

      // auto-fit the camera the first time the layout settles
      if (!fitRef.current && sim.alpha < 0.14) {
        let minX = Infinity
        let minY = Infinity
        let maxX = -Infinity
        let maxY = -Infinity
        for (const n of sn) {
          minX = Math.min(minX, n.x - n.r)
          maxX = Math.max(maxX, n.x + n.r)
          minY = Math.min(minY, n.y - n.r)
          maxY = Math.max(maxY, n.y + n.r)
        }
        if (Number.isFinite(minX) && maxX > minX) {
          const pad = mini ? 26 : 70
          const scale = Math.min(
            (width - pad * 2) / Math.max(60, maxX - minX),
            (height - pad * 2) / Math.max(60, maxY - minY),
            mini ? 0.95 : 1.5,
          )
          camRef.current = {
            x: (minX + maxX) / 2,
            y: (minY + maxY) / 2,
            scale: Math.max(0.3, scale),
          }
          fitRef.current = true
        }
      }

      // draw
      ctx.clearRect(0, 0, width, height)
      const cam = camRef.current
      const toScreen = (x: number, y: number) => ({
        sx: (x - cam.x) * cam.scale + width / 2,
        sy: (y - cam.y) * cam.scale + height / 2,
      })
      const neighbours = buildNeighbours()
      const q = searchRef.current.trim().toLowerCase()
      const hovered = hoverRef.current
      const focus = hovered
      const focusSet = focus ? neighbours.get(focus) : null

      // edges
      const byId = new Map(simRef.current.nodes.map((n) => [n.id, n]))
      for (const e of simRef.current.edges) {
        const a = byId.get(e.source)
        const b = byId.get(e.target)
        if (!a || !b) continue
        const p1 = toScreen(a.x, a.y)
        const p2 = toScreen(b.x, b.y)
        const related = focus ? e.source === focus || e.target === focus : false
        const dim = q
          ? !(a.label.toLowerCase().includes(q) || b.label.toLowerCase().includes(q))
          : focus
            ? !related
            : false
        ctx.strokeStyle = related ? accent : muted
        ctx.globalAlpha = dim ? 0.14 : related ? 0.8 : 0.36
        ctx.lineWidth = related ? 1.6 : 1
        ctx.beginPath()
        ctx.moveTo(p1.sx, p1.sy)
        ctx.lineTo(p2.sx, p2.sy)
        ctx.stroke()
      }

      // nodes
      for (const n of simRef.current.nodes) {
        const { sx, sy } = toScreen(n.x, n.y)
        const r = n.r * cam.scale * (mini ? 0.9 : 1)
        if (sx < -40 || sy < -40 || sx > width + 40 || sy > height + 40) continue
        const baseColor = n.tags.length ? tagColor(n.tags[0]) : accent
        const matches = !q || n.label.toLowerCase().includes(q) || n.tags.some((t) => t.toLowerCase().includes(q))
        const isFocus = focus === n.id
        const near = focusSet ? focusSet.has(n.id) : false
        ctx.globalAlpha = !matches ? 0.14 : focus && !isFocus && !near ? 0.3 : 1

        ctx.beginPath()
        ctx.arc(sx, sy, r, 0, Math.PI * 2)
        ctx.fillStyle = baseColor
        ctx.fill()
        if (activeRef.current === n.id) {
          ctx.strokeStyle = accent
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.arc(sx, sy, r + 3, 0, Math.PI * 2)
          ctx.stroke()
        }
        if (isFocus || near) {
          ctx.strokeStyle = ink
          ctx.lineWidth = 1.6
          ctx.stroke()
        } else {
          ctx.strokeStyle = surface
          ctx.lineWidth = 1.2
          ctx.stroke()
        }

        const showLabel = mini ? isFocus || hovered === n.id : isFocus || near || hovered === n.id || n.degree >= 5
        if (showLabel && matches) {
          ctx.globalAlpha = !matches ? 0.15 : isFocus || near ? 1 : 0.82
          ctx.fillStyle = isFocus ? ink : muted
          ctx.font = `${mini ? 9 : 10.5}px ui-sans-serif, system-ui, sans-serif`
          ctx.textAlign = 'center'
          const label = n.label.length > 24 ? `${n.label.slice(0, 23)}…` : n.label
          ctx.fillText(label, sx, sy + r + (mini ? 9 : 12))
        }
      }
      ctx.globalAlpha = 1

      if (sim.alpha > 0.002 || hoverRef.current) {
        rafRef.current = requestAnimationFrame(step)
      } else {
        rafRef.current = null
      }
    }

    const kick = () => {
      simRef.current.alpha = Math.max(simRef.current.alpha, 0.35)
      if (rafRef.current === null) rafRef.current = requestAnimationFrame(step)
    }
    kickRef.current = kick
    kick()

    /* ---------------------------------------------------------- interaction */
    const nodeAt = (clientX: number, clientY: number): SimNode | null => {
      const rect = canvas.getBoundingClientRect()
      const mx = clientX - rect.left
      const my = clientY - rect.top
      const cam = camRef.current
      let best: SimNode | null = null
      let bestDist = Infinity
      for (const n of simRef.current.nodes) {
        const sx = (n.x - cam.x) * cam.scale + width / 2
        const sy = (n.y - cam.y) * cam.scale + height / 2
        const d = Math.hypot(mx - sx, my - sy)
        const r = Math.max(9, n.r * cam.scale + 4)
        if (d < r && d < bestDist) {
          best = n
          bestDist = d
        }
      }
      return best
    }

    const onPointerDown = (event: PointerEvent) => {
      canvas.setPointerCapture(event.pointerId)
      const node = nodeAt(event.clientX, event.clientY)
      dragRef.current = { id: node?.id ?? null, moved: 0, panning: !node, lastX: event.clientX, lastY: event.clientY }
    }
    const onPointerMove = (event: PointerEvent) => {
      const drag = dragRef.current
      const node = nodeAt(event.clientX, event.clientY)
      const nextHover = node?.id ?? null
      if (nextHover !== hoverRef.current) {
        hoverRef.current = nextHover
        canvas.style.cursor = nextHover ? 'pointer' : 'grab'
        kick()
      }
      if (drag.id) {
        const cam = camRef.current
        const simNode = simRef.current.nodes.find((n) => n.id === drag.id)
        if (simNode) {
          const rect = canvas.getBoundingClientRect()
          simNode.x = (event.clientX - rect.left - width / 2) / cam.scale + cam.x
          simNode.y = (event.clientY - rect.top - height / 2) / cam.scale + cam.y
          simNode.vx = 0
          simNode.vy = 0
          drag.moved += Math.abs(event.movementX) + Math.abs(event.movementY)
          kick()
        }
      } else if (drag.panning) {
        const cam = camRef.current
        cam.x -= (event.clientX - drag.lastX) / cam.scale
        cam.y -= (event.clientY - drag.lastY) / cam.scale
        drag.lastX = event.clientX
        drag.lastY = event.clientY
        drag.moved += Math.abs(event.movementX) + Math.abs(event.movementY)
        kick()
      }
    }
    const onPointerUp = (event: PointerEvent) => {
      const drag = dragRef.current
      if (drag.id && drag.moved < 5) onOpenRef.current?.(drag.id)
      dragRef.current = { id: null, moved: 0, panning: false, lastX: 0, lastY: 0 }
      try {
        canvas.releasePointerCapture(event.pointerId)
      } catch {
        /* noop */
      }
    }
    const onWheel = (event: WheelEvent) => {
      event.preventDefault()
      const cam = camRef.current
      const rect = canvas.getBoundingClientRect()
      const mx = event.clientX - rect.left
      const my = event.clientY - rect.top
      const wx = (mx - width / 2) / cam.scale + cam.x
      const wy = (my - height / 2) / cam.scale + cam.y
      const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12
      cam.scale = Math.min(3.2, Math.max(0.35, cam.scale * factor))
      cam.x = wx - (mx - width / 2) / cam.scale
      cam.y = wy - (my - height / 2) / cam.scale
      kick()
    }
    const onLeave = () => {
      hoverRef.current = null
      kick()
    }

    canvas.addEventListener('pointerdown', onPointerDown)
    canvas.addEventListener('pointermove', onPointerMove)
    canvas.addEventListener('pointerup', onPointerUp)
    canvas.addEventListener('pointerleave', onLeave)
    canvas.addEventListener('wheel', onWheel, { passive: false })

    return () => {
      ro.disconnect()
      canvas.removeEventListener('pointerdown', onPointerDown)
      canvas.removeEventListener('pointermove', onPointerMove)
      canvas.removeEventListener('pointerup', onPointerUp)
      canvas.removeEventListener('pointerleave', onLeave)
      canvas.removeEventListener('wheel', onWheel)
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mini])

  // re-kick the loop whenever the data or highlight changes
  useEffect(() => {
    kickRef.current()
  }, [nodes, edges, search, activeId])

  return (
    <div ref={wrapRef} className={className} style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
      <canvas ref={canvasRef} className="block" />
    </div>
  )
}
