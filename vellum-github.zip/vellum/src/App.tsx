import { Fragment, useEffect } from 'react'
import { useStore } from './store/useStore'
import { isMac } from './lib/utils'
import { TopBar } from './components/TopBar'
import { Sidebar } from './components/Sidebar'
import { EditorPane } from './components/EditorPane'
import { RightSidebar } from './components/RightSidebar'
import { DatabaseViews } from './components/DatabaseViews'
import { StatusBar } from './components/StatusBar'
import { CommandPalette } from './components/CommandPalette'
import { GraphOverlay } from './components/GraphOverlay'
import { Onboarding } from './components/Onboarding'
import { Toasts } from './components/Toasts'

export default function App() {
  const ready = useStore((s) => s.ready)
  const init = useStore((s) => s.init)
  const sidebarOpen = useStore((s) => s.sidebarOpen)
  const rightOpen = useStore((s) => s.rightOpen)
  const panes = useStore((s) => s.panes)
  const view = useStore((s) => s.view)
  const onboarding = useStore((s) => s.onboarding)

  useEffect(() => {
    void init()
  }, [init])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return
      const state = useStore.getState()
      const mod = isMac() ? event.metaKey : event.ctrlKey
      const key = event.key.toLowerCase()

      if (mod && key === 'p') {
        event.preventDefault()
        state.setPalette(true, event.shiftKey ? 'commands' : 'files')
        return
      }
      if (mod && key === 'n' && !event.shiftKey) {
        event.preventDefault()
        state.createNote('')
        return
      }
      if (mod && event.shiftKey && key === 'd') {
        event.preventDefault()
        state.openDaily()
        return
      }
      if (mod && key === 'g' && !event.shiftKey) {
        event.preventDefault()
        state.setGraphOpen(!state.graphOpen)
        return
      }
      if (mod && key === 'b' && !event.shiftKey) {
        event.preventDefault()
        state.toggleSidebar()
        return
      }
      if (mod && event.shiftKey && key === 'b') {
        event.preventDefault()
        state.toggleRight()
        return
      }
      if (mod && key === '\\') {
        event.preventDefault()
        state.splitPane()
        return
      }
      if (key === 'escape') {
        if (state.graphOpen) {
          state.setGraphOpen(false)
          return
        }
        if (state.paletteOpen) {
          state.setPalette(false)
          return
        }
      }
      if (mod && key === 's') {
        event.preventDefault()
        state.toast('Your notes are saved automatically — every keystroke goes straight to the file.', 'info')
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  if (!ready) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 bg-app text-ink">
        <div className="flex size-11 animate-pulse items-center justify-center rounded-xl bg-accent text-[18px] font-black text-app">
          V
        </div>
        <div className="text-[13px] text-muted">Opening your vault…</div>
      </div>
    )
  }

  return (
    <div className="flex h-full flex-col overflow-hidden bg-app text-ink">
      <TopBar />
      <div className="flex min-h-0 flex-1">
        {sidebarOpen && <Sidebar />}
        {view ? (
          <DatabaseViews />
        ) : (
          <div className="flex min-w-0 flex-1">
            {panes.map((pane, index) => (
              <Fragment key={index}>
                <EditorPane paneIndex={index} />
                {index < panes.length - 1 ? <div className="w-px shrink-0 bg-line" /> : null}
              </Fragment>
            ))}
          </div>
        )}
        {rightOpen && <RightSidebar />}
      </div>
      <StatusBar />
      <CommandPalette />
      <GraphOverlay />
      {onboarding && <Onboarding />}
      <Toasts />
    </div>
  )
}
