import { useMemo, useState } from 'react'
import { ChevronDown, CornerUpLeft, FileText, ListTree, Search, Share2, X } from 'lucide-react'
import type { Note } from '../types'
import { buildTitleIndex, computeBacklinks, computeGraph, dirname, resolveLink } from '../lib/markdown'
import { cls, tagColor } from '../lib/utils'
import { scrollToHeadingText } from '../editor/registry'
import { useStore } from '../store/useStore'
import { ForceGraph } from './ForceGraph'

function Section({
  id,
  title,
  icon: Icon,
  count,
  children,
  bodyClass,
}: {
  id: 'outline' | 'backlinks' | 'graph'
  title: string
  icon: typeof ListTree
  count?: number
  children: React.ReactNode
  bodyClass?: string
}) {
  const open = useStore((s) => s.rightSections[id])
  const toggle = useStore((s) => s.toggleRightSection)
  return (
    <section className="border-b border-line last:border-b-0">
      <button
        type="button"
        onClick={() => toggle(id)}
        className="flex w-full items-center gap-1.5 px-3 py-2 text-left hover:bg-elev/60"
      >
        <ChevronDown size={13} className={cls('text-muted transition-transform', !open && '-rotate-90')} />
        <Icon size={13} className="text-muted" />
        <span className="flex-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted">{title}</span>
        {typeof count === 'number' ? <span className="text-[10px] text-muted">{count}</span> : null}
      </button>
      {open ? <div className={cls('pb-2', bodyClass)}>{children}</div> : null}
    </section>
  )
}

function OutlineSection({ note }: { note: Note }) {
  const activePane = useStore((s) => s.activePane)
  if (!note.headings.length) {
    return <div className="px-3 py-2 text-[11.5px] text-muted">No headings yet — add a <code className="font-mono">##</code> heading.</div>
  }
  return (
    <div className="max-h-[38vh] overflow-y-auto px-1.5">
      {note.headings.map((h, i) => (
        <button
          key={`${h.line}-${i}`}
          type="button"
          onClick={() => scrollToHeadingText(h.level, h.text, activePane)}
          className="block w-full truncate rounded-md py-[3px] pr-2 text-left text-[12px] text-ink/80 hover:bg-elev hover:text-ink"
          style={{ paddingLeft: 8 + (h.level - 1) * 11, fontWeight: h.level <= 2 ? 600 : 400 }}
          title={h.text}
        >
          {h.text}
        </button>
      ))}
    </div>
  )
}

function BacklinksSection({ note }: { note: Note }) {
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const backlinks = useMemo(() => computeBacklinks(notes)[note.path] || [], [notes, note.path])
  const list = backlinks

  if (!list.length) {
    return (
      <div className="px-3 py-2 text-[11.5px] leading-relaxed text-muted">
        No incoming links yet. Type <code className="font-mono">[[</code> in another note to reference this one.
      </div>
    )
  }
  return (
    <div className="max-h-[34vh] space-y-1 overflow-y-auto px-2">
      {list.map((b) => (
        <button
          key={b.path}
          type="button"
          onClick={() => openNote(b.path)}
          className="block w-full rounded-lg border border-line bg-elev px-2 py-1.5 text-left hover:border-accent/40"
        >
          <div className="flex items-center gap-1.5">
            <FileText size={11} className="shrink-0 text-muted" />
            <span className="truncate text-[12px] font-medium text-ink">{b.title}</span>
          </div>
          <div className="mt-0.5 text-[10px] text-muted">{dirname(b.path) || 'vault root'}</div>
          {b.snippets.slice(0, 2).map((s, i) => (
            <div key={i} className="mt-1 line-clamp-2 text-[11px] leading-snug text-muted">
              {s}
            </div>
          ))}
        </button>
      ))}
    </div>
  )
}

function LocalGraphSection({ note }: { note: Note }) {
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const [query, setQuery] = useState('')
  const [depth, setDepth] = useState<1 | 2>(1)

  const graph = useMemo(() => {
    const index = buildTitleIndex(notes)
    const keep = new Set<string>([note.path])
    let frontier = new Set<string>([note.path])
    for (let d = 0; d < depth; d++) {
      const next = new Set<string>()
      for (const path of frontier) {
        const n = notes[path]
        if (!n) continue
        for (const link of n.links) {
          const r = resolveLink(index, link.path || link.target)
          if (r && !keep.has(r)) {
            keep.add(r)
            next.add(r)
          }
        }
        for (const other of Object.values(notes)) {
          if (keep.has(other.path)) continue
          if (other.links.some((l) => resolveLink(index, l.path || l.target) === path)) {
            keep.add(other.path)
            next.add(other.path)
          }
        }
      }
      frontier = next
    }
    const subset: Record<string, Note> = {}
    for (const p of keep) if (notes[p]) subset[p] = notes[p]
    return computeGraph(subset)
  }, [notes, note.path, depth])

  const tags = useMemo(() => {
    const set = new Map<string, string>()
    for (const n of graph.nodes) if (n.tags[0] && !set.has(n.tags[0])) set.set(n.tags[0], tagColor(n.tags[0]))
    return [...set.entries()].slice(0, 5)
  }, [graph.nodes])

  return (
    <div>
      <div className="flex items-center gap-1.5 px-2.5 pb-1.5">
        <div className="flex flex-1 items-center gap-1 rounded-md border border-line bg-elev px-1.5 py-[3px]">
          <Search size={11} className="text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter graph…"
            className="w-full bg-transparent text-[11.5px] outline-none placeholder:text-muted/80"
          />
          {query ? (
            <button type="button" onClick={() => setQuery('')} className="text-muted hover:text-ink">
              <X size={10} />
            </button>
          ) : null}
        </div>
        <button
          type="button"
          onClick={() => setDepth(depth === 1 ? 2 : 1)}
          className="rounded-md border border-line bg-elev px-1.5 py-[3px] text-[10px] font-medium text-muted hover:text-ink"
          title="Toggle graph depth"
        >
          {depth}°
        </button>
      </div>
      <div className="mx-2 overflow-hidden rounded-lg border border-line" style={{ height: 208 }}>
        <ForceGraph
          nodes={graph.nodes}
          edges={graph.edges}
          activeId={note.path}
          search={query}
          mini
          onOpen={openNote}
        />
      </div>
      <div className="flex flex-wrap gap-1.5 px-3 py-1.5">
        {tags.map(([tag, color]) => (
          <span key={tag} className="flex items-center gap-1 text-[10px] text-muted">
            <span className="size-1.5 rounded-full" style={{ background: color }} />#{tag}
          </span>
        ))}
        <span className="ml-auto text-[10px] text-muted">{graph.nodes.length} nodes</span>
      </div>
    </div>
  )
}

export function RightSidebar() {
  const note = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ? s.notes[pane.active] ?? null : null
  })
  const notes = useStore((s) => s.notes)
  const backlinkCount = useMemo(() => (note ? (computeBacklinks(notes)[note.path] || []).length : 0), [notes, note])

  return (
    <aside className="flex w-[296px] shrink-0 flex-col overflow-y-auto border-l border-line bg-panel">
      {note ? (
        <>
          <Section id="outline" title="Outline" icon={ListTree} count={note.headings.length}>
            <OutlineSection note={note} />
          </Section>
          <Section id="backlinks" title="Backlinks" icon={CornerUpLeft} count={backlinkCount}>
            <BacklinksSection note={note} />
          </Section>
          <Section id="graph" title="Local graph" icon={Share2}>
            <LocalGraphSection note={note} />
          </Section>
        </>
      ) : (
        <div className="p-4 text-[12px] text-muted">Open a note to see its outline, backlinks and local graph.</div>
      )}
    </aside>
  )
}
