import { useMemo, useState } from 'react'
import { Focus, Search, Share2, X } from 'lucide-react'
import { computeGraph, dirname } from '../lib/markdown'
import { cls, tagColor } from '../lib/utils'
import { useStore } from '../store/useStore'
import { ForceGraph } from './ForceGraph'

export function GraphOverlay() {
  const open = useStore((s) => s.graphOpen)
  const focus = useStore((s) => s.graphFocus)
  const setGraphOpen = useStore((s) => s.setGraphOpen)
  const notes = useStore((s) => s.notes)
  const openNote = useStore((s) => s.openNote)
  const activePath = useStore((s) => {
    const pane = s.panes[Math.min(s.activePane, s.panes.length - 1)]
    return pane?.active ?? null
  })
  const [query, setQuery] = useState('')
  const [tag, setTag] = useState<string | null>(null)
  const [localOnly, setLocalOnly] = useState(!!focus)

  const graph = useMemo(() => {
    const all = computeGraph(notes)
    if (!localOnly) return all
    const center = focus || activePath
    if (!center) return all
    const keep = new Set<string>([center])
    for (const e of all.edges) {
      if (e.source === center) keep.add(e.target)
      if (e.target === center) keep.add(e.source)
    }
    return {
      nodes: all.nodes.filter((n) => keep.has(n.id)),
      edges: all.edges.filter((e) => keep.has(e.source) && keep.has(e.target)),
    }
  }, [notes, localOnly, focus, activePath])

  const tagCounts = useMemo(() => {
    const map = new Map<string, number>()
    for (const n of graph.nodes) for (const t of n.tags.slice(0, 1)) map.set(t, (map.get(t) || 0) + 1)
    return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
  }, [graph.nodes])

  const search = tag ? `#${tag}` : query

  if (!open) return null

  const center = focus || activePath
  const focusTitle = center ? notes[center]?.title : undefined

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ background: 'var(--graph-bg)' }}>
      <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-3">
        <Share2 size={15} className="text-accent" />
        <span className="text-[13px] font-semibold">Knowledge graph</span>
        <span className="hidden text-[11px] text-muted sm:inline">
          {focusTitle ? `· around “${focusTitle}”` : '· whole vault'}
        </span>

        <div className="ml-3 flex items-center gap-1.5 rounded-lg border border-line bg-panel px-2 py-[4px]">
          <Search size={12} className="text-muted" />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              if (tag) setTag(null)
            }}
            placeholder="Filter notes or tags…"
            className="w-[180px] bg-transparent text-[12px] outline-none placeholder:text-muted/80"
          />
          {query ? (
            <button type="button" onClick={() => setQuery('')} className="text-muted hover:text-ink">
              <X size={11} />
            </button>
          ) : null}
        </div>

        <button
          type="button"
          onClick={() => setLocalOnly((v) => !v)}
          className={cls(
            'inline-flex items-center gap-1.5 rounded-lg border px-2 py-[4px] text-[11.5px]',
            localOnly ? 'border-accent/50 bg-accent-soft text-accent' : 'border-line bg-panel text-muted hover:text-ink',
          )}
          title="Show only the active note's neighbourhood"
        >
          <Focus size={12} /> Local
        </button>

        <div className="ml-auto flex items-center gap-3">
          <span className="hidden text-[11px] text-muted md:inline">
            {graph.nodes.length} nodes · {graph.edges.length} links
          </span>
          <button
            type="button"
            onClick={() => setGraphOpen(false)}
            className="inline-flex size-8 items-center justify-center rounded-lg text-muted hover:bg-panel hover:text-ink"
            title="Close graph (Esc)"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="relative min-h-0 flex-1">
        <ForceGraph
          nodes={graph.nodes}
          edges={graph.edges}
          activeId={center}
          search={search}
          onOpen={(id) => {
            openNote(id)
            setGraphOpen(false)
          }}
        />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-3">
          <div className="pointer-events-auto flex flex-wrap items-center gap-1.5 rounded-xl border border-line bg-panel/85 p-1.5 backdrop-blur">
            {tagCounts.map(([t, count]) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  setTag(tag === t ? null : t)
                  setQuery('')
                }}
                className={cls(
                  'flex items-center gap-1.5 rounded-lg px-1.5 py-1 text-[11px] transition-colors',
                  tag === t ? 'bg-accent-soft text-ink' : 'text-muted hover:bg-elev hover:text-ink',
                )}
              >
                <span className="size-2 rounded-full" style={{ background: tagColor(t) }} />#{t}
                <span className="text-[9.5px] opacity-60">{count}</span>
              </button>
            ))}
            {!tagCounts.length && <span className="px-1 text-[11px] text-muted">No tags yet</span>}
          </div>
          <div className="pointer-events-none hidden gap-3 text-[10.5px] text-muted sm:flex">
            <span>drag to pan · scroll to zoom · click a node to open</span>
          </div>
        </div>
      </div>
    </div>
  )
}
