/* Vellum service worker — runtime cache so the app shell loads offline. */
const CACHE = 'vellum-shell-v1'

self.addEventListener('install', () => {
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys()
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
      await self.clients.claim()
    })(),
  )
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET') return
  const url = new URL(request.url)
  if (url.origin !== location.origin) return

  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE)
      const cached = await cache.match(request, { ignoreSearch: false })
      if (cached) {
        fetch(request)
          .then((response) => {
            if (response.ok) cache.put(request, response.clone())
          })
          .catch(() => {})
        return cached
      }
      try {
        const response = await fetch(request)
        if (response.ok) cache.put(request, response.clone())
        return response
      } catch (error) {
        const scope = self.registration.scope
        const shell =
          (await cache.match(new URL('index.html', scope).href)) ||
          (await cache.match(new URL('./', scope).href)) ||
          (await cache.match('/index.html'))
        if (shell) return shell
        throw error
      }
    })(),
  )
})
