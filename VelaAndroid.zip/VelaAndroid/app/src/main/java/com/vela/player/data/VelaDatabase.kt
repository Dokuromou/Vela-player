package com.vela.player.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface VelaDao {
    @Query("SELECT * FROM tracks ORDER BY addedAt DESC") fun allTracks(): Flow<List<Track>>
    @Query("SELECT * FROM tracks ORDER BY addedAt DESC") suspend fun tracksOnce(): List<Track>
    @Query("SELECT * FROM tracks WHERE uri = :uri LIMIT 1") suspend fun find(uri: String): Track?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(track: Track)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putAll(tracks: List<Track>)
    @Query("UPDATE tracks SET favorite = NOT favorite WHERE uri = :uri") suspend fun toggleFavorite(uri: String)
    @Query("DELETE FROM tracks WHERE uri = :uri") suspend fun remove(uri: String)
    @Query("SELECT * FROM mixes ORDER BY id DESC") fun mixes(): Flow<List<Mix>>
    @Insert suspend fun createMix(mix: Mix): Long
    @Query("DELETE FROM mixes WHERE id = :id") suspend fun deleteMix(id: Long)
}

@Database(entities = [Track::class, Mix::class], version = 1, exportSchema = false)
abstract class VelaDatabase : RoomDatabase() {
    abstract fun dao(): VelaDao
    companion object {
        @Volatile private var instance: VelaDatabase? = null
        fun get(context: Context): VelaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, VelaDatabase::class.java, "vela-library.db")
                .fallbackToDestructiveMigration().build().also { instance = it }
        }
    }
}
