export type Theme = 'dark' | 'light' | 'paper'
export type VaultKind = 'idb' | 'fs'

export type Frontmatter = Record<string, unknown>

export interface LinkRef {
  /** raw target without alias: "Projects/Website Redesign#Roadmap" */
  target: string
  path: string
  heading?: string
  alias?: string
  raw: string
  /** does the link have an "!" prefix */
  embed: boolean
}

export interface Heading {
  level: number
  text: string
  line: number
}

export interface Note {
  path: string
  content: string
  fm: Frontmatter
  body: string
  title: string
  tags: string[]
  links: LinkRef[]
  headings: Heading[]
  modified: number
}

export interface Backlink {
  path: string
  title: string
  snippets: string[]
}

export interface GraphNode {
  id: string
  label: string
  tags: string[]
  degree: number
}

export interface GraphEdge {
  source: string
  target: string
}

export interface GraphData {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

export interface VaultFile {
  path: string
  content: string
}

export interface VaultSnapshot {
  name: string
  kind: VaultKind
  files: VaultFile[]
}

export type ViewMode = 'table' | 'kanban'

export interface PaneState {
  tabs: string[]
  active: string | null
}

export type SuggestMode = 'slash' | 'wikilink'

// ---------------------------------------------------------------- search
export interface SearchDoc {
  path: string
  title: string
  text: string
}

export interface SearchHit {
  path: string
  title: string
  score: number
  snippet: string
}
